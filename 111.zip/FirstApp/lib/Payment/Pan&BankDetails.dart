import 'package:firstapp/Payment/MyWallet.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Pan extends StatefulWidget {
  const Pan({super.key});

  @override
  State<Pan> createState() => _PanState();
}

class _PanState extends State<Pan> {
  final email=TextEditingController();
  final mobile=TextEditingController();
  final PAN=TextEditingController();
  final Bank=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      body: LayoutBuilder(
        builder: (context, constraints) =>
            SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(
                    height:MediaQuery.of(context).size.height*1,
                    child: Stack(
                      children: [
                        Positioned(
                            top: 0,
                            bottom: 520,
                            left: 0,
                            right: 0,
                            child: Container(height: 360,
                              color: Colors.blueAccent,
                              child: Column(children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 18.0),
                                  child: Center(
                                    child: Text(
                                      'Verify PAN & Bank Details',
                                      style: GoogleFonts.yaldevi(
                                        fontSize: 24,color: Colors.white,
                                        fontWeight: FontWeight.w700,
                                        fontStyle: FontStyle.normal,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(height: 30,),
                               Row(
                                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                 children: [

                                 Icon(Icons.wallet,color: Colors.orange.shade200,size: 50,),
                                 Column(
                                   crossAxisAlignment: CrossAxisAlignment.start,
                                   children: [
                                   Text(
                                     'Get Verified',
                                     style: GoogleFonts.yaldevi(
                                       fontSize: 24,color: Colors.white,
                                       fontWeight: FontWeight.w700,
                                       fontStyle: FontStyle.normal,
                                     ),
                                   ),
                                   Text(
                                     'Withdraw winnings to your bank immediately',
                                     style: GoogleFonts.yaldevi(
                                       fontSize: 12,color: Colors.white,
                                       fontWeight: FontWeight.w700,
                                       fontStyle: FontStyle.normal,
                                     ),
                                   ),
                                 ],)
                               ],)
                              ],),)
                        ),
                        Positioned(
                          top:170,
                          left: 0,
                          right: 0,
                          child: Padding(
                            padding: const EdgeInsets.all( 13.0),
                            child: Container(
                              height: 450,
                              decoration: BoxDecoration(
                                color: Colors.white,boxShadow: [BoxShadow(color: Colors.black,blurRadius: 4)],
                                borderRadius: BorderRadius.circular(15),
                              ),
                            child: Column(children: [
                              SizedBox(height: 30,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  SizedBox(
                                    width: 250,
                                    child: TextFormField(
                                      controller: email,
                                      maxLength: 10,
                                      decoration: InputDecoration(
                                        counterStyle: TextStyle(color: Colors.black,fontSize: 1),
                                        contentPadding: EdgeInsets.only(left: 12),
                                        enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(color: Colors.blue.shade400),
                                          borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          borderSide: BorderSide(color: Colors.grey),
                                          borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                        ),
                                        labelText: 'Email',
                                        hintText: "Quiz.15@gmail.com",
                                        labelStyle: TextStyle(
                                          fontSize: 13.0, color: Colors.blue,
                                        ),
                                       prefixIcon: Icon(CupertinoIcons.mail_solid),
                                        suffixIcon: InkWell(child: Icon(Icons.edit))
                                      ),
                                    ),
                                  ),

                                ],
                              ),
                              SizedBox(
                                  width: 300,
                                  child: Divider(thickness: 1,)),
                              SizedBox(height: 10,),
                              SizedBox(width: 250,
                                child: TextFormField(
                                  controller: mobile,
                                  keyboardType: TextInputType.phone,
                                  maxLength: 10,
                                  decoration: InputDecoration(
                                      counterStyle: TextStyle(color: Colors.black,fontSize: 1),
                                      contentPadding: EdgeInsets.only(left: 12),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(color: Colors.blue.shade400),
                                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(color: Colors.grey),
                                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                      ),
                                      hintText: "+91-9315xxxxxx",
                                      labelText: 'Mobile',
                                      labelStyle: TextStyle(
                                        fontSize: 13.0, color: Colors.blue,
                                      ),
                                      prefixIcon: Icon(Icons.phone_android),

                                  ),
                                ),
                              ),
                              SizedBox(
                                  width: 300,
                                  child: Divider(thickness: 1,)),
                              SizedBox(height: 10,),
                              SizedBox(
                                width: 250,
                                child: TextFormField(
                                  controller: Bank,
                                  decoration: InputDecoration(
                                      counterStyle: TextStyle(color: Colors.black,fontSize: 1),
                                      contentPadding: EdgeInsets.only(left: 12),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(color: Colors.blue.shade400),
                                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(color: Colors.grey),
                                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                      ),
                                      labelText: 'Bank Name',
                                      hintText: "SBI Bank",
                                      labelStyle: TextStyle(
                                        fontSize: 13.0, color: Colors.blue,
                                      ),
                                      prefixIcon:Icon(Icons.account_balance),
                                    suffixIcon: Icon(Icons.edit)
                                  ),
                                ),
                              ),
                              SizedBox(
                                  width: 300,
                                  child: Divider(thickness: 1,)),
                              SizedBox(height: 10,),
                              SizedBox(
                                width: 250,
                                child: TextFormField(
                                  controller: PAN,
                                  maxLength: 10,
                                  decoration: InputDecoration(
                                      counterStyle: TextStyle(color: Colors.black,fontSize: 1),
                                      contentPadding: EdgeInsets.only(left: 12),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(color: Colors.blue.shade400),
                                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(color: Colors.grey),
                                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                      ),
                                      labelText: 'PAN Card',
                                      hintText: "MDHJFD3465L",
                                      labelStyle: TextStyle(
                                        fontSize: 13.0, color: Colors.blue,
                                      ),
                                      prefixIcon: Icon(CupertinoIcons.book_fill),
                                    suffixIcon: Icon(Icons.edit)


                                  ),
                                ),
                              ),

                              SizedBox(
                                  width: 300,
                                  child: Divider(thickness: 1,)),
                              SizedBox(
                                width: 250,
                                child: ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                      primary: Colors.green.shade400, // Background color
                                      onPrimary: Colors.white, // Text Color (Foreground color)
                                    ),
                                    onPressed: (){
                                      print(email.toString());

                                      print(mobile.toString());

                                      print(PAN.toString());
                                      print(Bank.toString());
                                      Get.to(
                                          fullscreenDialog: true,duration: Duration(milliseconds: 600),
                                          transition:Transition.fadeIn,
                                        FutureBuilder<String>(
                                          future: _getPhoneNumber(),
                                          builder: (context, snapshot) {
                                            if (snapshot.connectionState == ConnectionState.waiting) {
                                              return CircularProgressIndicator();
                                            } else if (snapshot.hasError) {
                                              return Text('Error: ${snapshot.error}');
                                            } else {
                                              return MyWallet(phone: snapshot.data ?? '');
                                            }
                                          },
                                        ),);
                                      Get.snackbar(
                                          backgroundColor:  Colors.teal.shade200,
                                          colorText: Colors.white,
                                          "Your Bank Details Is Verify..","");

                                    }, child: Text("Verify",)),
                              ),
                            ],),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            )
      ),
    );
  }
}
Future<String> _getPhoneNumber() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('PhoneNo') ?? ''; // Change 'PhoneNo' to your actual key
}
