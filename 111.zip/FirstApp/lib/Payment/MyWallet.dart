import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../BottomNavigation.dart';
import '../api/Add To Wallet.dart';
import '../api/MyWallet.dart';
import 'Pan&BankDetails.dart';
class MyWallet extends StatefulWidget {
final String phone;
 const MyWallet({super.key,required this.phone });

  @override
  State<MyWallet> createState() => _MyWalletState();
}

class _MyWalletState extends State<MyWallet> {
  Future<List<Add>> sendAndFetchData(String phoneNumber, String wallet) async {
    try {
      // Send data to the API using POST method
      final sendResponse = await http.post(
        Uri.parse('https://amazonboost.in/demo/api/wallet.php'),
        body: {
          'phone': widget.phone,
          'wallet': rupees.text,
        },
      );
      print('Send API Response Status Code: ${sendResponse.statusCode}');
      print('Send API Response Body: ${sendResponse.body}');

      if (sendResponse.statusCode == 200) {
        final dynamic data = json.decode(sendResponse.body);

        if (data is List) {
          // Handle the case where data is a list
          return data.map((countryData) {
            return Add.fromJson(countryData);
          }).toList();
        } else if (data is Map<String, dynamic>) {
          // Handle the case where data is an object
          return [Add.fromJson(data)];
        } else {
          throw Exception('Invalid response format');
        }
      } else {
        throw Exception('Failed to send data to API');
      }
    } catch (error) {
      print('Error: $error');
      throw Exception('Error: $error');
    }
  }

  Future<List<Wallet>> walletBalance(String phoneNumber) async {
    try {
      final response = await http.get(
        Uri.parse('https://amazonboost.in/demo/twiz/userdetail?phone=$phoneNumber'),
      );

      if (response.statusCode == 200) {
        final dynamic data = json.decode(response.body);

        if (data is List) {
          // Handle the case where data is a list
          return data.map((countryData) {
            return Wallet.fromJson(countryData);
          }).toList();
        } else if (data is Map<String, dynamic>) {
          // Handle the case where data is an object
          return [Wallet.fromJson(data)];
        } else {
          throw Exception('Invalid response format');
        }
      } else {
        print('API Response Status Code: ${response.statusCode}');
        print('API Response Body: ${response.body}');
        throw Exception('Failed to load data from API');
      }
    } catch (error) {
      print('Error: $error');
      throw Exception('Error: $error');
    }
  }
  final rupees=TextEditingController();
  final formGlobalKey = GlobalKey<FormState>();
  Future<void> _saveWalletAmount(String walletAmount) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('WalletAmount', walletAmount);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      body: Form(
        key: formGlobalKey,
        child: LayoutBuilder(
          builder: (context, constraints) =>
              SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height:MediaQuery.of(context).size.height*1,
                      child: Stack(
                        children: [
                          Positioned(
                              top: 0,
                              bottom: 520,
                              left: 0,
                              right: 0,
                              child: Container(height: 360,
                                color: Colors.blueAccent,
                                child: Column(children: [
                                  Padding(
                                    padding: const EdgeInsets.only(top: 18.0),
                                    child: Row(
                                      children: [
                                        IconButton(onPressed: (){
                                          Get.to(NavBar());
                                        }, icon:Icon(CupertinoIcons.arrow_left,color: Colors.white,)),
                                        Text(
                                          'My Wallet',
                                          style: GoogleFonts.yaldevi(
                                            fontSize: 24,color: Colors.white,
                                            fontWeight: FontWeight.w700,
                                            fontStyle: FontStyle.normal,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Container(
                                      height: 100,
                                      decoration: BoxDecoration(
                                        color: Colors.black26,
                                         borderRadius: BorderRadius.circular(21)
                                      ),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Row(
                                            children: [
                                              Icon(Icons.account_balance_wallet_outlined,color: Colors.orange,size: 40,),
                                              Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  SizedBox(height: 25,),
                                                  Text("Mobile Number",style: TextStyle(color: Colors.white,fontSize: 15),),
                                                  SizedBox(height: 10,),

                                                  Text(widget.phone,style: TextStyle(color: Colors.white,fontSize: 18),)
                                                ],
                                              )
                                            ],
                                          ),
                                          ElevatedButton(
                                              style: ElevatedButton.styleFrom(
                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),),
                                                primary: Colors.green.shade700, // Background color
                                                onPrimary: Colors.grey.shade200, // Text Color (Foreground color)
                                              ),
                                              onPressed: (){
                                               showBottomSheet(context: context,
                                                    shape:RoundedRectangleBorder( borderRadius: BorderRadius.only(topRight: Radius.circular(30),topLeft: Radius.circular(30))),
                                                    backgroundColor: Colors.grey.shade200,
                                                    builder: (context){
                                                     return FutureBuilder<List<Wallet>>(
                                                    future: walletBalance(widget.phone),
                                                    builder: (context, snapshot) {
                                                      if (snapshot.connectionState == ConnectionState.waiting) {
                                                        return Center(
                                                          child: CircularProgressIndicator(),
                                                        );
                                                      } else if (snapshot.hasError) {
                                                        return Center(
                                                          child: Text('Error: ${snapshot.error}'),
                                                        );
                                                      } else {
                                                        final walletData = snapshot.data!.first;
                                                        _saveWalletAmount(walletData.wallet.toString());
                                                        return SizedBox(
                                                            height: 400,
                                                            child: Column(
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsets.all(8.0),
                                                                  child: Row(
                                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                    children: [
                                                                      Text("Add money",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 24),),
                                                                      IconButton(onPressed: (){
                                                                        Navigator.pop(context,false);
                                                                      }, icon: Icon(Icons.close))
                                                                    ],
                                                                  ),
                                                                ),
                                                                Container(
                                                                  decoration: BoxDecoration(
                                                                      gradient: LinearGradient(colors: [
                                                                        Colors.blue.shade200,
                                                                        Colors.grey.shade200,
                                                                      ])
                                                                  ),

                                                                  height:50,
                                                                  width:300,

                                                                  child: Row(
                                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                    children: [
                                                                      Row(
                                                                        children: [
                                                                          Icon(Icons.account_balance_wallet,color: Colors.orange,size: 30,),

                                                                          SizedBox(width: 12,),
                                                                          Text("Current Balance",style: TextStyle(color: Colors.black,fontSize: 15),),
                                                                          Icon((CupertinoIcons.info),color: Colors.black,)

                                                                        ],
                                                                      ),
                                                                      Text("₹"+walletData.wallet.toString(),style: TextStyle(color: Colors.black,fontSize: 18),),

                                                                    ],
                                                                  ),
                                                                ),
                                                                SizedBox(height: 12,),
                                                                SizedBox(
                                                                  width:300,
                                                                  child: TextFormField(
                                                                    controller: rupees,
                                                                    keyboardType: TextInputType.phone,

                                                                    decoration: InputDecoration(
                                                                      contentPadding: EdgeInsets.only(left: 18),                                                            enabledBorder: OutlineInputBorder(

                                                                      borderSide: BorderSide(color:Colors.blue.shade400),
                                                                      borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                                                    ),
                                                                      focusedBorder: OutlineInputBorder(
                                                                        borderSide: BorderSide(color: Colors.grey),
                                                                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                                                      ),
                                                                      hintText: 'Add Amount',

                                                                      hintStyle: TextStyle(
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 18.0, color: Colors.blue.shade400
                                                                      ),



                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(height: 30,),
                                                                SizedBox(
                                                                  width: 300,
                                                                  child: ElevatedButton(
                                                                    style: ElevatedButton.styleFrom(
                                                                      shape: RoundedRectangleBorder(
                                                                          borderRadius: BorderRadius.circular(12)),
                                                                      primary: Colors.green, // Background color
                                                                      onPrimary: Colors.white, // Text Color (Foreground color)
                                                                    ),
                                                                    onPressed: () {

                                                                      if (formGlobalKey.currentState?.validate() ?? false) {
                                                                        sendAndFetchData(rupees.text, 'Your Wallet')
                                                                            .then((response) {
                                                                          // Handle the API response, e.g., display data
                                                                          print(response);
                                                                        }).catchError((error) {
                                                                          print('Error: $error');
                                                                          ScaffoldMessenger.of(context).showSnackBar(
                                                                            SnackBar(
                                                                              content: Text('Failed to send data to API'),
                                                                            ),
                                                                          );
                                                                        });
                                                                      }
                                                                    },
                                                                    child: Text('Add Money',   style: GoogleFonts.poppins(
                                                                      fontSize: 18,
                                                                      fontWeight: FontWeight.w300,
                                                                      color: Colors.white,
                                                                    ),),
                                                                  ),
                                                                ),
                                                              ],
                                                            )
                                                        );
                                                      }
                                                    },
                                                  );

                                                });
                                                }, child: Text("Add Money",style: GoogleFonts.poppins(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w300,
                                            color: Colors.white,
                                          ),)),

                                        ],
                                      ),
                                    ),
                                  )
                                ],),)
                          ),
                          Positioned(
                            top:170,
                            left: 0,
                            right: 0,
                            child: Padding(
                              padding: const EdgeInsets.all( 13.0),
                              child: Container(
                                height: 550,
                                decoration: BoxDecoration(
                                color: Colors.white,boxShadow: [BoxShadow(color: Colors.black,blurRadius: 4)],
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Column(children: [
                                    Row(
                                      children: [

                                        Icon(Icons.badge_rounded,color: Colors.orange,size: 30,),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [

                                            Row(
                                              children: [
                                                Text("Amount Unutilised",style: TextStyle(color: Colors.black,fontSize: 15),),
                                                Icon((CupertinoIcons.info),color: Colors.black,)
                                              ],
                                            ),
                                            Text("₹1",style: TextStyle(color: Colors.black,fontSize: 18),),

                                          ],
                                        )
                                      ],
                                    ),
                                    SizedBox(width: 300,
                                      child: Divider(
                                        thickness: 1,color: Colors.black,
                                      ),
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
  children: [
    Icon(Icons.blur_circular,color: Colors.orange,size: 30,),
    Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Row(
            children: [
              Text("Winnings",style: TextStyle(color: Colors.black,fontSize: 15),),
              Icon((CupertinoIcons.info),color: Colors.black,)
            ],
          ),
          Text("₹0",style: TextStyle(color: Colors.black,fontSize: 18),),

        ],
    ),  ],
),
                                        ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                              primary: Colors.green.shade700, // Background color
                                              onPrimary: Colors.white, // Text Color (Foreground color)
                                            ),
                                            onPressed: (){
                                              Get.to(
                                                  fullscreenDialog: true,duration: Duration(milliseconds: 600),
                                                  transition:Transition.fadeIn,
                                                  Pan());
                                            }, child: Text("Verify for Withdraw")),
                                      ],
                                    ),
                                    SizedBox(width: 300,
                                      child: Divider(
                                        thickness: 1,color: Colors.black,
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        Icon(Icons.attach_money_outlined,color: Colors.orange,size: 30,),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [

                                            Row(
                                              children: [
                                                Text("Bonus",style: TextStyle(color: Colors.black,fontSize: 15),),
                                                Icon((CupertinoIcons.info),color: Colors.black,)
                                              ],
                                            ),
                                            Text("₹1.96",style: TextStyle(color: Colors.black,fontSize: 18),),

                                          ],
                                        )
                                      ],
                                    ),
                                    SizedBox(width: 300,
                                      child: Divider(
                                        thickness: 1,color: Colors.black,
                                      ),
                                    ),
                                    SizedBox(height: 50,),
                                    Container(
                                      height: 150,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        boxShadow: [BoxShadow(color: Colors.black,blurRadius: 1)],
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      child: Column(
                                        children: [
                                          ListTile(
                                            leading: Icon(Icons.data_usage_sharp),
                                            title: Text("My Transactions"),
                                            trailing: Icon(Icons.arrow_right),
                                          ),
                                          SizedBox(width: 300,
                                            child: Divider(
                                              thickness: 1,color: Colors.black,
                                            ),
                                          ),
                                          ListTile(
                                            leading: Icon(Icons.refresh),
                                            title: Text("Refer & Earn"),
                                            subtitle: Text("Invite Friens To earn Rs. 99",style: TextStyle(fontSize: 13,color: Colors.grey),),
                                            trailing: Icon(Icons.arrow_right),
                                          ),

                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 50,),
                                    Container(
                                      height: 70,
                                      decoration: BoxDecoration(
                                        color: Colors.green.shade100,
                                        boxShadow: [BoxShadow(color: Colors.green,blurRadius: 1)],
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      child: Column(
                                        children: [
                                          ListTile(
                                            leading: Icon(Icons.messenger_sharp),
                                            title: Text("Do You have a Question about Balance..",style: TextStyle(fontSize: 14),),
                                            trailing:  ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                                  primary: Colors.green.shade700, // Background color
                                                  onPrimary: Colors.white, // Text Color (Foreground color)
                                                ),
                                                onPressed: (){
                                                }, child: Text("Get Help")),
                                          ),


                                        ],
                                      ),
                                    ),
                                  ],),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
        ),
      ),
    );
  }
}
