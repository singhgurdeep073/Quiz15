import 'package:firstapp/CategoryLangs.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'BottomNavigation.dart';
import 'Home/RankPages/Catgorytab/Fix.dart';
class CategoryReg extends StatefulWidget {
  final String pass;
  CategoryReg({super.key, required this.pass});

  @override
  _CategoryRegState createState() => _CategoryRegState();
}

class _CategoryRegState extends State<CategoryReg> {
  List<String> selectedLanguages = [];
  List<String> availableLanguages = [];

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.green,
        content: Text(message),
        duration: Duration(seconds: 2),
      ),
    );
  }
  Future<void> fetchLanguages() async {
    final response =
    await http.get(Uri.parse('https://amazonboost.in/demo/twiz/categor'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      setState(() {
        availableLanguages =
            data.map((language) => language['categ']).toList().cast<String>();
      });
    } else {
      _showSnackBar('Failed to load languages.');
    }
  }
  void fixTab(){
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => FixTab(phone:widget.pass),
      ),
    );
  }

  Future<void> sendToSecondAPI(List<String> selectedCategories) async {
    try {
      final response = await http.post(
        Uri.parse('https://amazonboost.in/demo/api/categor.php'),
        body: {
          'categgor': selectedCategories.join(','), // Join selected categories
          'register_id': widget.pass,
        },
      );

      print('Raw Response: ${response.body}');
      if (response.statusCode == 200) {
        if (response.body.startsWith('{')) {
          final responseData = json.decode(response.body);
          if (responseData['status'] == 'success') {
            _showSnackBar('Invalid response format from second API.');
            print('Response Data: $responseData');
          } else {
            _showSnackBar(
                'Failed to send data to second API. ${responseData['status']}');
          }
        } else {
          print('Data sent to second API successfully');
          Get.to(Langs(pass: widget.pass));
        }
      } else {
        _showSnackBar(
            'Failed to send data to second API. Status Code: ${response.statusCode}');
      }
    } catch (error, stackTrace) {
      print('Error sending data to second API: $error');
      print(stackTrace);
      _showSnackBar(
          'An error occurred while sending data to second API. $error');
    }
  }

  @override
  void initState() {
    super.initState();
    fetchLanguages();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,

      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.70,
            width: double.infinity,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  height: MediaQuery.of(context).size.height * .20,
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(12),
                      bottomLeft: Radius.circular(12),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      'Select your Category',
                      style: GoogleFonts.poppins(
                        fontSize: 25,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 16),
                Container(
                  margin: EdgeInsets.only(left:MediaQuery.of(context).size.width * 0.10,),
                  width: MediaQuery.of(context).size.width * 0.80,
                  height: MediaQuery.of(context).size.height * 0.46,
                  decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                    gradient: LinearGradient(colors: [
                      Colors.teal.shade50,
                      Colors.blue.shade100,
                      Colors.teal.shade50,

                    ]),
                    borderRadius: BorderRadius.circular(23)
                  ),
                  child: SingleChildScrollView(

                    child: Column(
                      children: availableLanguages.map((language) {
                        return CheckboxListTile(
                          activeColor: Colors.black,
                          checkColor: Colors.white,

                          title: Text(
                            language,
                            style: GoogleFonts.roboto(
                              fontSize: 17,color: Colors.black,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          value: selectedLanguages.contains(language),
                          onChanged: (bool? value) {
                            setState(() {
                              if (value != null) {
                                if (value) {
                                  selectedLanguages.add(language);
                                } else {
                                  selectedLanguages.remove(language);
                                }
                              }
                            });
                          },
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 50,
            width: 300,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                primary: Colors.blue.shade200,
                onPrimary: Colors.white,
              ),
              onPressed: () {
                if (selectedLanguages.isEmpty) {
                  _showSnackBar('Please select at least one category.');
                } else {
                  // Send the selected data to the second API
                  sendToSecondAPI(selectedLanguages);
                  print('Selected Categories: $selectedLanguages');
                  print(widget.pass);
                }
              },
              child: Text('Select',style: GoogleFonts.poppins(
                fontSize: 20,color: Colors.white,
                fontWeight: FontWeight.w600,
              ),),
            ),
          ),
        ],
      ),
    );
  }
}
