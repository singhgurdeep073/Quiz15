import 'dart:convert';

import 'package:firstapp/FirstScreen%20Pge/Rewards.dart';
import 'package:firstapp/FirstScreen%20Pge/Winners.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

import 'FirstScreen Pge/Home.dart';
import 'FirstScreen Pge/Share&earn.dart';
import 'QuizCategory/NavBar.dart';
import 'api/MyWallet.dart';

class NavBar extends StatefulWidget {

  const NavBar({Key? key,}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {

  int currentPage = 0;
  List<Widget> pages =  [
    HomePage(),
    QuizNav(),
    Rewards(),
    Shareandearn(),
    Winners(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[currentPage],
      bottomNavigationBar: Padding(
        padding:  EdgeInsets.all(12),
        child: Container(
          height: 53,
          /*  decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(13)),*/
          child: GNav(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            activeColor: Colors.white,
            tabBackgroundColor: Colors.blue,
            gap: 1,
            onTabChange: (index) => setState(() => currentPage = index),
            selectedIndex: currentPage,
            padding: const EdgeInsets.all(16),
            tabs: const [
              GButton(icon: Icons.home,textSize: 10,iconColor: Colors.grey,iconSize: 25),
              GButton(icon: Icons.chat_bubble,textSize: 10,iconColor: Colors.grey,iconSize: 25),
              GButton(icon: Icons.currency_rupee,textSize: 15,iconColor: Colors.grey,iconSize: 25),
              GButton(icon: Icons.whatshot,textSize: 15,iconColor: Colors.grey,iconSize: 25),
              GButton(icon: Icons.public,textSize: 15,iconColor: Colors.grey,iconSize: 25),
            ],
          ),
        ),
      ),
    );
  }
}