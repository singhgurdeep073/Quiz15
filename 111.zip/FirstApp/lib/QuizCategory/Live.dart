import 'dart:convert';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Home/Notification.dart';
import '../Payment/MyWallet.dart';
import '../Quiz Page/Quiz Page.dart';
import '../api/Present.dart';
import 'package:http/http.dart' as http;
class Present {
  int? id;
  String? categ;
  String? subject;
  String? user;
  String? user_join;
  String? price;
  String?start_time;
  String? end_time;

  Present({required this.id,required this.start_time,required this.user_join,required this.end_time,required this.categ,required this.subject,required this.price});
  Present.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    user_join = json['user_join'];
    start_time = json['start_time'];
    categ = json['categ'];
    subject = json['subject'];
    user = json['user'];
    end_time = json['end_time'];
    price = json['price'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_join'] = this.user_join;
    data['start_time'] = this.start_time;
    data['categ'] = this.categ;
    data['subject'] = this.subject;
    data['user'] = this.user;
    data['end_time'] = this.end_time;
    data['price'] = this.price;
    return data;
  }
}
class Live extends StatefulWidget {
  final String phone;
  const Live({super.key, required this.phone});

  @override
  State<Live> createState() => _LiveState();
}

class _LiveState extends State<Live> {
  Future<List<Present>> present(Mob) async {
    final response = await http.get(Uri.parse('http://amazonboost.in/demo/twiz/quiz_user?phone=$Mob'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((countryData) {
        final msg = countryData['id'];
        final user_join = countryData['user_join'];
        final start_time = countryData['start_time'];
        final categ = countryData['categ'];
        final subject = countryData['subject'];
        final end_time = countryData['end_time'];
        final price = countryData['price'];
        return Present(id: msg,categ:categ,price: price,subject: subject, start_time: start_time,user_join: user_join,end_time:end_time);
      }).toList();
    } else {
      throw Exception('Failed to load countries');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.black,
        ),
        backgroundColor: Colors.white,
        actions: [
          Container(
            margin: EdgeInsets.only(right: 100),
            height: 70,width: 70,
            decoration: BoxDecoration(
                image: DecorationImage(image: AssetImage("images/logo.png"))
            ),
          ),
          IconButton(onPressed: (){
            Get.to(
                fullscreenDialog: true,duration: Duration(milliseconds: 600),
                transition:Transition.fadeIn,
              FutureBuilder<String>(
                future: _getPhoneNumber(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  } else {
                    return MyWallet(phone: snapshot.data ?? '');
                  }
                },
              ),);
          }, icon:Icon( Icons.account_balance_wallet,color: Color(0xff259de0),),),

        ],
       ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child:Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: Text(
                  'Quiz Live Now',
                  style: GoogleFonts.yaldevi(
                    fontSize: 24,color: Colors.red,
                    fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.normal,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'View All >',
                  style: GoogleFonts.yaldevi(
                    fontSize: 13,
                    fontWeight: FontWeight.w400,
                    fontStyle: FontStyle.normal,
                  ),
                ),
              ),
            ],
          ),
          Container(
            height: MediaQuery.of(context).size.height*.70,
            child: FutureBuilder<List<Present>>(
              future: present(widget.phone),
              builder: (context,snapshot)
              {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                }
                else{
                  return ListView.builder(
                      itemCount: snapshot.data!.length,
                      itemBuilder: (context, index)
                      {
                        final country = snapshot.data![index];
                        return Container(height: 140,width: 350,
                          margin: EdgeInsets.only(top: 4),
                          decoration: BoxDecoration(
                              border: Border.all(color: Color(0xffe5e5e5),width: 1.50 ),
                              borderRadius: BorderRadius.circular(10)
                          ),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(height: 36,
                                    width: 120,

                                    decoration: BoxDecoration(
                                        color: Color(0xffe3e7ed),
                                        borderRadius: BorderRadius.only(bottomRight: Radius.circular(45),topLeft: Radius.circular(12))
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 7.0,right: 1,top: 12),
                                      child: Text(
                                       country.subject.toString(),
                                        style: GoogleFonts.poppins(
                                          textStyle: Theme.of(context).textTheme.displayLarge,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w300,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      children: [
                                        Text("Entry : ",style: TextStyle(fontWeight: FontWeight.bold,color: Color(0xffb63131),fontSize: 13),),
                                        Text(country.price.toString(),style: TextStyle(fontSize: 15,color: Color(0xff09a866)),),
                                      ],
                                    ),
                                  ),
                                ],),
                              SizedBox(
                                height: 10,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 8.0,right: 8),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                                  children: [
                                    Text(
                                      '₹6 Lakhs',
                                      style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),
                                    ),
                                    GestureDetector(
                                    onTap: (){
                                      Get.to(
                                       fullscreenDialog: true,
                                       duration: Duration(milliseconds: 600),
                                       transition: Transition.fadeIn,
                                          QuizPage(phone: widget.phone,id:_phone.toString() ,));
                                       },
                                      child: Container(
                                        height:35,width: 150,
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(12),
                                            color: Color(0xff07a76b)
                                        ),
                                        child:   Center(
                                          child: Text(
                                            'Join Now',
                                            style: GoogleFonts.poppins(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w700,
                                              fontStyle: FontStyle.normal,
                                            ),
                                          ),
                                        ),),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 15),
                                height: 41,width: 350,
                                decoration: BoxDecoration(
                                    color: Color(0xfff5f5f5),
                                    borderRadius: BorderRadius.only(bottomRight: Radius.circular(10),
                                        bottomLeft: Radius.circular(10)
                                    )
                                ),child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(children: [
                                    Icon( Icons.monetization_on, size: 15,),
                                    SizedBox(width: 6,),
                                    Text(
                                      '₹60,000',
                                      style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                                    ),
                                    SizedBox(width: 6,),
                                    Icon( Icons.local_bar_outlined, size: 15,),
                                    SizedBox(width: 6,),
                                    Text(
                                      '57%',
                                      style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                                    ),
                                    SizedBox(width: 6,),
                                    Icon( Icons.maps_ugc_sharp, size: 15,),
                                    SizedBox(width: 6,),
                                    Text(
                                      'Upto 20',
                                      style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                                    ),
                                  ],),
                                  Row(
                                    children: [
                                      Icon( Icons.check_circle_outline, ),
                                      SizedBox(width: 6,),
                                      Text(
                                        'Guaranteed',
                                        style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                                      ),
                                    ],
                                  ),



                                ],
                              ),)


                            ],),);
                      });
                }
              },
            ),
          )
        ],),
      ),
    );
  }
}
Future<String> _getPhoneNumber() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('PhoneNo') ?? ''; // Change 'PhoneNo' to your actual key
}
Future<String> _phone(int id) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString(id.toString()) ?? '';
}
