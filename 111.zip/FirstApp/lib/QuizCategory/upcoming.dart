import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../Home/Notification.dart';
import '../Home/RankPages/Catgorytab/Fix.dart';
import '../Home/RankPages/RankPage.dart';
import '../Payment/MyWallet.dart';
class Book {
  int? id;
  String? categ;
  String? subject;
  String? user_join;
  String? price;
  String?start_time;
  String? end_time;
  String?slot;
  String?user;
  Book({required this.slot,required this.id,required this.start_time,required this.user_join,required this.end_time,required this.categ,required this.subject,required this.price,required this.user});
  Book.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    user_join = json['user_join'];
    start_time = json['start_time'];
    categ = json['categ'];
    subject = json['subject'];
    end_time = json['end_time'];
    price = json['price'];
    slot = json['slot'];
    user = json['user'];

  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_join'] = this.user_join;
    data['start_time'] = this.start_time;
    data['categ'] = this.categ;
    data['subject'] = this.subject;
    data['end_time'] = this.end_time;
    data['price'] = this.price;
    data['slot'] = this.slot;
    data['user'] = this.user;
    return data;
  }
}

class Booked extends StatefulWidget {
  final String phone;
  const Booked({super.key, required this.phone});

  @override
  State<Booked> createState() => _BookedState();
}

class _BookedState extends State<Booked> {
  Future<List<Book>> UpcomingQuiz(Mob) async {
    final response = await http.get(Uri.parse('https://amazonboost.in/demo/twiz/slotbooked?phone=$Mob'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((countryData) {
        final msg = countryData['id'];
        final userJoin = countryData['user_join'];
        final startTime = countryData['start_time'];
        final categ = countryData['categ'];
        final subject = countryData['subject'];
        final endTime = countryData['end_time'];
        final price = countryData['price'];
        final slot = countryData['slot'];
        final user = countryData['user'];

        return Book(user:user ,slot: slot,id: msg,categ:categ,price: price,subject: subject, start_time: startTime,user_join: userJoin,end_time:endTime  );
      }).toList();
    } else {
      throw Exception('Failed to load countries');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.black, //change your color here
        ),
        backgroundColor: Colors.white,
        actions: [
          Container(
            margin: EdgeInsets.only(right: 100),
            height: 70,width: 70,
            decoration: BoxDecoration(
                image: DecorationImage(image: AssetImage("images/logo.png"))
            ),
          ),
          IconButton(onPressed: (){
            Get.to(
                fullscreenDialog: true,duration: Duration(milliseconds: 600),
                transition:Transition.fadeIn,
              FutureBuilder<String>(
                future: _getPhoneNumber(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  } else {
                    return MyWallet(phone: snapshot.data ?? '');
                  }
                },
              ),);
          }, icon:Icon( Icons.account_balance_wallet,color: Color(0xff259de0),),),
        ],
      ),
      body: SingleChildScrollView(
        child:   Column(children: [
          Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: Text(
                  'Booked Quiz',
                  style: GoogleFonts.yaldevi(
                    fontSize: 24,color: Colors.red,
                    fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.normal,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'View All >',
                  style: GoogleFonts.yaldevi(
                    fontSize: 13,
                    fontWeight: FontWeight.w400,
                    fontStyle: FontStyle.normal,
                  ),
                ),
              ),
            ],
          ),
          Container(
              height: MediaQuery.of(context).size.height*.70,
              child: FutureBuilder<List<Book>>(
                future: UpcomingQuiz(widget.phone),
                builder: (context,snapshot)
                {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: SpinKitWaveSpinner(color: Colors.grey));
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  }
                  else{
                    return
                      Container(
                        child: ListView.builder(
                            scrollDirection: Axis.vertical,
                            itemCount: snapshot.data!.length,
                            itemBuilder: (context, index)
                            {
                              final country = snapshot.data![index];
                              return Column(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Container(
                                      height: 133,width: 350,
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Color(0xffe5e5e5),width: 1.50 ),
                                          borderRadius: BorderRadius.circular(10)
                                      ),
                                      child: Column(
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(right: 8.0),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Container(height: 36,
                                                  width: 110,
                                                  decoration: BoxDecoration(
                                                      color: Color(0xffe3e7ed),
                                                      borderRadius: BorderRadius.only(bottomRight: Radius.circular(45),topLeft: Radius.circular(12))
                                                  ),
                                                  child: Center(
                                                    child: Text(
                                                      country.categ.toString(),
                                                      style: GoogleFonts.poppins(
                                                        textStyle: Theme.of(context).textTheme.displayLarge,
                                                        fontSize: 18,
                                                        fontWeight: FontWeight.w500,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  country.subject.toString(),
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 18,
                                                    color: Color(0xff07a76b),
                                                    fontWeight: FontWeight.w500,
                                                    fontStyle: FontStyle.normal,
                                                  ),
                                                ),
                                                Container(
                                                  height:25,width: 120,
                                                  decoration: BoxDecoration(
                                                      borderRadius: BorderRadius.circular(5),
                                                      color: Color(0xff07a76b),
                                                      border: Border.all(color:Color(0xff07a76b), )
                                                  ),
                                                  child:   Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      Text(
                                                        ' Competitions',
                                                        style: GoogleFonts.poppins(
                                                          fontSize: 12,
                                                          fontWeight: FontWeight.w400,
                                                          fontStyle: FontStyle.normal,
                                                        ),
                                                      ),
                                                      Container(color: Colors.white,height: 25,width: 25,
                                                        child: Center(
                                                          child: Text(
                                                            country.user_join.toString(),
                                                            style: GoogleFonts.poppins(
                                                              fontSize: 18,
                                                              color: Colors.blue,
                                                              fontWeight: FontWeight.w700,
                                                              fontStyle: FontStyle.normal,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),),
                                              ],),
                                          ),
                                          SizedBox(
                                            height: 3,
                                          ),
                                          Divider(thickness: 0.50,),
                                          Padding(
                                            padding: const EdgeInsets.only(left: 8.0,right: 8),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Column(crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Text("Win Cash",style: TextStyle(fontSize: 16,color: Colors.green,fontWeight: FontWeight.bold),),
                                                    Text("Prize Pool ",style: TextStyle(fontSize: 12,color: Colors.black,fontWeight: FontWeight.bold),),
                                                  ],
                                                ),
                                                Text("₹"+country.price.toString(),style:TextStyle(fontSize: 18),),
                                                // ... (Your existing code)

                                                SizedBox(
                                                  height: 30,
                                                  width: 90,
                                                  child: ElevatedButton(
                                                    style: ElevatedButton.styleFrom(
                                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                                                      primary: Colors.red.shade200,
                                                      onPrimary: Colors.white,
                                                    ),
                                                    onPressed: () async {
                                                      try {
                                                        // Make the API call to fixSlot directly in the onPressed callback
                                                        final response = await http.get(Uri.parse('https://amazonboost.in/demo/twiz/slot?q_id=${country.id}'));

                                                        if (response.statusCode == 200) {
                                                          final Map<String, dynamic> data = json.decode(response.body);
                                                          if (data.isNotEmpty) {
                                                            final message = data['message'];
                                                            final status = data['status'];

                                                            // Check the status from the API response
                                                            if (status == "success") {
                                                              // If the status is success, you can show a success message or perform other actions
                                                              print("Fix Slot success: $message");
                                                            } else {

                                                              // Handle other cases, e.g., show an error message
                                                              Get.snackbar(
                                                                  backgroundColor: Colors.red.shade200,
                                                                  colorText: Colors.white,
                                                                  "Slot Already Book","You Will Be Notified when Quiz Start.");
                                                            }
                                                          } else {
                                                            // Handle the case when the result is empty
                                                            print("Fix Slot failed: Empty result");
                                                          }
                                                        } else {
                                                          // Handle other HTTP status codes, e.g., show an error message
                                                          print("Fix Slot failed: HTTP Status Code ${response.statusCode}");
                                                        }
                                                      } catch (e) {
                                                        // Handle exceptions, e.g., show an error message
                                                        print("Error during Fix Slot API call: $e");
                                                      }
                                                    },
                                                    child: Text(
                                                      'Booked',
                                                      style: GoogleFonts.poppins(
                                                        fontSize: 14,
                                                        fontWeight: FontWeight.bold,
                                                        color: Colors.white,
                                                      ),
                                                    ),
                                                  ),
                                                ),





                                              ],
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.only(top: 10),
                                            height: 35,width: MediaQuery.of(context).size.width*1,
                                            decoration: BoxDecoration(
                                                color: Color(0xffd4d4d4),
                                                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(8),bottomRight: Radius.circular(8))),
                                            child: Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Row(children: [
                                                    Icon(Icons.sign_language_sharp,color: Colors.blue,size: 17,),
                                                    Text("English",style: TextStyle(fontSize: 12,color: Colors.black,fontWeight: FontWeight.bold),),


                                                  ],),
                                                  Row(children: [
                                                    Icon(Icons.alarm_on,color: Colors.blue,size: 17,),
                                                    Text(country.start_time.toString(),style: TextStyle(fontSize: 12,color: Colors.black,fontWeight: FontWeight.bold),),


                                                  ],),
                                                ],),
                                            ), )

                                        ],),),
                                  ),
                                ],);
                            }),
                      );

                  }
                },
              )
          )
        ],),
      ),
    );
  }
}
Future<String> _getPhoneNumber() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('PhoneNo') ?? ''; // Change 'PhoneNo' to your actual key
}
