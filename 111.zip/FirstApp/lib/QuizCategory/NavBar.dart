import 'package:firstapp/QuizCategory/Complete.dart';
import 'package:firstapp/QuizCategory/Live.dart';
import 'package:firstapp/QuizCategory/upcoming.dart';
import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:shared_preferences/shared_preferences.dart';

class QuizNav extends StatefulWidget {
  const QuizNav({super.key});
  @override
  State<QuizNav> createState() => _QuizNavState();
}
class _QuizNavState extends State<QuizNav> {
  int currentPage = 0;
  List<Widget> pages =  [
    FutureBuilder<String>(
      future: _getPhoneNumber(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return CircularProgressIndicator();
        } else if (snapshot.hasError) {
          return Text('Error: ${snapshot.error}');
        } else {
          return Live(phone: snapshot.data ?? '');
        }
      },
    ),
    FutureBuilder<String>(
      future: _getPhoneNumber(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return CircularProgressIndicator();
        } else if (snapshot.hasError) {
          return Text('Error: ${snapshot.error}');
        } else {
          return Booked(phone: snapshot.data ?? '');
        }
      },
    ),
    FutureBuilder<String>(
      future: _getPhoneNumber(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return CircularProgressIndicator();
        } else if (snapshot.hasError) {
          return Text('Error: ${snapshot.error}');
        } else {
          return Complete(phone: snapshot.data ?? '');
        }
      },
    ),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[currentPage],
      bottomNavigationBar: Padding(
        padding:  EdgeInsets.all(12),
        child: Container(
          height: 70,

          decoration: BoxDecoration(
              color: Colors.grey,
              borderRadius: BorderRadius.circular(13)),
          child: GNav(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            tabBorder: Border.all(color: Colors.white),
            activeColor: Colors.black,
            tabBackgroundColor: Colors.white,
            gap: 1,
            onTabChange: (index) => setState(() => currentPage = index),
            selectedIndex: currentPage,
            padding: const EdgeInsets.all(16),
            tabs: const [
              GButton(icon: Icons.home,textSize: 10,iconColor: Colors.white,iconSize: 15),
              GButton(icon: Icons.menu_book,textSize: 15,iconColor: Colors.white,iconSize: 15),
              GButton(icon: Icons.open_in_new,textSize: 15,iconColor: Colors.white,iconSize: 15),

            ],
          ),
        ),
      ),
    );
  }
}
Future<String> _getPhoneNumber() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('PhoneNo') ?? ''; // Change 'PhoneNo' to your actual key
}
