import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class Present {
  int? id;
  String? categ;
  String? subject;
  String? user;
  String? user_join;
  String? price;
  String?start_time;
  String? end_time;

  Present({required this.id,required this.start_time,required this.user_join,required this.end_time,required this.categ,required this.subject,required this.price});
  Present.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    user_join = json['user_join'];
    start_time = json['start_time'];
    categ = json['categ'];
    subject = json['subject'];
    user = json['user'];
    end_time = json['end_time'];
    price = json['price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_join'] = this.user_join;
    data['start_time'] = this.start_time;
    data['categ'] = this.categ;
    data['subject'] = this.subject;
    data['user'] = this.user;
    data['end_time'] = this.end_time;
    data['price'] = this.price;
    return data;
  }
}
class PresentQuiz extends StatefulWidget {
  const PresentQuiz({super.key});

  @override
  State<PresentQuiz> createState() => _PresentQuizState();
}

class _PresentQuizState extends State<PresentQuiz> {
  Future<List<Present>> present() async {
    final response = await http.get(Uri.parse('https://amazonboost.in/demo/twiz/quiz_user'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((countryData) {
        final msg = countryData['id'];
        final user_join = countryData['user_join'];
        final start_time = countryData['start_time'];
        final categ = countryData['categ'];
        final subject = countryData['subject'];
        final end_time = countryData['end_time'];
        final price = countryData['price'];
        return Present(id: msg,categ:categ,price: price,subject: subject, start_time: start_time,user_join: user_join,end_time:end_time);
      }).toList();
    } else {
      throw Exception('Failed to load countries');
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: FutureBuilder<List<Present>>(
          future: present(),
          builder: (context,snapshot)
          {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            }
            else{
              return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index)
                  {
                    final country = snapshot.data![index];
                    return Column(
                      children: [
                        Text(country.id.toString()),
                        Text(country.categ.toString()),
                        Text(country.subject.toString()),
                        Text(country.user_join.toString()),
                        Text(country.price.toString()),
                        Text(country.start_time.toString()),
                        Text(country.end_time.toString()),
                        Text(country.user_join.toString()),
                      ],
                    );
                  });
            }
          },
        )
    );
  }
}
