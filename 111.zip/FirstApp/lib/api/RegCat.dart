import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
class RegCa {
  int? id;

  String? cat;

  RegCa({required this.id,required this.cat});

  RegCa.fromJson(Map<String, dynamic> json) {
    id = json['id'];
   cat=json['categ'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;

    data['categ'] = this.cat;

    return data;
  }
}
class RegCats extends StatefulWidget {
  const RegCats({super.key});

  @override
  State<RegCats> createState() => _RegCatsState();
}

class _RegCatsState extends State<RegCats> {
  Future<List<RegCa>> SubCategory() async {
    final response = await http.get(Uri.parse('https://amazonboost.in/demo/twiz/categor'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((countryData) {
        final msg = countryData['id'];
        final status = countryData['categ'];
        return RegCa(id: msg,cat: status);
      }).toList();
    } else {
      throw Exception('Failed to load countries');
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: FutureBuilder<List<RegCa>>(
          future: SubCategory(),
          builder: (context,snapshot)
          {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            }
            else{
              return GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index)
                  {
                    final country = snapshot.data![index];
                    return Column(
                      children: [
                        Text(
                            country.cat.toString()
                        ),
                        Text(
                            country.id.toString()
                        ),

                      ],
                    );
                  });
            }
          },
        )
    );
  }
}
