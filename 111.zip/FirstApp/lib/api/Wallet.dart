import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class SubCat {
  int? id;
  int? status;
  String? createdAt;
  String? categ;
  String? subject;
  String? user;
  String? date;
  String? time;
  String? price;

  SubCat({required this.id,required this.status,required this.createdAt,required this.categ,required this.subject,required this.user,required this.date,required this.time,required this.price});

  SubCat.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    status = json['status'];
    createdAt = json['created_at'];
    categ = json['categ'];
    subject = json['subject'];
    user = json['user'];
    date = json['date'];
    time = json['time'];
    price = json['price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['status'] = this.status;
    data['created_at'] = this.createdAt;
    data['categ'] = this.categ;
    data['subject'] = this.subject;
    data['user'] = this.user;
    data['date'] = this.date;
    data['time'] = this.time;
    data['price'] = this.price;
    return data;
  }
}

class Api extends StatefulWidget {
  const Api({super.key});

  @override
  State<Api> createState() => _ApiState();
}
class _ApiState extends State<Api> {
  Future<List<SubCat>> SubCategory() async {
    final response = await http.get(Uri.parse('https://amazonboost.in/demo/twiz/apiquiz'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((countryData) {
        final msg = countryData['id'];
        final status = countryData['status'];
        final createdAt = countryData['created_at'];
        final categ = countryData['categ'];
        final subject = countryData['subject'];
        final user = countryData['user'];
        final date = countryData['date'];
        final time = countryData['time'];
        final price = countryData['price'];

        return SubCat(id: msg,categ:categ,createdAt: createdAt,price: price,status: status,subject: subject,time: time,user: user, date: date );
      }).toList();
    } else {
      throw Exception('Failed to load countries');
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: FutureBuilder<List<SubCat>>(
          future: SubCategory(),
          builder: (context,snapshot)
          {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            }
            else{
              return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index)
                  {
                    final country = snapshot.data![index];
                    return Column(
                      children: [
                        Text(
                          country.date.toString()
                        ),
                        Text(
                            country.id.toString()
                        ),
                        Text(
                            country.user.toString()
                        ),
                        Text(
                            country.createdAt.toString()
                        ),
                        Text(
                            country.categ.toString()
                        ),
                      ],
                    );
                  });

            }
          },
        )
    );
  }
}