/*
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class Timee {
  String? user;
  Timee({required this.user});
  Timee.fromJson(Map<String, dynamic> json) {

    user = json['user'];

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user'] = this.user;
    return data;
  }
}

class Time extends StatefulWidget {
  final String phone;
  final String id;
  const Time({super.key, required this.phone, required this.id});

  @override
  State<Time> createState() => _TimeState();
}

class _TimeState extends State<Time> {
  Future<List<Time>> fetchTimerData(List<String> selectedOptionsList, String questionText, int id) async {
    try {
      final response = await http.post(
        Uri.parse("https://amazonboost.in/demo/twiz/timer"),
        body: {
          'phone': widget.phone,
          'qu_id': id.toString(),
          'option': json.encode(selectedOptionsList),
        },
      );

      if (response.statusCode == 200) {
        List listResponse = json.decode(response.body);
        return listResponse.map((data) => Time.fromJson(data)).toList();
      } else {
        throw Exception('Unexpected error occurred!');
      }
    } catch (error) {
      print('Error fetching timer data: $error');
      throw error;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:   Container(
        height: 100,
        child: FutureBuilder<List<Time>>(
          future: fetchTimerData(selectedOptionsList, '', 0),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            } else {
              return ListView.builder(
                itemCount: snapshot.data!.length,
                itemBuilder: (context, index) {
                  final timeData = snapshot.data![index];
                  return Column(
                    children: [
                      Text('User: ${timeData.user}'),
                      // Add other Text widgets for other properties you want to display
                    ],
                  );
                },
              );
            }
          },
        ),
      ),
    );
  }
}
*/
