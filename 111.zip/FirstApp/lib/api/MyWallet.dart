import 'dart:convert';

import 'package:firstapp/api/QuizDetails.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../Payment/MyWallet.dart';

class Wallet {
  int? id;
  int? status;
  String? pincode;
  String? city;
  String? state;
  String? phone;
  String? email;
  String? name;
  String? wallet;

  Wallet({
    required this.id,
    required this.status,
    required this.pincode,
    required this.city,
    required this.state,
    required this.phone,
    required this.email,
    required this.name,
    required this.wallet,
  });

  factory Wallet.fromJson(Map<String, dynamic> json) {
    return Wallet(
      id: json['id'],
      status: json['status'],
      pincode: json['pincode'],
      city: json['city'],
      state: json['state'],
      phone: json['phone'],
      email: json['email'],
      name: json['name'],
      wallet: json['wallet'],
    );
  }
}

class WalletWidget extends StatefulWidget {
  final String wallet;
  const WalletWidget({Key? key, required this.wallet}) : super(key: key);

  @override
  State<WalletWidget> createState() => _WalletWidgetState();
}

class _WalletWidgetState extends State<WalletWidget> {
  Future<List<Wallet>> sendToSecondAPI(String phoneNumber) async {
    try {
      final response = await http.get(
        Uri.parse('https://amazonboost.in/demo/twiz/userdetail?phone=$phoneNumber'),
      );

      if (response.statusCode == 200) {
        final dynamic data = json.decode(response.body);

        if (data is List) {
          return data.map((countryData) {
            return Wallet.fromJson(countryData);
          }).toList();
        } else if (data is Map<String, dynamic>) {
          return [Wallet.fromJson(data)];
        } else {
          throw Exception('Invalid response format');
        }
      } else {
        print('API Response Status Code: ${response.statusCode}');
        print('API Response Body: ${response.body}');
        throw Exception('Failed to load data from API');
      }
    } catch (error) {
      print('Error: $error');
      throw Exception('Error: $error');
    }
  }

  Future<String> _getPhoneNumber() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('PhoneNo') ?? '';
  }

  Future<void> _saveWalletAmount(String walletAmount) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('WalletAmount', walletAmount);
  }
  Future<void> _currentBalance(String balance) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('CurrentBalance',balance);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.wallet),
      ),
      body: FutureBuilder<List<Wallet>>(
        future: sendToSecondAPI(widget.wallet),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          } else {
            // Get the first item from the list, assuming it's not empty
            final walletData = snapshot.data!.first;

            // Save wallet amount to SharedPreferences
            _saveWalletAmount(walletData.wallet.toString());

            return ListView.builder(
              itemCount: 1,
              itemBuilder: (context, index) {
                return Column(
                  children: [
                    Text(walletData.id.toString()),
                    Text(walletData.status.toString()),
                    Text(walletData.pincode.toString()),
                    Text(walletData.city.toString()),
                    Text(walletData.phone.toString()),
                    Text(walletData.email.toString()),
                    Text(walletData.name.toString()),
                    Text(walletData.wallet.toString()),
                    FutureBuilder<String>(
                      future: _getPhoneNumber(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return CircularProgressIndicator();
                        } else if (snapshot.hasError) {
                          return Text('Error: ${snapshot.error}');
                        } else {
                          return MyWallet(phone: walletData.wallet.toString(),);
                        }
                      },
                    ),
                    FutureBuilder<String>(
                      future: _getPhoneNumber(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return CircularProgressIndicator();
                        } else if (snapshot.hasError) {
                          return Text('Error: ${snapshot.error}');
                        } else {
                          return QD(phone: walletData.wallet.toString(),);
                        }
                      },
                    ),

                  ],
                );
              },
            );
          }
        },
      ),
    );
  }
}
