import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
class LangCa {
  int? id;
  String? lan;
  LangCa({required this.id,required this.lan});
  LangCa.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    lan=json['language'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['categ'] = this.lan;
    return data;
  }
}
class Langs extends StatefulWidget {
  const Langs({super.key});

  @override
  State<Langs> createState() => _LangsState();
}

class _LangsState extends State<Langs> {
  Future<List<LangCa>> lang() async {
    final response = await http.get(Uri.parse('https://amazonboost.in/demo/twiz/langua'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((countryData) {
        final msg = countryData['id'];
        final lan = countryData['language'];
        return LangCa(id: msg,lan: lan);
      }).toList();
    } else {
      throw Exception('Failed to load countries');
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: FutureBuilder<List<LangCa>>(
          future: lang(),
          builder: (context,snapshot)
          {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            }
            else{
              return GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index)
                  {
                    final country = snapshot.data![index];
                    return Column(
                      children: [
                        Text(
                            country.lan.toString()
                        ),
                        Text(
                            country.id.toString()
                        ),

                      ],
                    );
                  });
            }
          },
        )
    );
  }
}
