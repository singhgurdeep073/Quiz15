import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Add {
  String? phone;
  String? wallet;

  Add({
    required this.phone,
    required this.wallet,
  });

  factory Add.fromJson(Map<String, dynamic> json) {
    return Add(
      phone: json['phone'],
      wallet: json['wallet'],
    );
  }
}

class AddToWallet extends StatefulWidget {
  final String phone;
  const AddToWallet({Key? key,required this.phone}) : super(key: key);

  @override
  State<AddToWallet> createState() => _AddToWalletState();
}

class _AddToWalletState extends State<AddToWallet> {
  final formGlobalKey = GlobalKey<FormState>();
  final phoneController = TextEditingController();

  Future<List<Add>> sendAndFetchData(String phoneNumber, String wallet) async {
    try {
      // Send data to the API using POST method
      final sendResponse = await http.post(
        Uri.parse('https://amazonboost.in/demo/api/wallet.php'),
        body: {
          'phone': widget.phone,
          'wallet': phoneController.text,
        },
      );

      print('Send API Response Status Code: ${sendResponse.statusCode}');
      print('Send API Response Body: ${sendResponse.body}');

      if (sendResponse.statusCode == 200) {
        final dynamic data = json.decode(sendResponse.body);

        if (data is List) {
          // Handle the case where data is a list
          return data.map((countryData) {
            return Add.fromJson(countryData);
          }).toList();
        } else if (data is Map<String, dynamic>) {
          // Handle the case where data is an object
          return [Add.fromJson(data)];
        } else {
          throw Exception('Invalid response format');
        }
      } else {
        throw Exception('Failed to send data to API');
      }
    } catch (error) {
      print('Error: $error');
      throw Exception('Error: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Your Wallet'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: formGlobalKey,
          child: Column(
            children: [
              TextFormField(
                controller: phoneController,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue.shade400),
                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey),
                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                  ),
                  labelText: 'Phone',
                  labelStyle: TextStyle(
                    fontSize: 13.0,
                    color: Colors.blue,
                  ),
                  prefixIcon: Icon(
                    Icons.phone,
                    color: Colors.grey,
                  ),
                ),
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: () {
                  if (formGlobalKey.currentState?.validate() ?? false) {
                    sendAndFetchData(phoneController.text, 'Your Wallet')
                        .then((response) {
                      // Handle the API response, e.g., display data
                      print(response);
                    }).catchError((error) {
                      // Handle API call error
                      print('Error: $error');
                      // Show a snackbar or alert to inform the user about the error
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Failed to send data to API'),
                        ),
                      );
                    });
                  }
                },
                child: Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
