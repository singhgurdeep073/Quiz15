import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Details {
  int? total;

  int? right;
  int? wrong;

  Details({required this.total,required this.right,required this.wrong});

  Details.fromJson(Map<String, dynamic> json) {
    total = json['total'];
    right=json['right'];
    wrong=json['wrong'];

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['total'] = this.total;
    data['right'] = this.right;
    data['wrong'] = this.wrong;

    return data;
  }
}
class QD extends StatefulWidget {
  final String phone;
  const QD({super.key, required this.phone});

  @override
  State<QD> createState() => _QDState();
}

class _QDState extends State<QD> {
  Future<List<Details>> sendToSecondAPI(String phoneNumber) async {
    try {
      final response = await http.get(
        Uri.parse('https://amazonboost.in/demo/twiz/total?phone=$phoneNumber'),
      );

      if (response.statusCode == 200) {
        final dynamic data = json.decode(response.body);

        if (data is List) {
          return data.map((countryData) {
            return Details.fromJson(countryData);
          }).toList();
        } else if (data is Map<String, dynamic>) {
          return [Details.fromJson(data)];
        } else {
          throw Exception('Invalid response format');
        }
      } else {
        print('API Response Status Code: ${response.statusCode}');
        print('API Response Body: ${response.body}');
        throw Exception('Failed to load data from API');
      }
    } catch (error) {
      print('Error: $error');
      throw Exception('Error: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: FutureBuilder<List<Details>>(
          future: sendToSecondAPI(widget.phone),
          builder: (context,snapshot)
          {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            }
            else{
              return GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index)
                  {
                    final country = snapshot.data![index];
                    return Column(
                      children: [
                        Text(
                            country.total.toString()
                        ),
                        Text(
                            country.wrong.toString()
                        ),

                        Text(
                            country.right.toString()
                        ),

                      ],
                    );
                  });
            }
          },
        )
    );
  }
}
