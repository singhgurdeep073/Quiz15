import 'package:carousel_slider/carousel_slider.dart';
import 'package:firstapp/Home/RankPages/Catgorytab/Fix.dart';
import 'package:firstapp/Home/RankPages/Catgorytab/Fix.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../../../FirstScreen Pge/Home.dart';
import '../../../Quiz Page/Quiz Page.dart';
import '../../../api/ImageSider.dart';
import '../../../api/Wallet.dart';
import '../../Subcategory/SubCategory.dart';
import '../RankPage.dart';
import 'Fix.dart';
import 'Fix.dart';
class SliderCat{
  final String sliderid;
  final String sliderimg;
  SliderCat({required this.sliderid,required this.sliderimg});
  factory SliderCat.FromJson(Map<String,dynamic>json){
    return SliderCat(sliderid: json['id'].toString(),sliderimg: "https://amazonboost.in/demo/twiz/public/uploads/"+json['imgbanner']);
  }
}
class FixSlot{
  final String message;
  final String status;
  FixSlot({required this.message,required this.status});
  factory FixSlot.FromJson(Map<String,dynamic>json){
    return FixSlot(message: json['message'].toString(),status:json['status']);
  }
}
class Quiz {
  int? id;
  String? categ;
  String? subject;
  String? user_join;
  String? price;
  String?start_time;
  String? end_time;
   String?slot;
  Quiz({required this.slot,required this.id,required this.start_time,required this.user_join,required this.end_time,required this.categ,required this.subject,required this.price});
  Quiz.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    user_join = json['user_join'];
    start_time = json['start_time'];
    categ = json['categ'];
    subject = json['subject'];
    end_time = json['end_time'];
    price = json['price'];
    slot = json['slot'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_join'] = this.user_join;
    data['start_time'] = this.start_time;
    data['categ'] = this.categ;
    data['subject'] = this.subject;
    data['end_time'] = this.end_time;
    data['price'] = this.price;
    data['slot'] = this.slot;
    return data;
  }
}
class FixTab extends StatefulWidget {
final  String phone;
   FixTab({super.key,required this.phone});

  @override
  State<FixTab> createState() => _RealTAbState();
}
class _RealTAbState extends State<FixTab> {


  Future<List<SliderCat>>fetchDataImgPicker() async{
    var url=Uri.parse("https://amazonboost.in/demo/twiz/imgapibanner");
    final responce=await http.get(url);
    if(responce.statusCode==200){

      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => SliderCat.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }


  }
  Future<List<Quiz>> UpcomingQuiz(Mob) async {
    final response = await http.get(Uri.parse('http://amazonboost.in/demo/twiz/upcoming?phone=$Mob'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((countryData) {
        final msg = countryData['id'];
        final userJoin = countryData['user_join'];
        final startTime = countryData['start_time'];
        final categ = countryData['categ'];
        final subject = countryData['subject'];
        final endTime = countryData['end_time'];
        final price = countryData['price'];
        final slot = countryData['slot'];
        return Quiz(slot: slot,id: msg,categ:categ,price: price,subject: subject, start_time: startTime,user_join: userJoin,end_time:endTime  );
      }).toList();
    } else {
      throw Exception('Failed to load countries');
    }
  }
  Future<List<FixSlot>> fixSlot(quiz_id) async {
    final response = await http.get(Uri.parse('http://amazonboost.in/demo/twiz/upcoming?phone=$quiz_id'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((countryData) {
        final message = countryData['message'];
        final status = countryData['status'];


        return FixSlot(message:message,status:status );
      }).toList();
    } else {
      throw Exception('Failed to load countries');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Column(
        children: [
          Container(
            child: FutureBuilder<List<SliderCat>>(
                future: fetchDataImgPicker(),
                builder: (context,abc){
                  if(abc.hasData){
                    return
                      CarouselSlider.builder(
                        itemCount: abc.data!.length,
                        itemBuilder: (BuildContext context, int index, int realIndex) {
                          return Padding(
                            padding: const EdgeInsets.only(right:3,left: 3),
                            child: Image.network(abc.data![index].sliderimg, fit: BoxFit.cover),
                          );
                        },
                        options: CarouselOptions(
                          height: 100,
                          aspectRatio: 9 / 9,
                          viewportFraction: .8,
                          initialPage: 1,
                          enableInfiniteScroll: true,
                          autoPlay: true,
                        ),
                      );
                  }
                  else if(abc.hasError){
                    return Text(abc.error.toString());
                  }
                  return Center(child: SpinKitWaveSpinner(color: Colors.grey));
                }
                ),
          ),

          Row(mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Upcoming Quiz..',
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.normal,
                  ),
                ),
              ),
            ],
          ),
          Container(
            height: MediaQuery.of(context).size.height*.55,
            child: FutureBuilder<List<Quiz>>(
              future: UpcomingQuiz(widget.phone),
              builder: (context,snapshot)
              {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: SpinKitWaveSpinner(color: Colors.grey));
                } else if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                }
                else{
                  return
                    ListView.builder(
                        scrollDirection: Axis.vertical,
                        itemCount: snapshot.data!.length,
                        itemBuilder: (context, index)
                        {
                          final country = snapshot.data![index];
                          return Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  height: 133,width: 350,
                                  decoration: BoxDecoration(
                                      border: Border.all(color: Color(0xffe5e5e5),width: 1.50 ),
                                      borderRadius: BorderRadius.circular(10)
                                  ),
                                  child: Column(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(right: 8.0),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Container(height: 36,
                                              width: 110,
                                              decoration: BoxDecoration(
                                                  color: Color(0xffe3e7ed),
                                                  borderRadius: BorderRadius.only(bottomRight: Radius.circular(45),topLeft: Radius.circular(12))
                                              ),
                                              child: Center(
                                                child: Text(
                                                  country.categ.toString(),
                                                  style: GoogleFonts.poppins(
                                                    textStyle: Theme.of(context).textTheme.displayLarge,
                                                    fontSize: 18,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Text(
                                              country.subject.toString(),
                                              style: GoogleFonts.poppins(
                                                fontSize: 18,
                                                color: Color(0xff07a76b),
                                                fontWeight: FontWeight.w500,
                                                fontStyle: FontStyle.normal,
                                              ),
                                            ),
                                            Container(
                                              height:25,width: 120,
                                              decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(5),
                                                  color: Color(0xff07a76b),
                                                  border: Border.all(color:Color(0xff07a76b), )
                                              ),
                                              child:   Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text(
                                                    ' Competitions',
                                                    style: GoogleFonts.poppins(
                                                      fontSize: 12,
                                                      fontWeight: FontWeight.w400,
                                                      fontStyle: FontStyle.normal,
                                                    ),
                                                  ),
                                                  SizedBox(width:3),
                                                  Container(color: Colors.white,height: 25,width: 25,
                                                    child: Center(
                                                      child: Text(
                                                        country.user_join.toString(),
                                                        style: GoogleFonts.poppins(
                                                          fontSize: 18,
                                                          color: Colors.blue,
                                                          fontWeight: FontWeight.w700,
                                                          fontStyle: FontStyle.normal,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),),
                                          ],),
                                      ),
                                      SizedBox(
                                        height: 3,
                                      ),
                                      Divider(thickness: 0.50,),
                                      Padding(
                                        padding: const EdgeInsets.only(left: 8.0,right: 8),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text("Win Cash",style: TextStyle(fontSize: 16,color: Colors.green,fontWeight: FontWeight.bold),),
                                              Text("Prize Pool ",style: TextStyle(fontSize: 12,color: Colors.black,fontWeight: FontWeight.bold),),
                                            ],
                                          ),
                                            Text("₹"+country.price.toString(),style:TextStyle(fontSize: 18),),
                                            SizedBox(
                                              height: 30,
                                              width: 90,
                                              child: ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                                                  primary: country.slot == "1" ? Colors.red : Colors.green,
                                                  onPrimary: Colors.white,
                                                ),
                                                onPressed: () {
                                                  if (country.slot == "1") {
                                                    ScaffoldMessenger.of(context).showSnackBar(
                                                      SnackBar(
                                                        backgroundColor: Colors.red,
                                                        content: Text('Slot is already booked!'),
                                                        duration: Duration(seconds: 2),
                                                      ),
                                                    );
                                                  } else {
                                                    Get.to(
                                                      fullscreenDialog: true,
                                                      duration: Duration(milliseconds: 600),
                                                      transition: Transition.fadeIn,
                                                      Rank(
                                                        id: country.id,
                                                        categ: country.categ,
                                                        end_time: country.end_time,
                                                        price: country.price,
                                                        start_time: country.start_time,
                                                        subject: country.subject,
                                                        user_join: country.user_join,
                                                        phoneNo: widget.phone,
                                                      ),
                                                    );
                                                  }
                                                },
                                                child: Text(
                                                  'Join Now',
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                              ),
                                            ),

                                          ],
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(top: 10),
                                        height: 35,width: MediaQuery.of(context).size.width*1,
                                        decoration: BoxDecoration(
                                            color: Color(0xffd4d4d4),
                                            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(8),bottomRight: Radius.circular(8))),
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Row(children: [
                                                Icon(Icons.sign_language_sharp,color: Colors.blue,size: 17,),
                                                Text("English",style: TextStyle(fontSize: 12,color: Colors.black,fontWeight: FontWeight.bold),),


                                              ],),
                                              Row(children: [
                                                Icon(Icons.alarm_on,color: Colors.blue,size: 17,),
                                                Text(country.start_time.toString(),style: TextStyle(fontSize: 12,color: Colors.black,fontWeight: FontWeight.bold),),


                                              ],),
                                            ],),
                                        ), )

                                    ],),),
                              ),
                            ],);
                        });

                }
              },
            )
          )
        ],
      ),

    );
  }
}
