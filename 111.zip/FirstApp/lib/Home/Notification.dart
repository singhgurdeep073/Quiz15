import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';

import '../BottomNavigation.dart';

class Notifcate extends StatefulWidget {
  const Notifcate({super.key});

  @override
  State<Notifcate> createState() => _NotifcateState();
}

class _NotifcateState extends State<Notifcate> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
         backgroundColor:Colors.blueAccent,
title:   Text(
  'Notification',
  style: GoogleFonts.yaldevi(
    fontSize: 24,color: Colors.white,
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
  ),
),
          bottom: TabBar(
            unselectedLabelColor: Colors.black,
            indicatorSize: TabBarIndicatorSize.tab,
            indicator: BoxDecoration(

                gradient: LinearGradient(colors: [
                  Colors.blueAccent,
                  Colors.grey,

                ])),
            tabs: [

              Tab(
                child: Align(
                  alignment: Alignment.center,
                  child: Text("Information",style: TextStyle(
                      fontWeight: FontWeight.bold,fontSize: 15
                  ),),
                ),
              ),
              Tab(
                child: Align(
                  alignment: Alignment.center,
                  child: Text("Tips",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
                ),
              ),
            ]),),
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.white,
        body: LayoutBuilder(
          builder: (context, constraints) =>
              Column(
                children: [
                  SizedBox(
                    height:650,
                    child: Stack(
                      children: [
                        Positioned(
                            top: 0,
                            bottom: 520,
                            left: 0,
                            right: 0,
                            child: Container(height: 360,
                              color: Colors.blueAccent,
                              child: Column(children: [


                              ],),)
                        ),
                        Positioned(
                          top:10,
                          left: 0,
                          right: 0,
                          child: Padding(
                            padding: const EdgeInsets.all( 13.0),
                            child: Container(
                              height: 600,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                boxShadow: [BoxShadow(
                                  color: Colors.black,blurRadius: 5
                                )],
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    SizedBox(height: 50,),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Icon((Icons.notifications),color: Colors.grey,),
                                      Text("1 Message from Quiz 15.",style: TextStyle(fontSize: 18),),
                                    ],
                                  ),
                                  SizedBox(
                                      width: 300,
                                      child: Divider(thickness: 1.50,)),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Icon((Icons.notifications),color: Colors.grey,),
                                      Text("1 Message from Quiz 15.",style: TextStyle(fontSize: 18),),
                                    ],
                                  ),
                                  SizedBox(
                                      width: 300,
                                      child: Divider(thickness: 1.50,)),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Icon((Icons.notifications),color: Colors.grey,),
                                      Text("1 Message from Quiz 15.",style: TextStyle(fontSize: 18),),
                                    ],
                                  ),
                                  SizedBox(
                                      width: 300,
                                      child: Divider(thickness: 1.50,)),


                                ],),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
        ),
      ),
    );
  }
}
