import 'dart:async';


import 'package:firstapp/Payment/Payment.dart';
import 'package:firstapp/Home/Subcategory/Entry.dart';
import 'package:firstapp/Quiz%20Page/Quiz%20Page.dart';
import 'package:firstapp/Home/RankPages/RankPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../Payment/MyWallet.dart';
import '../../clock.dart';
import '../JoinPage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../RankPages/Winnings.dart';
import 'spot.dart';
class Pool extends StatefulWidget {
   Pool({super.key,});
  @override
  State<Pool> createState() => _PoolState();
}
class _PoolState extends State<Pool> {

  bool checkBox1=false;
  bool checkBox2=false;
  bool checkBox3=false;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar:  AppBar(
          iconTheme: IconThemeData(
            color: Colors.black, //change your color here
          ),
          backgroundColor: CupertinoColors.white,
            actions: [
              Container(
                margin: EdgeInsets.only(right: 100),
                height: 70,width: 70,
                decoration: BoxDecoration(
                    image: DecorationImage(image: AssetImage("images/logo.png"))
                ),
              ),
              IconButton(onPressed: (){
                Get.to(
                    fullscreenDialog: true,duration: Duration(milliseconds: 600),
                    transition:Transition.fadeIn,
                  FutureBuilder<String>(
                    future: _getPhoneNumber(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return CircularProgressIndicator();
                      } else if (snapshot.hasError) {
                        return Text('Error: ${snapshot.error}');
                      } else {
                        return MyWallet(phone: snapshot.data ?? '');
                      }
                    },
                  ),);
              }, icon:Icon( Icons.account_balance_wallet,color: Color(0xff259de0) ),),

            ],
            bottom: TabBar(
                labelColor:Color(0xff259de0) ,
                indicatorSize: TabBarIndicatorSize.label,
                indicatorColor:Color(0xff259de0),
                tabs: [
                  Tab(
                    child: Align(
                      alignment: Alignment.center,
                      child: Text("Entry", style: GoogleFonts.poppins(
                          fontSize: 11,
                          fontWeight: FontWeight.bold    ),),
                    ),
                  ),
                  Tab(
                    child: Align(
                      alignment: Alignment.center,
                      child: Text("SPOTS", style: GoogleFonts.poppins(
                          fontSize: 10,
                          fontWeight: FontWeight.bold    ),),
                    ),
                  ),
                  Tab(
                    child: Text("Price", style: GoogleFonts.poppins(
                        fontSize: 11,
                        fontWeight: FontWeight.bold),),
                  ),
                  Tab(
                    child: Text("WINNER", style: GoogleFonts.poppins(
                        fontSize: 10,
                        fontWeight: FontWeight.bold
                    ),),
                  ),
                  Tab(
                    child: CircleAvatar(
                        radius: 15,
                        backgroundColor: Colors.white,
                        child: IconButton(
                            onPressed: (){}, icon: Icon(Icons.filter_alt_rounded,size: 15,))),
                  )


                ]),

        ),
        body:   Container(

          height: MediaQuery.of(context).size.height*1,
          child: TabBarView(children: [
          Entry(),
            Spot(),
            Center(child: Text("Price")),
            Center(child: Text("Winner")),
            Center(child: Text("Filter")),

          ]),
        )),
    );
  }
}

Future<String> _getPhoneNumber() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('PhoneNo') ?? ''; // Change 'PhoneNo' to your actual key
}
