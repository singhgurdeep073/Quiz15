import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../QuizCategory/NavBar.dart';
import 'AlreadyJoin.dart';

class Spot extends StatefulWidget {
  const Spot({super.key});

  @override
  State<Spot> createState() => _SpotState();
}

class _SpotState extends State<Spot> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child:   Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child:Text(
                  'Spot',
                  style: GoogleFonts.yaldevi(
                    fontSize: 24,color: Colors.red,
                    fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.normal,
                  ),
                ),
              ),
              GestureDetector(
                onTap: (){
                  Get.to(
                      fullscreenDialog: true,
                      duration: const Duration(milliseconds: 600),
                      transition:Transition.fadeIn,
                      const QuizNav());
                },
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    'View All >',
                    style: GoogleFonts.yaldevi(
                      fontSize: 13,
                      fontWeight: FontWeight.w400,
                      fontStyle: FontStyle.normal,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Column(
            children: [
              GestureDetector(
                onTap: (){
                  Get.to(
                      fullscreenDialog: true,duration: const Duration(milliseconds: 600),
                      transition:Transition.fadeIn,
                      const AlredyJoin());
                },
                child: Container(height: 131,width: 350,
                  margin: const EdgeInsets.only(top: 4),
                  decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xffe5e5e5),width: 1.50 ),
                      borderRadius: BorderRadius.circular(10)
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(height: 36,
                            width: 120,
                            decoration: const BoxDecoration(
                                color: Color(0xffe3e7ed),
                                borderRadius: BorderRadius.only(bottomRight: Radius.circular(45),topLeft: Radius.circular(12))
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(left: 7.0,right: 1,top: 12),
                              child: Text(
                                "Prize Pool",
                                style: GoogleFonts.poppins(
                                  textStyle: Theme.of(context).textTheme.displayLarge,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w300,
                                ),
                              ),
                            ),
                          ),
                         GestureDetector(
                           onTap: (){
                             Get.snackbar(
                                 backgroundColor:  const Color(0xff07a76b),
                                 colorText: Colors.white,
                                 "Successfully Join","You will be notified when Quiz Start");
                           },
                           child: Padding(
                             padding: const EdgeInsets.only(right: 4.0,top: 4),
                             child: Container(height: 30,width: 80,
                             decoration: BoxDecoration(
                                 color: const Color(0xff07a76b),
                                 borderRadius: BorderRadius.circular(10)
                             ),child:  Center(
                               child:Text(
                                 'Join ',
                                 style: GoogleFonts.poppins(
                                   fontSize: 18,color: Colors.white,
                                   fontWeight: FontWeight.w700,
                                   fontStyle: FontStyle.normal,
                                 ),
                               ),
                             ),),
                           ),
                         )
                        ],),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                      height: 4,width: 300,
                      decoration: BoxDecoration( color: Colors.blue,
                        borderRadius: BorderRadius.circular(12)
                      ),
                      child: Row(
                        children: [
                          Container(
                            height: 4,width: 200,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                                Colors.grey.shade200,
                                Colors.red,])
                            ),
                          ),
                        ],
                      ),
                    ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0,right: 8,top: 7),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                          Text(
                            '4 Spot left',
                            style: GoogleFonts.yaldevi(
                              fontSize: 13,color: Colors.red,
                              fontWeight: FontWeight.bold,
                              fontStyle: FontStyle.normal,
                            ),
                          ),
                          Text(
                            '10 Spots',
                            style: GoogleFonts.yaldevi(
                              fontSize: 13,color: Colors.grey,
                              fontWeight: FontWeight.w400,
                              fontStyle: FontStyle.normal,
                            ),
                          ),
                        ],),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 15),
                        height: 41,width: 350,
                        decoration: const BoxDecoration(
                                color: Color(0xfff5f5f5),
                                borderRadius: BorderRadius.only(bottomRight: Radius.circular(10),
                                bottomLeft: Radius.circular(10)
                            )
                        ),child: const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(children: [
                            Icon( Icons.monetization_on, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '₹60,000',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.local_bar_outlined, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '57%',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.maps_ugc_sharp, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              'Upto 20',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                          ],),
                          Row(
                            children: [
                              Icon( Icons.check_circle_outline, ),
                              SizedBox(width: 6,),
                              Text(
                                'Guaranteed',
                                style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                              ),
                            ],
                          ),
                        ],
                      ),)
                    ],),),
              ),
              const SizedBox(height:9),
              GestureDetector(
                onTap: (){
                  Get.to(
                      fullscreenDialog: true,duration: const Duration(milliseconds: 600),
                      transition:Transition.fadeIn,
                      const AlredyJoin());
                },
                child: Container(height: 131,width: 350,
                  margin: const EdgeInsets.only(top: 4),
                  decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xffe5e5e5),width: 1.50 ),
                      borderRadius: BorderRadius.circular(10)
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(height: 36,
                            width: 120,

                            decoration: const BoxDecoration(
                                color: Color(0xffe3e7ed),
                                borderRadius: BorderRadius.only(bottomRight: Radius.circular(45),topLeft: Radius.circular(12))
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(left: 7.0,right: 1,top: 12),
                              child: Text(
                                "Prize Pool",
                                style: GoogleFonts.poppins(
                                  textStyle: Theme.of(context).textTheme.displayLarge,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w300,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 4.0,top: 4),
                            child: Container(height: 30,width: 80,
                              decoration: BoxDecoration(
                                  color: const Color(0xff07a76b),

                                  borderRadius: BorderRadius.circular(10)
                              ),child:  Center(
                                child:Text(
                                  'Join ',
                                  style: GoogleFonts.poppins(
                                    fontSize: 18,color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontStyle: FontStyle.normal,
                                  ),
                                ),
                              ),),
                          )
                        ],),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        height: 4,width: 300,

                        decoration: BoxDecoration( color: Colors.blue,
                            borderRadius: BorderRadius.circular(12)
                        ),
                        child: Row(
                          children: [
                            Container(
                              height: 4,width: 200,
                              decoration: BoxDecoration(
                                  gradient: LinearGradient(colors: [
                                    Colors.grey.shade200,

                                    Colors.red,])
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0,right: 8,top: 7),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '4 Spot left',
                              style: GoogleFonts.yaldevi(
                                fontSize: 13,color: Colors.red,
                                fontWeight: FontWeight.bold,
                                fontStyle: FontStyle.normal,
                              ),
                            ),
                            Text(
                              '10 Spots',
                              style: GoogleFonts.yaldevi(
                                fontSize: 13,color: Colors.grey,
                                fontWeight: FontWeight.w400,
                                fontStyle: FontStyle.normal,
                              ),
                            ),
                          ],),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 15),
                        height: 41,width: 350,
                        decoration: const BoxDecoration(
                            color: Color(0xfff5f5f5),
                            borderRadius: BorderRadius.only(bottomRight: Radius.circular(10),
                                bottomLeft: Radius.circular(10)
                            )
                        ),child: const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(children: [
                            Icon( Icons.monetization_on, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '₹60,000',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.local_bar_outlined, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '57%',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.maps_ugc_sharp, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              'Upto 20',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                          ],),
                          Row(
                            children: [
                              Icon( Icons.check_circle_outline, ),
                              SizedBox(width: 6,),
                              Text(
                                'Guaranteed',
                                style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                              ),
                            ],
                          ),



                        ],
                      ),)


                    ],),),
              ),
              const SizedBox(height:9),
              GestureDetector(
                onTap: (){
                  Get.to(
                      fullscreenDialog: true,duration: const Duration(milliseconds: 600),
                      transition:Transition.fadeIn,
                      const AlredyJoin());
                },
                child: Container(height: 131,width: 350,
                  margin: const EdgeInsets.only(top: 4),
                  decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xffe5e5e5),width: 1.50 ),
                      borderRadius: BorderRadius.circular(10)
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(height: 36,
                            width: 120,

                            decoration: const BoxDecoration(
                                color: Color(0xffe3e7ed),
                                borderRadius: BorderRadius.only(bottomRight: Radius.circular(45),topLeft: Radius.circular(12))
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(left: 7.0,right: 1,top: 12),
                              child: Text(
                                "Prize Pool",
                                style: GoogleFonts.poppins(
                                  textStyle: Theme.of(context).textTheme.displayLarge,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w300,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 4.0,top: 4),
                            child: Container(height: 30,width: 80,
                              decoration: BoxDecoration(
                                  color: const Color(0xff07a76b),

                                  borderRadius: BorderRadius.circular(10)
                              ),child:  Center(
                                child:Text(
                                  'Join ',
                                  style: GoogleFonts.poppins(
                                    fontSize: 18,color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontStyle: FontStyle.normal,
                                  ),
                                ),
                              ),),
                          )
                        ],),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        height: 4,width: 300,

                        decoration: BoxDecoration( color: Colors.blue,
                            borderRadius: BorderRadius.circular(12)
                        ),
                        child: Row(
                          children: [
                            Container(
                              height: 4,width: 200,
                              decoration: BoxDecoration(
                                  gradient: LinearGradient(colors: [
                                    Colors.grey.shade200,

                                    Colors.red,])
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0,right: 8,top: 7),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '4 Spot left',
                              style: GoogleFonts.yaldevi(
                                fontSize: 13,color: Colors.red,
                                fontWeight: FontWeight.bold,
                                fontStyle: FontStyle.normal,
                              ),
                            ),
                            Text(
                              '10 Spots',
                              style: GoogleFonts.yaldevi(
                                fontSize: 13,color: Colors.grey,
                                fontWeight: FontWeight.w400,
                                fontStyle: FontStyle.normal,
                              ),
                            ),
                          ],),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 15),
                        height: 41,width: 350,
                        decoration: const BoxDecoration(
                            color: Color(0xfff5f5f5),
                            borderRadius: BorderRadius.only(bottomRight: Radius.circular(10),
                                bottomLeft: Radius.circular(10)
                            )
                        ),child: const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(children: [
                            Icon( Icons.monetization_on, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '₹60,000',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.local_bar_outlined, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '57%',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.maps_ugc_sharp, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              'Upto 20',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                          ],),
                          Row(
                            children: [
                              Icon( Icons.check_circle_outline, ),
                              SizedBox(width: 6,),
                              Text(
                                'Guaranteed',
                                style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                              ),
                            ],
                          ),



                        ],
                      ),)


                    ],),),
              ),
              const SizedBox(height:9),
              GestureDetector(
                onTap: (){
                  Get.to(
                      fullscreenDialog: true,duration: const Duration(milliseconds: 600),
                      transition:Transition.fadeIn,
                      const AlredyJoin());
                },
                child: Container(height: 131,width: 350,
                  margin: const EdgeInsets.only(top: 4),
                  decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xffe5e5e5),width: 1.50 ),
                      borderRadius: BorderRadius.circular(10)
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(height: 36,
                            width: 120,

                            decoration: const BoxDecoration(
                                color: Color(0xffe3e7ed),
                                borderRadius: BorderRadius.only(bottomRight: Radius.circular(45),topLeft: Radius.circular(12))
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(left: 7.0,right: 1,top: 12),
                              child: Text(
                                "Prize Pool",
                                style: GoogleFonts.poppins(
                                  textStyle: Theme.of(context).textTheme.displayLarge,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w300,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 4.0,top: 4),
                            child: Container(height: 30,width: 80,
                              decoration: BoxDecoration(
                                  color: const Color(0xff07a76b),

                                  borderRadius: BorderRadius.circular(10)
                              ),child:  Center(
                                child:Text(
                                  'Join ',
                                  style: GoogleFonts.poppins(
                                    fontSize: 18,color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontStyle: FontStyle.normal,
                                  ),
                                ),
                              ),),
                          )
                        ],),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        height: 4,width: 300,

                        decoration: BoxDecoration( color: Colors.blue,
                            borderRadius: BorderRadius.circular(12)
                        ),
                        child: Row(
                          children: [
                            Container(
                              height: 4,width: 200,
                              decoration: BoxDecoration(
                                  gradient: LinearGradient(colors: [
                                    Colors.grey.shade200,

                                    Colors.red,])
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0,right: 8,top: 7),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '4 Spot left',
                              style: GoogleFonts.yaldevi(
                                fontSize: 13,color: Colors.red,
                                fontWeight: FontWeight.bold,
                                fontStyle: FontStyle.normal,
                              ),
                            ),
                            Text(
                              '10 Spots',
                              style: GoogleFonts.yaldevi(
                                fontSize: 13,color: Colors.grey,
                                fontWeight: FontWeight.w400,
                                fontStyle: FontStyle.normal,
                              ),
                            ),
                          ],),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 15),
                        height: 41,width: 350,
                        decoration: const BoxDecoration(
                            color: Color(0xfff5f5f5),
                            borderRadius: BorderRadius.only(bottomRight: Radius.circular(10),
                                bottomLeft: Radius.circular(10)
                            )
                        ),child: const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(children: [
                            Icon( Icons.monetization_on, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '₹60,000',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.local_bar_outlined, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '57%',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.maps_ugc_sharp, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              'Upto 20',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                          ],),
                          Row(
                            children: [
                              Icon( Icons.check_circle_outline, ),
                              SizedBox(width: 6,),
                              Text(
                                'Guaranteed',
                                style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                              ),
                            ],
                          ),



                        ],
                      ),)


                    ],),),
              ),
              const SizedBox(height:9),
              GestureDetector(
                onTap: (){
                  Get.to(
                      fullscreenDialog: true,duration: const Duration(milliseconds: 600),
                      transition:Transition.fadeIn,
                      const AlredyJoin());
                },
                child: Container(height: 131,width: 350,
                  margin: const EdgeInsets.only(top: 4),
                  decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xffe5e5e5),width: 1.50 ),
                      borderRadius: BorderRadius.circular(10)
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(height: 36,
                            width: 120,

                            decoration: const BoxDecoration(
                                color: Color(0xffe3e7ed),
                                borderRadius: BorderRadius.only(bottomRight: Radius.circular(45),topLeft: Radius.circular(12))
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(left: 7.0,right: 1,top: 12),
                              child: Text(
                                "Prize Pool",
                                style: GoogleFonts.poppins(
                                  textStyle: Theme.of(context).textTheme.displayLarge,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w300,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 4.0,top: 4),
                            child: Container(height: 30,width: 80,
                              decoration: BoxDecoration(
                                  color: const Color(0xff07a76b),

                                  borderRadius: BorderRadius.circular(10)
                              ),child:  Center(
                                child:Text(
                                  'Join ',
                                  style: GoogleFonts.poppins(
                                    fontSize: 18,color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontStyle: FontStyle.normal,
                                  ),
                                ),
                              ),),
                          )
                        ],),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        height: 4,width: 300,

                        decoration: BoxDecoration( color: Colors.blue,
                            borderRadius: BorderRadius.circular(12)
                        ),
                        child: Row(
                          children: [
                            Container(
                              height: 4,width: 200,
                              decoration: BoxDecoration(
                                  gradient: LinearGradient(colors: [
                                    Colors.grey.shade200,

                                    Colors.red,])
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0,right: 8,top: 7),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '4 Spot left',
                              style: GoogleFonts.yaldevi(
                                fontSize: 13,color: Colors.red,
                                fontWeight: FontWeight.bold,
                                fontStyle: FontStyle.normal,
                              ),
                            ),
                            Text(
                              '10 Spots',
                              style: GoogleFonts.yaldevi(
                                fontSize: 13,color: Colors.grey,
                                fontWeight: FontWeight.w400,
                                fontStyle: FontStyle.normal,
                              ),
                            ),
                          ],),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 15),
                        height: 41,width: 350,
                        decoration: const BoxDecoration(
                            color: Color(0xfff5f5f5),
                            borderRadius: BorderRadius.only(bottomRight: Radius.circular(10),
                                bottomLeft: Radius.circular(10)
                            )
                        ),child: const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(children: [
                            Icon( Icons.monetization_on, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '₹60,000',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.local_bar_outlined, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '57%',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.maps_ugc_sharp, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              'Upto 20',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                          ],),
                          Row(
                            children: [
                              Icon( Icons.check_circle_outline, ),
                              SizedBox(width: 6,),
                              Text(
                                'Guaranteed',
                                style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                              ),
                            ],
                          ),



                        ],
                      ),)


                    ],),),
              ),
              const SizedBox(height:9),
              GestureDetector(
                onTap: (){
                  Get.to(
                      fullscreenDialog: true,duration: const Duration(milliseconds: 600),
                      transition:Transition.fadeIn,
                      const AlredyJoin());
                },
                child: Container(height: 131,width: 350,
                  margin: const EdgeInsets.only(top: 4),
                  decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xffe5e5e5),width: 1.50 ),
                      borderRadius: BorderRadius.circular(10)
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(height: 36,
                            width: 120,

                            decoration: const BoxDecoration(
                                color: Color(0xffe3e7ed),
                                borderRadius: BorderRadius.only(bottomRight: Radius.circular(45),topLeft: Radius.circular(12))
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(left: 7.0,right: 1,top: 12),
                              child: Text(
                                "Prize Pool",
                                style: GoogleFonts.poppins(
                                  textStyle: Theme.of(context).textTheme.displayLarge,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w300,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 4.0,top: 4),
                            child: Container(height: 30,width: 80,
                              decoration: BoxDecoration(
                                  color: const Color(0xff07a76b),

                                  borderRadius: BorderRadius.circular(10)
                              ),child:  Center(
                                child:Text(
                                  'Join ',
                                  style: GoogleFonts.poppins(
                                    fontSize: 18,color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontStyle: FontStyle.normal,
                                  ),
                                ),
                              ),),
                          )
                        ],),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        height: 4,width: 300,

                        decoration: BoxDecoration( color: Colors.blue,
                            borderRadius: BorderRadius.circular(12)
                        ),
                        child: Row(
                          children: [
                            Container(
                              height: 4,width: 200,
                              decoration: BoxDecoration(
                                  gradient: LinearGradient(colors: [
                                    Colors.grey.shade200,

                                    Colors.red,])
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0,right: 8,top: 7),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '4 Spot left',
                              style: GoogleFonts.yaldevi(
                                fontSize: 13,color: Colors.red,
                                fontWeight: FontWeight.bold,
                                fontStyle: FontStyle.normal,
                              ),
                            ),
                            Text(
                              '10 Spots',
                              style: GoogleFonts.yaldevi(
                                fontSize: 13,color: Colors.grey,
                                fontWeight: FontWeight.w400,
                                fontStyle: FontStyle.normal,
                              ),
                            ),
                          ],),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 15),
                        height: 41,width: 350,
                        decoration: const BoxDecoration(
                            color: Color(0xfff5f5f5),
                            borderRadius: BorderRadius.only(bottomRight: Radius.circular(10),
                                bottomLeft: Radius.circular(10)
                            )
                        ),child: const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(children: [
                            Icon( Icons.monetization_on, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '₹60,000',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.local_bar_outlined, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              '57%',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                            SizedBox(width: 6,),
                            Icon( Icons.maps_ugc_sharp, size: 15,),
                            SizedBox(width: 6,),
                            Text(
                              'Upto 20',
                              style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                            ),
                          ],),
                          Row(
                            children: [
                              Icon( Icons.check_circle_outline, ),
                              SizedBox(width: 6,),
                              Text(
                                'Guaranteed',
                                style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                              ),
                            ],
                          ),



                        ],
                      ),)


                    ],),),
              ),
              const SizedBox(height:9),
            ],
          )
        ],),
      ),
    );
  }
}
