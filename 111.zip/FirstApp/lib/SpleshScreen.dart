import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import 'CategoryLangs.dart';
import 'Login&Reg/Login&Reg.dart';


class Splesh_Screen extends StatefulWidget {
  const Splesh_Screen({super.key});

  @override
  State<Splesh_Screen> createState() => _Splesh_ScreenState();
}

class _Splesh_ScreenState extends State<Splesh_Screen> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds:3),
            ()=> Get.to(
                fullscreenDialog: true,duration: Duration(seconds: 3),
        transition:Transition.fade,
        const LogReg()
           /*     Langs()*/

    ));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: MediaQuery.of(context).size.height*.40,),
          Center(child: Image.asset("images/logo.png",height: 100,)),
          SpinKitSpinningLines(
              duration: Duration(seconds: 2),
              color: Colors.grey),
        ],
      ),
    );
  }
}
