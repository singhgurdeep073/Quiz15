import 'dart:convert';
import 'dart:math';
import 'package:firstapp/Home/RankPages/Catgorytab/Fix.dart';
import 'package:firstapp/api/Add%20To%20Wallet.dart';
import 'package:firstapp/api/MyWallet.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../Quiz Page/Quiz Page.dart';
import '../SelectSubject.dart';
import 'Otpscreen.dart';
import 'Registation.dart';
import 'package:http/http.dart' as http;
class LogReg extends StatefulWidget {
  const LogReg({super.key});

  @override
  State<LogReg> createState() => _LogRegState();
}

class _LogRegState extends State<LogReg>{
  void _loginpush() {
    String _pass = phoneNo.text;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => WalletWidget(wallet:phoneNo.text),
      ),
    );
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => CategoryReg(pass:_pass),
      ),
    );

  }
  @override
  void initState2() {
    super.initState();
    // _loadSavedLoginData();
  }


  void wallet(){
  Navigator.pushReplacement(
  context,
  MaterialPageRoute(
  builder: (context) => WalletWidget(wallet:phoneNo.text),
  ),
  );
}

  /*void quiz(){
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => QuizPage(phone: phoneNo.text),
      ),
    );
  }*/
  bool checkBox1=false;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool value = false;
  int? verificationCode;
  var phoneNo = TextEditingController();
  void generateRandomCode() {
    Random random = Random();
    verificationCode = random.nextInt(9000) + 1000;
  }

  bool isValidPhoneNumber(String phoneNumber) {
    RegExp regex = RegExp(r'^\+91[1-9][0-9]{9}$');
    return regex.hasMatch(phoneNumber);
  }
  @override
  void dispose() {
    phoneNo.dispose();
    verificationCode = null;
    super.dispose();
  }
  Future<void> _login() async {
    final String p = phoneNo.text.trim();
    try {
      final response = await http.post(
        Uri.parse("https://amazonboost.in/demo/api/login.php"),
        body: {
          'phone': p,
      },
      );
          if(!checkBox1){
  Get.snackbar(
    backgroundColor: Colors.red,
    colorText: Colors.white,
    "Please Verify Your Age",
    "Your Age Must be 18+",
  );

}else{
      if (response.statusCode == 200) {

       if(phoneNo.text.isEmpty) {
         Get.snackbar(
             backgroundColor: Colors.red,
             colorText: Colors.white,
               "Login Failed", "Kindly Fill Your Number here.");
       }
       else{
        // Parse the response body as a JSON object
        final Map<String, dynamic> data = json.decode(response.body);

        // Check the status from the response
        if (data['status'] == 1) {
          // Successful login
          print(response.body);

          Get.snackbar(
              backgroundColor: Colors.green,
              colorText: Colors.white,

              "Mobile Number Verified","Fill OTP Send On Your's Number...");
          SharedPreferences prefs = await SharedPreferences.getInstance();
          await prefs.setString('PhoneNo',phoneNo.text);
          Navigator.push(context,MaterialPageRoute(builder: (context){
            return OtpScreen(verificationCode: verificationCode,mobileno: phoneNo.text,);
          }));
        /*Get.to(AddToWallet(phone: phoneNo.text,));*/
        } else {
          Get.snackbar(
              backgroundColor: Colors.red,
              colorText: Colors.white,
              "Login Failed","Mobile Number Not Valid");
        }
      }}
      else {
        // Failed login due to non-200 status code
        print('Login Failed');
        // Handle error or show a message to the user
      }
    } }catch (e) {
      // Handle network or server errors
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      body: Form(
        key:_formKey,
        child: LayoutBuilder(
          builder: (context, constraints) => SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  height: constraints.maxHeight *.6+70,
                  child: Stack(
                    children: [
                      Positioned(
                        top: 0,
                        bottom: 390,
                        left: 0,
                        right: 0,
                        child: Column(
                          children: [
                            Center(
                              child: Container(
                                width: 360,
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage("images/AppBar.jpeg"),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                margin: EdgeInsets.only(),
                                height: 100,
                                child: Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                                  children: [
                                    SizedBox(width: MediaQuery.of(context).size.width*.22,),
                                    Column(
                                      children: [
                                        SizedBox(
                                          height: 25,
                                        ),
                                        Text(
                                          "Login/Register",
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20,
                                          ),
                                        ),
                                        Text(
                                          "Let's get you started",
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                    IconButton(
                                      onPressed: () {},
                                      icon: Icon(
                                        Icons.help_outline,
                                        size: 30,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Positioned(
                        top: constraints.maxHeight * .1,
                        left: 0,
                        right: 0,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Container(
                            height: 300,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                    left: 14.0,
                                    right: 14,
                                    top: 14,
                                  ),
                                  child: TextFormField(
                                    maxLength: 10,
                                    controller: phoneNo,
                                    keyboardType: TextInputType.phone,
                                    decoration: InputDecoration(
                                      counterStyle: TextStyle(color: Colors.white),
                                      contentPadding: EdgeInsets.only(left: 18),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(color: Colors.white),
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(10.0),
                                        ),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(color: Colors.white),
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(10.0),
                                        ),
                                      ),
                                      labelText: 'Enter 10-digit phone number',
                                         labelStyle: TextStyle(
                                        fontSize: 15.0,
                                        color: Colors.black,
                                      ),
                                      filled: true,
                                      fillColor: Color(0xffe6e6e6),
                                    ),

                                  ),
                                ),
                                Row(
                                  children: [
                                    Checkbox(
                                      activeColor: Colors.black,
                                      checkColor: Colors.white,
                                      shape: RoundedRectangleBorder(),
                                      value: checkBox1,
                                      onChanged: (bool? newValue) {
                                        setState(() {
                                          checkBox1 = newValue!;
                                        });
                                      },
                                    ),
                                    Text("I certify that I am above 18 years"),
                                  ],
                                ),
                                InkWell(

                                  onTap: (){
                                    generateRandomCode();
                                    _login();
                                  },
                                  child: Container(
                                    height: 40,
                                    width: 350,
                                    decoration: BoxDecoration(
                                      color: Color(0xff109e38),
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    child: Center(
                                      child: Text(
                                        "Continue",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 17,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(height: 15,),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      "By continuing, I agree to Quiz 15 ",
                                      style: TextStyle(color: Colors.grey),
                                    ),
                                    Text(
                                      "T&C.",
                                      style:
                                      TextStyle(fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),

                                Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                    children: [
                                      GestureDetector(
                                        onTap:(){
                                          Get.to(
                                              fullscreenDialog: true,duration: Duration(milliseconds: 600),
                                              transition:Transition.fadeIn,
                                              Reg());
                                        },
                                        child: Text(
                                          "Register Here",
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black,

                                          ),
                                        ),
                                      ),
                                 /*     GestureDetector(
                                        onTap: () {
                                          Navigator.push(context,MaterialPageRoute(builder: (context){
                                            return WalletWidget(wallet: phoneNo.text);
                                          }));
                                        },
                                        child: Text(
                                          "Other login Options",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black,
                                            decoration: TextDecoration.underline,
                                            decorationColor: Colors.blue,
                                            decorationThickness: 3,
                                            decorationStyle:
                                            TextDecorationStyle.dashed,
                                          ),
                                        ),
                                      ),*/
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


