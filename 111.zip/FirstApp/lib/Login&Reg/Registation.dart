import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../CategoryLangs.dart';
import '../api/Reg.dart';
import 'Login&Reg.dart';

class Reg extends StatefulWidget {
  const Reg({super.key});

  @override
  State<Reg> createState() => _RegState();
}

class _RegState extends State<Reg> {
  final formGlobalKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final phoneno = TextEditingController();
  final email = TextEditingController();
  final State = TextEditingController();
  final city = TextEditingController();
  final pincode = TextEditingController();
  bool isVerifying = false;

  // List to store registered phone numbers
  List<String> registeredPhoneNumbers = ['1234567890', '9876543210']; // Replace with your actual data

  String? validateName(String value) {
    if (!value.isNotEmpty || !value[0].toUpperCase().contains(RegExp('[A-Z]'))) {
      return 'Name must start with a capital letter';
    }

    return null;
  }

  String? validatePhoneNumber(String value) {
    if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
      return 'Only numbers are allowed';
    }

    if (value.length != 10) {
      return 'Phone number must have 10 digits';
    }

    // Check if the phone number already exists locally
    if (registeredPhoneNumbers.contains(value)) {
      return 'Phone number already exists';
    }
    return null;
  }

  Future<void> SubCategory() async {
    if (formGlobalKey.currentState!.validate()) {
      if (!email.text.endsWith("@gmail.com")) {
        Get.snackbar(
          backgroundColor: Colors.blue[300],
          colorText: Colors.white,
          "Invalid Email",
          "Please enter a valid Gmail address",
        );
      } else {
        final response = await http.post(
          Uri.parse('https://amazonboost.in/demo/api/create.php'),
          body: {
            'name': name.text,
            'email': email.text,
            'phone': phoneno.text,
            'state': State.text,
            'city': city.text,
            'pincode': pincode.text,
          },
        );
        if (response.statusCode == 200) {
          final Map<String, dynamic> data = json.decode(response.body);
          final status = data['status'];

          if (status == 1) {
            // Registration successful
            if (name.text.isEmpty ||
                email.text.isEmpty ||
                phoneno.text.isEmpty ||
                State.text.isEmpty ||
                city.text.isEmpty ||
                pincode.text.isEmpty) {
              Get.snackbar(
                backgroundColor: Colors.blue[300],
                colorText: Colors.white,
                "Failed To Register",
                "Please Fill Complete Form",
              );
            } else {
              Get.to(
                fullscreenDialog: true,
                duration: Duration(milliseconds: 300),
                transition: Transition.fadeIn,
                LogReg(),
              );
              Get.snackbar(
                backgroundColor: Colors.blue[300],
                colorText: Colors.white,
                "Register Successfully",
                "Now Enter Phone No. For Login",
              );
              print(response.body);
            }
          } else if (status == 0) {
            // Mobile number already exists
            Get.snackbar(
              backgroundColor: Colors.red[300],
              colorText: Colors.white,
              "Mobile Number Exists",
              "Please use a different phone number",
            );
          } else {
            // Handle other statuses if needed
            throw Exception('Failed to register: Status $status');
          }
        } else {
          // Handle other HTTP status codes
          throw Exception('Failed to register. HTTP Status Code: ${response.statusCode}');
        }
      }
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      resizeToAvoidBottomInset: false,
      body: Form(
      key:formGlobalKey,
      child: Column(
        children: [
          SizedBox(
            height: 700,
            child: Stack(
              children: [
                Positioned(
                  top: 0,
                  bottom: 300,
                  left: 0,
                  right: 0,
                  child: Column(
                    children: [
                      Center(
                        child: Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage("images/AppBar.jpeg"),
                              fit: BoxFit.cover,
                            ),
                          ),
                          margin: EdgeInsets.only(),
                          height: 200,
                          child: Row(
                            mainAxisAlignment:
                            MainAxisAlignment.center,
                            children: [
                              Column(
                                children: [
                                  SizedBox(height: 50,),
                                  Text(
                                    "Register Now",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25,
                                    ),
                                  ),
                                  Text(
                                    "Let's get you started",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top:130,
                  left: 5,
                  right: 5,
                  child: Container(
                    height:500,
                    decoration: BoxDecoration(
                       color:Colors.white,
                      boxShadow: [BoxShadow(
                        color: Colors.black,blurRadius: 3,
                      )],
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                            left: 14.0,
                            right: 14,
                            top: 14,
                          ),
                          child: Column(
                            children: [
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: name,
                                validator: (value) => validateName(value!),
                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color:Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'Name',
                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue
                                  ),
                                  prefixIcon: Icon(
                                    Icons.account_circle,
                                    color: Colors.grey,
                                  ),


                                ),
                              ),
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: email,

                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color:Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'Email',

                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue
                                  ),
                                  prefixIcon: Icon(
                                    Icons.email,
                                    color: Colors.grey,
                                  ),


                                ),
                              ),
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: phoneno,
                                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                                validator: (value) => validatePhoneNumber(value!),

                                keyboardType: TextInputType.phone,
                                maxLength: 10,
                                decoration: InputDecoration(
                                  counterStyle: TextStyle(color: Colors.black,fontSize: 1),
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'Phone No.',
                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue,
                                  ),
                                  prefixIcon: Icon(
                                    Icons.call,
                                    color: Colors.grey,
                                  ),
                                ),
                              ),
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: State,
                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'State',
                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue,
                                  ),
                                  prefixIcon: Icon(
                                    Icons.flag,
                                    color: Colors.grey,
                                  ),
                                ),
                              ),
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: city,

                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'Your City',

                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue,
                                  ),
                                  prefixIcon: Icon(
                                    Icons.location_city_sharp,
                                    color: Colors.grey,
                                  ),


                                ),
                              ),
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: pincode,
                                maxLength: 10,
                                keyboardType: TextInputType.phone,
                                decoration: InputDecoration(
                                  counterStyle: TextStyle(color: Colors.white,fontSize: 1),
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'Pin Code',

                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue
                                  ),
                                  prefixIcon: Icon(
                                    Icons.pin_drop,
                                    color: Colors.grey,
                                  ),


                                ),
                              ),
                              SizedBox(
                                width: 250,
                                child: ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                      primary: Colors.green.shade400, // Background color
                                      onPrimary: Colors.white, // Text Color (Foreground color)
                                    ),
                                    onPressed: SubCategory, child: Text("Register",)),
                              ),
                            ],
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
    );
  }




}