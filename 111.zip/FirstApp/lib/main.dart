import 'package:auto_size_text/auto_size_text.dart';
import 'package:firstapp/SelectSubject.dart';
import 'package:firstapp/Login&Reg/Registation.dart';
import 'package:firstapp/api/Login.dart';
import 'package:firstapp/api/MyWallet.dart';
import 'package:firstapp/api/Reg.dart';
import 'package:firstapp/clock.dart';
import 'package:firstapp/timer.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'BottomNavigation.dart';

import 'Login&Reg/Login&Reg.dart';
import 'QuizCategory/upcoming.dart';
import 'api/Completed.dart';
import 'api/ImageSider.dart';
import 'api/Present.dart';
import 'api/UpcomingQuiz.dart';
import 'api/language.dart';
import 'CategoryLangs.dart';
import 'SpleshScreen.dart';
import 'api/Wallet.dart';
Future<void>main()async{
  WidgetsFlutterBinding().ensureFrameCallbacksRegistered();
  SharedPreferences prefs = await SharedPreferences.getInstance();
  var mobile= prefs.getString('PhoneNo');
  print(mobile);
  runApp(
      GetMaterialApp(

        debugShowCheckedModeBanner: false,
        home:mobile==null?Splesh_Screen():NavBar(),
      ));
}
/*void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
        primaryColor: Colors.blue
        ),
       home: LogReg()
    );
  }
}*/


