import 'package:firstapp/BottomNavigation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'SelectSubject.dart';

class Langs extends StatefulWidget {
  final String pass;
  Langs({super.key, required this.pass});
  @override
  _LangsState createState() => _LangsState();
}

class _LangsState extends State<Langs> {
  List<String> selectedLanguages = [];
  List<String> availableLanguages = [];

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.green,
        content: Text(message),
        duration: Duration(seconds: 2),
      ),
    );
  }

  Future<void> fetchLanguages() async {
    final response =
    await http.get(Uri.parse('https://amazonboost.in/demo/twiz/langua'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      setState(() {
        availableLanguages =
            data.map((language) => language['language']).toList().cast<String>();
      });
    } else {
      _showSnackBar('Failed to load languages.');
    }
  }

  Future<void> sendToSecondAPI(List<String> selectedLanguages) async {
    try {
      final response = await http.post(
        Uri.parse('https://amazonboost.in/demo/api/language.php'),
        body: {
          'langg': selectedLanguages.join(','), // Join selected languages
          'register_id': widget.pass,
        },
      );
      print('Raw Response: ${response.body}');
      if (response.statusCode == 200) {
        if (response.body.startsWith('{')) {
          final responseData = json.decode(response.body);
          if (responseData['status'] == 'success') {
            print('Data sent to second API successfully');
            print('Response Data: $responseData');
          } else {
            _showSnackBar(
                'Failed to send data to second API. ${responseData['status']}');
          }
        } else {
          Get.to(NavBar());
          _showSnackBar('Languages Select Successfully');
        }
      } else {
        _showSnackBar(
            'Failed to send data to second API. Status Code: ${response.statusCode}');
      }
    } catch (error, stackTrace) {
      print('Error sending data to second API: $error');
      print(stackTrace);
      _showSnackBar(
          'An error occurred while sending data to second API. $error');
    }
  }

  @override
  void initState() {
    super.initState();
    fetchLanguages();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            height: MediaQuery.of(context).size.height * 0.70,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  height: MediaQuery.of(context).size.height * .20,
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(12),
                      bottomLeft: Radius.circular(12),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      'Select your Languages',
                      style: GoogleFonts.poppins(
                        fontSize: 25,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 16),
                Container(
                  margin: EdgeInsets.only(left:MediaQuery.of(context).size.width * 0.10,),
                  width: MediaQuery.of(context).size.width * 0.80,
                  height: MediaQuery.of(context).size.height * 0.46,
                  decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      gradient: LinearGradient(colors: [
                        Colors.teal.shade50,
                        Colors.blue.shade100,
                        Colors.teal.shade50,

                      ]),
                      borderRadius: BorderRadius.circular(23)
                  ),
                  child: Column(
                    children: availableLanguages.map((language) {
                      return CheckboxListTile(
                        title: Text(
                          language,
                          style: GoogleFonts.roboto(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        value: selectedLanguages.contains(language),
                        onChanged: (bool? value) {
                          setState(() {
                            if (value != null) {
                              if (value) {
                                selectedLanguages.add(language);
                              } else {
                                selectedLanguages.remove(language);
                              }
                            }
                          });
                        },
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 24),
          SizedBox(
            height: 50,
            width: 300,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                primary: Colors.blue.shade200,
                onPrimary: Colors.black,
              ),
              onPressed: () {
                if (selectedLanguages.isEmpty) {
                  _showSnackBar('Please select at least one language.');
                } else {
                  // Send the selected data to the second API
                  sendToSecondAPI(selectedLanguages);
                  print('Selected Languages: $selectedLanguages');
                  print(widget.pass);
                }
              },
              child: Text('Select',style: GoogleFonts.poppins(
                fontSize: 20,color: Colors.white,
                fontWeight: FontWeight.w600,
              ),),
            ),
          ),
        ],
      ),
    );
  }
}
