import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';

class Shareandearn extends StatefulWidget {
  const Shareandearn({super.key});

  @override
  State<Shareandearn> createState() => _ShareandearnState();
}

class _ShareandearnState extends State<Shareandearn> {
  /*final Uri _url = Uri.parse('https://web.whatsapp.com/');

  Future<void> _launchUrl() async {
    if (!await launchUrl(_url)) {
      throw Exception('Could not launch ');
    }
  }*/
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(

        appBar: AppBar(
backgroundColor: Color(0xff5367fc),elevation: 0,
          title: Center(child: Text("Invite a friend & Earn rewards")),
          bottom: TabBar(

              labelColor:Colors.white ,
              indicatorSize: TabBarIndicatorSize.label,
              indicatorColor: Colors.white,
              tabs: [
                Tab(
                  child: Align(
                    alignment: Alignment.center,
                    child: Text("Share With Friends", style: GoogleFonts.poppins(
                        fontSize: 15,
                        fontWeight: FontWeight.bold    ),),
                  ),
                ),
                Tab(
                  child: Text("Shared list", style: GoogleFonts.poppins(
                      fontSize: 15,
                      fontWeight: FontWeight.bold    ),),
                ),


              ]),
          iconTheme: IconThemeData(color: Color(0xffffffff),size: 30,),
        ),

        body:
              Column(
                children: [
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height*.70,
                          child: Stack(
                            children: [
                              Positioned(
                                  top: 0,
                                  left: 0,
                                  right: 0,
                                  child: Container(height: 150,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(image: NetworkImage("https://wp-asset.groww.in/wp-content/uploads/2018/10/11094227/whatisgrowwreferral_-01-scaled.jpg"),fit: BoxFit.cover)
                                    ),
                                )
                              ),
                              Positioned(
                                top:100,
                                left: 0,
                                right: 0,
                                child: Padding(
                                  padding: const EdgeInsets.all( 13.0),
                                  child: Container(
                                    height: 460,
                                    child: Column(children: [
                                      Container(
                                        height: 60,
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(15),
                                        ),
                                      child:   Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                          children:[
                                        Text('Referral Code',style: GoogleFonts.poppins(
                                        fontSize: 20,fontWeight: FontWeight.w400,color: Colors.blueGrey,

                                      ),
                                        ),
                                        Text('1234567',style: GoogleFonts.poppins(
                                          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black,

                                        ),)]),),
                                      Padding(
                                        padding: const EdgeInsets.only(top: 28.0),
                                        child: Container(
                                          height: 260,width: 350,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            boxShadow: [BoxShadow(color: Colors.blueGrey,blurRadius: 0.50)],
                                            borderRadius: BorderRadius.circular(15),
                                          ),
                                          child:   Column(
                                              children:[
                                                SizedBox(height: 50,),
                                                Text('Share with your 11 friends.',style: GoogleFonts.poppins(
                                                  fontSize: 18,fontWeight: FontWeight.bold,color: Colors.black,
                                                ),),
                                                SizedBox(height: 20,),
                                              Text('Rs.99*',style: GoogleFonts.poppins(
                                                fontSize: 28,fontWeight: FontWeight.bold,color: Colors.grey,
                                              ),),
                                                Padding(
                                                  padding: const EdgeInsets.only(top: 28.0),
                                                  child: GestureDetector(
                                                 /*   onTap: _launchUrl,*/
                                                    child: Container(
                                                      height: 50,
                                                      width: 300,
                                                      decoration: BoxDecoration(
                                                        color: Colors.green[900],

                                                        borderRadius: BorderRadius.circular(15),
                                                      ),child:   Center(
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.center,
                                                          children: [
                                                            Text("Invite Now",style: GoogleFonts.poppins(
                                                            fontSize: 18,fontWeight: FontWeight.bold,color: Colors.white,),),
                                                          Icon(Icons.call,color: Colors.white,)
                                                          ],
                                                        ),
                                                      ) ,
                                                    ),
                                                  ),
                                                )
                                             ]),),
                                      ),
                                    ],),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                ],
              ),

      ),
    );
  }
}
