import 'dart:async';
import 'dart:io';
import 'package:firstapp/Home/Notification.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../Payment/MyWallet.dart';
import '../SpleshScreen.dart';
import '../Home/RankPages/Catgorytab/Real.dart';
import '../Home/RankPages/Catgorytab/Fix.dart';
import '../api/MyWallet.dart';
import '../api/QuizDetails.dart';

class Imageslider {
  final String img;
  Imageslider({required this.img});
}
class HomePage extends StatefulWidget {
  HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  File? _selectedImage;
  Future<void> _pickImage() async {
    final pickedImage =
    await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      setState(() {
        _selectedImage = File(pickedImage.path);
      });
    }
  }
  Future<void> clearSession() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('PhoneNo');
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Splesh_Screen()),
    );
  }

  Future<void> setLoggedIn() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('isLoggedIn', true);
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        key: _scaffoldKey,
        appBar: AppBar(
          backgroundColor: CupertinoColors.white,
          leading: Padding(
            padding: const EdgeInsets.all(8.0),
            child: GestureDetector(
              onTap: () {
                _scaffoldKey.currentState?.openDrawer();
              },
              child: CircleAvatar(
                child: _selectedImage != null
                    ? CircleAvatar(
                  backgroundImage: FileImage(_selectedImage!),
                )
                    : Icon(Icons.person, color: Colors.white),
              ),
            ),
          ),
          actions: [
            Container(
              margin: EdgeInsets.only(right: 50),
              height: 70,
              width: 70,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("images/logo.png"))),
            ),
            IconButton(
                onPressed: () {
                  Get.to(
                    fullscreenDialog: true,
                    duration: Duration(milliseconds: 600),
                    transition: Transition.fadeIn,
                    FutureBuilder<String>(
                      future: _getPhoneNumber(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return CircularProgressIndicator();
                        } else if (snapshot.hasError) {
                          return Text('Error: ${snapshot.error}');
                        } else {
                          return MyWallet(phone: snapshot.data ?? '');
                        }
                      },
                    ),
                  );
                },
                icon: Icon(Icons.account_balance_wallet,
                    color: Color(0xff259de0))),
            IconButton(
                onPressed: () {
                  Get.to(
                    fullscreenDialog: true,
                    duration: Duration(milliseconds: 600),
                    transition: Transition.fadeIn,
                    Notifcate(),
                  );
                },
                icon: Icon(Icons.notifications_none,
                    color: Color(0xff259de0))),
          ],
          iconTheme: IconThemeData(color: Color(0xff259de0), size: 30),
          bottom: TabBar(
            labelColor: Colors.blue,
            indicatorSize: TabBarIndicatorSize.label,
            indicatorColor: Colors.grey,
            tabs: [
              Tab(
                child: Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Fix Time",
                    style: GoogleFonts.poppins(
                        fontSize: 15, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              Tab(
                child: Text(
                  "Real Time",
                  style: GoogleFonts.poppins(
                      fontSize: 15, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
        drawer: Drawer(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                    height: MediaQuery.of(context).size.height*.13,
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              InkWell(
                                onTap: _pickImage,
                                child: CircleAvatar(
                                  radius: 25,
                                  backgroundColor: Colors.grey,
                                  backgroundImage: _selectedImage != null
                                      ? FileImage(_selectedImage!)
                                      : null,
                                ),
                              ),
                              Container(
                                height: MediaQuery.of(context).size.height*.6,
                                width: MediaQuery.of(context).size.width*.50,
                                child: FutureBuilder<List<Wallet>>(
                                  future: sendToSecondAPI(),
                                  builder: (context, snapshot) {
                                    if (snapshot.connectionState == ConnectionState.waiting) {
                                      return SpinKitThreeBounce(
                                          size: 20,
                                          color: Colors.grey);
                                    } else if (snapshot.hasError) {
                                      return Center(
                                        child: Text('Error: ${snapshot.error}'),
                                      );
                                    } else {
                                      final walletData = snapshot.data!.first;
                                      _saveWalletAmount(
                                          walletData.wallet.toString());

                                      return Container(
                                        height: MediaQuery.of(context).size.height*.8,
                                        width: 100,
                                        child: ListView.builder(
                                          itemCount: 1,
                                           scrollDirection: Axis.horizontal,
                                          itemBuilder: (context, index) {
                                            return Column(
                                              mainAxisAlignment: MainAxisAlignment.end,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [

                                                Text(walletData.name.toString(), style: GoogleFonts.poppins(
                                                fontSize: 20,

                                                  fontWeight: FontWeight.w500,
                                                ),),
                                                Text(walletData.email.toString(), style: GoogleFonts.poppins(
                                                  fontSize: 15,

                                                  fontWeight: FontWeight.w500,
                                                ),),

                                                FutureBuilder<String>(
                                                  future: _getPhoneNumber(),
                                                  builder: (context, snapshot) {
                                                    if (snapshot.connectionState ==
                                                        ConnectionState.waiting) {
                                                      return CircularProgressIndicator();
                                                    } else if (snapshot.hasError) {
                                                      return Text(
                                                          'Error: ${snapshot.error}');
                                                    } else {
                                                      return MyWallet(
                                                        phone: walletData.wallet
                                                            .toString(),
                                                      );
                                                    }
                                                  },
                                                ),

                                              ],
                                            );
                                          },
                                        ),
                                      );
                                    }
                                  },
                                ),
                              ),
                            ],
                          ),
                          IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: Icon(Icons.arrow_right,
                                  size: 40, color: Colors.grey))
                        ],
                      ),
                    )),
                ListTile(
                    onTap: () {
                      Get.to(
                          fullscreenDialog: true,
                          duration: Duration(milliseconds: 600),
                          transition: Transition.fadeIn,
                          Notifcate());
                    },
                    leading: Icon(Icons.notifications),
                    title: Text(
                      'Notifications',
                    ),
                    trailing: Container(
                      height: 30,
                      width: 30,
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(12)),
                      child: Center(
                          child: Text(
                            "0",
                            style: TextStyle(color: Colors.white, fontSize: 14),
                          )),
                    )),
                ListTile(

                    leading: Icon(
                      Icons.account_balance_wallet,
                      color: Colors.black,
                    ),
                    title: Text(
                      'Wallet',
                    ),
                    trailing: Text(
                      "₹677.00",
                      style: TextStyle(color: Colors.black, fontSize: 14),
                    )),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      height: 40,
                      width: 130,
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(12)),
                      child: Center(
                          child: Text(
                            "Deposit",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold),
                          )),
                    ),
                    Container(
                      height: 40,
                      width: 130,
                      decoration: BoxDecoration(
                          color: Color(0xff4cb050),
                          borderRadius: BorderRadius.circular(12)),
                      child: Center(
                          child: Text(
                            "Withdraw",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold),
                          )),
                    )
                  ],
                ),
                Card(
                  color: Color(0xfffefefe),
                  child: ListTile(
                    leading: Icon(Icons.account_balance_wallet, color: Colors.grey),
                    title: Text(
                      'twiz15 Marking System',
                      style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Card(
                  color: Color(0xfffefefe),
                  child: ListTile(
                    leading: Icon(Icons.question_mark_outlined, color: Colors.grey),
                    title: Text(
                      'How to Participate?',
                      style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Card(
                  color: Color(0xfffefefe),
                  child: ListTile(
                    leading: Icon(Icons.mail, color: Colors.grey),
                    title: Text(
                      'Support & FAQs',
                      style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Card(
                  color: Color(0xfffefefe),
                  child: ListTile(
                    leading: Icon(Icons.share, color: Colors.grey),
                    title: Text(
                      'Share App',
                      style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        "Legal",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.grey,
                            fontSize: 16),
                      ),
                    ),
                  ],
                ),
                Card(
                  color: Color(0xfffefefe),
                  child: ListTile(
                    leading: Text(
                      'Privacy Policy',
                      style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
                Card(
                  color: Color(0xfffefefe),
                  child: ListTile(
                    leading: Text(
                      'Terms & Conditions',
                      style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 2.0, left: 5, right: 5, bottom: 6),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: () {
                          clearSession();
                        },
                        child: Container(
                          height: 40,
                          width: 130,
                          decoration: BoxDecoration(
                              color: Color(0xff4cb050),
                              borderRadius: BorderRadius.circular(12)),
                          child: Center(
                              child: Text(
                                "LogOut",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold),
                              )),
                        ),
                      ),
                      Text("v1.0.6")
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        body: Container(
          height: MediaQuery.of(context).size.height * 1,
          child: TabBarView(
            children: [
              FutureBuilder<String>(
                future: _getPhoneNumber(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  } else {
                    return FixTab(phone: snapshot.data ?? '');
                  }
                },
              ),
              RealTab(),
            ],
          ),
        ),
      ),
    );
  }

  Future<List<Wallet>> sendToSecondAPI() async {
    try {
      String phoneNumber = await _getPhoneNumber();

      final response = await http.get(
        Uri.parse('https://amazonboost.in/demo/twiz/userdetail?phone=$phoneNumber'),
      );

      if (response.statusCode == 200) {
        final dynamic data = json.decode(response.body);

        if (data is List) {
          return data.map((countryData) {
            return Wallet.fromJson(countryData);
          }).toList();
        } else if (data is Map<String, dynamic>) {
          return [Wallet.fromJson(data)];
        } else {
          throw Exception('Invalid response format');
        }
      } else {
        print('API Response Status Code: ${response.statusCode}');
        print('API Response Body: ${response.body}');
        throw Exception('Failed to load data from API');
      }
    } catch (error) {
      print('Error: $error');
      throw Exception('Error: $error');
    }
  }

  Future<String> _getPhoneNumber() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('PhoneNo') ?? '';
  }

  Future<void> _saveWalletAmount(String amount) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('WalletAmount', amount);
  }
}
