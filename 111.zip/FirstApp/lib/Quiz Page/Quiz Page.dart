import 'dart:async';
import 'package:firstapp/Home/JoinPage.dart';
import 'package:firstapp/Quiz%20Page/Submit.dart';
import 'package:firstapp/QuizCategory/NavBar.dart';
import 'package:firstapp/clock.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:quiver/async.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../QuizCategory/Complete.dart';
import '../api/question.dart';
import '../FirstScreen Pge/Home.dart';
import '../Home/Subcategory/SubCategory.dart';

class QuizPage extends StatefulWidget {
  final String phone;
  final String id;
  QuizPage({Key? key, required this.phone, required this.id}) : super(key: key);

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  late Timer _timer;
  int _secondsRemaining = 15 * 60;
  PageController _con = PageController();
  int selectedOption = -1;
  List<String> selectedOptionsList = [];

  void startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_secondsRemaining > 0) {
        setState(() {
          _secondsRemaining--;
        });
      } else {
        _timer.cancel();
      }
    });
  }

  void _goToNextPage(List<Quest> questions) {
    if (selectedOptionsList.isNotEmpty) {
      _con.nextPage(duration: Duration(seconds: 1), curve: Curves.easeInOut);
      if (_con.page != null && _con.page! < questions.length - 1) {
        // Pass the question text and ID to the second API
        sendToSecondAPI(selectedOptionsList, questions[_con.page!.toInt()].ques, questions[_con.page!.toInt()].id);
      }
    } else {
      _showSnackBar('Please select at least one option before proceeding.');
    }
  }

  Future<List<Quest>> fetchDataQuiz() async {
    final response = await http.get(
        Uri.parse("https://amazonboost.in/demo/twiz/question_view_question"));
    if (response.statusCode == 200) {
      List listResponse = json.decode(response.body);
      return listResponse.map((data) => Quest.FromJson(data)).toList();
    } else {
      throw Exception('Unexpected error occurred!');
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.green,
        content: Text(message),
        duration: Duration(seconds: 2),
      ),
    );
  }

  Future<void> sendToSecondAPI(List<String> selectedCategories, String questionText, int id) async {
    try {
      final response = await http.post(
        Uri.parse('https://amazonboost.in/demo/api/quizpost.php'),
        body: {
          'phone': widget.phone,
          'qu_id': id.toString(),
          'option': selectedOption.toString(),
        },
      );
      print(id.toString()); // Print the 'id' parameter instead of 'widget.id'
      print('Raw Response: ${response.body}');
      if (response.statusCode == 200) {
        if (response.body.startsWith('{')) {
          final responseData = json.decode(response.body);
          if (responseData['status'] == 'success') {
            _showSnackBar('Invalid response format from second API.');
            print('Response Data: $responseData');
          } else {
            print('Data to second API. ${responseData['status']}');
          }
        } else {
          print('Data sent to second API successfully');
        }
      } else {
        print('Send data to second API. Status Code: ${response.statusCode}');
      }
    } catch (error, stackTrace) {
      print('Error sending data to second API: $error');
      print(stackTrace);
      _showSnackBar('An error occurred while sending data to second API. $error');
    }
  }

  void _pop() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        content: Text(
          'Are You Sure to Quit Quiz',
          style: GoogleFonts.poppins(
            fontSize: 15,
            color: Colors.black,
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'No',
              style: GoogleFonts.poppins(fontSize: 15, color: Colors.black),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              primary: Colors.orange, // Background color
              onPrimary: Colors.black, // Text Color (Foreground color)
            ),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (context) => Pool())),
            child: Text(
              'Yes',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.w300,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void Submit() {
    if (selectedOptionsList.isNotEmpty) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          content: Container(
            height: MediaQuery.of(context).size.height*.7,
            child: Column(
              children: [
                Text(
                  'Are You Sure to Quit Quiz...',
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w300,
                    color: Colors.black,
                  ),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                primary: Colors.grey, // Background color
                onPrimary: Colors.black, // Text Color (Foreground color)
              ),
              onPressed: () {
                Navigator.of(context).pop();
                if (selectedOptionsList.isNotEmpty) {
                  sendToSecondAPI(selectedOptionsList, '', 0); // Replace 0 with the actual ID
                }
              },
              child: Text(
                'Continue',
                style: GoogleFonts.poppins(
                  fontSize: 15,
                  fontWeight: FontWeight.w300,
                  color: Colors.white,
                ),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                primary: Colors.amber, // Background color
                onPrimary: Colors.black, // Text Color (Foreground color)
              ),
              onPressed: () {
                Get.to(
                  fullscreenDialog: true,
                  duration: Duration(milliseconds: 800),
                  transition: Transition.fadeIn,
                  FinishQuiz(phoneno: widget.phone,),
                );
              },
              child: Text(
                'Quit',
                style: GoogleFonts.poppins(
                  fontSize: 15,
                  fontWeight: FontWeight.w300,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      );
    } else {
      _showSnackBar('Please select at least one option before submitting.');
    }
  }
  @override
  Widget build(BuildContext context) {
    int minutes = _secondsRemaining ~/ 60;
    int seconds = _secondsRemaining % 60;

    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Scaffold(
        backgroundColor: Color(0xff259de0),
        body: Column(
          children: [
            SizedBox(height: 30,),
            Center(
              child: Container(
                height: MediaQuery.of(context).size.height * .80,
                child: FutureBuilder<List<Quest>>(
                  future: fetchDataQuiz(),
                  builder: (context, abc) {
                    if (abc.hasData) {
                      return Container(
                        height: MediaQuery.of(context).size.height * 1,
                        child: PageView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          controller: _con,
                          itemCount: abc.data!.length,
                          itemBuilder: (context, len) {
                            return Column(
                              children: [
                                SizedBox(height: 20),
                                Center(
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Container(
                                      child: Column(
                                        children: [
                                          GestureDetector(
                                            onTap: () {
                                              Get.to(QuizNav());
                                            },
                                            child: Container(
                                              // ... (existing container properties)
                                            ),
                                          ),
                                          Column(
                                            children: [
                                              Container(
                                                height: MediaQuery.of(context).size.height * .10,
                                                width: MediaQuery.of(context).size.width * .90,
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(12),
                                                  color: Colors.white,
                                                ),
                                                child: Center(
                                                  child: Padding(
                                                    padding: const EdgeInsets.all(8.0),
                                                    child: AutoSizeText.rich(
                                                      TextSpan(text: abc.data![len].ques),
                                                      style: TextStyle(fontSize: 16),
                                                      minFontSize: 5,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                '$minutes:${seconds < 10 ? '0' : ''}$seconds',
                                                style: TextStyle(
                                                  fontSize: 25,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.white,
                                                ),
                                              ),
                                              buildOptionButton(abc.data![len].opt1, 0),
                                              buildOptionButton(abc.data![len].opt2, 1),
                                              buildOptionButton(abc.data![len].opt3, 2),
                                              buildOptionButton(abc.data![len].opt4, 3),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                            children: [
                                              SizedBox(
                                                width: MediaQuery.of(context).size.width * .50,
                                              ),
                                              SizedBox(
                                                width: 100,
                                                child: ElevatedButton(
                                                  style: ElevatedButton.styleFrom(
                                                    shape: RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.circular(12)),
                                                    primary: Colors.white, // Background color
                                                    onPrimary: Colors.blue, // Text Color (Foreground color)
                                                  ),
                                                  onLongPress: startTimer,
                                                  onPressed: () => _goToNextPage(abc.data!),
                                                  child: Text(
                                                    'Next',
                                                    style: GoogleFonts.poppins(
                                                      fontSize: 15,
                                                      fontWeight: FontWeight.w300,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      );
                    } else if (abc.hasError) {
                      return Text(abc.error.toString());
                    }
                    return Center(
                      child: SpinKitWaveSpinner(color: Colors.grey),
                    );
                  },
                ),
              ),
            ),
            SizedBox(
              width: 150,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  primary: Colors.white, // Background color
                  onPrimary: Colors.black, // Text Color (Foreground color)
                ),
                onPressed: Submit,
                child: Text(
                  'Submit',
                  style: GoogleFonts.poppins(
                    fontSize: 15,
                    fontWeight: FontWeight.w400,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildOptionButton(String option, int index) {
    int optionValue = index + 1;

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: SizedBox(
        width: 300,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
            primary: Colors.orange.shade200, // Background color
            onPrimary: Colors.white, // Text Color (Foreground color)
          ),
          onPressed: () {
            setState(() {
              selectedOption = optionValue;
            });
            _onOptionSelected(selectedOption, option);
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Radio<int>(
                activeColor: Colors.black,
                value: optionValue,
                groupValue: selectedOption,
                onChanged: (int? value) {
                  setState(() {
                    selectedOption = value!;
                  });
                  _onOptionSelected(selectedOption, option);
                },
              ),
              Text(
                option,
                style: GoogleFonts.poppins(
                  fontSize: 15,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onOptionSelected(int selectedOption, String optionText) {
    if (selectedOption != -1) {
      setState(() {
        selectedOptionsList.add(optionText);
      });

      // Print the selected option
      print('Selected Option: $selectedOption');

      // Print the updated list of selected options
      print('Updated Selected Options List: $selectedOptionsList');
    }
  }

  Future<String> _phone(int id) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(id.toString()) ?? '';
  }
}