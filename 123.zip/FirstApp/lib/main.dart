import 'package:auto_size_text/auto_size_text.dart';
import 'package:firstapp/clock.dart';
import 'package:firstapp/timer.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'BottomNavigation.dart';

import 'First Category.dart';
import 'SpleshScreen.dart';
Future<void>main()async{
  WidgetsFlutterBinding().ensureFrameCallbacksRegistered();
  SharedPreferences prefs = await SharedPreferences.getInstance();
  var mobile= prefs.getString('PhoneNo');
  print(mobile);
  runApp(
      GetMaterialApp(

        debugShowCheckedModeBanner: false,
        home: mobile==null?Splesh_Screen():NavBar(),
      ));
}
/*void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
        primaryColor: Colors.blue
        ),
       home: Cat(),
    );
  }
}*/



