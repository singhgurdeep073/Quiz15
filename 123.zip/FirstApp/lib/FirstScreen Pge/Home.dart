import 'dart:async';
import 'dart:io';
import 'package:firstapp/Home/Notification.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';

import 'package:shared_preferences/shared_preferences.dart';


import '../Payment/MyWallet.dart';
import '../SpleshScreen.dart';
import '../Home/RankPages/Catgorytab/Real.dart';
import '../Home/RankPages/Catgorytab/Fix.dart';

class Imageslider{
  final String img;
  Imageslider({required this.img});
}
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  List<Imageslider>img=[
  Imageslider(img: "images/S1.jpeg"),
  Imageslider(img: "images/S2.jpeg"),
  Imageslider(img: "images/S3.jpeg"),
];
File? _selectedImage;

Future<void> _pickImage() async {
  final pickedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
  if (pickedImage  != null) {
    setState(() {
      _selectedImage  = File(pickedImage .path);
    });
  }
}
  Future<void> clearSession() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('PhoneNo');
    Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Splesh_Screen(),));


  }

  Future<void> setLoggedIn() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('isLoggedIn', true);
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();


@override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        key:_scaffoldKey ,
        appBar: AppBar(
         backgroundColor: CupertinoColors.white,
          leading: Padding(
            padding: const EdgeInsets.all(8.0),
            child: GestureDetector(
              onTap: () {
                _scaffoldKey.currentState?.openDrawer();
              },
              child: CircleAvatar(
                child: _selectedImage != null
                    ? CircleAvatar(
                  backgroundImage: FileImage(_selectedImage!),
                )
                    : Icon(Icons.person, color: Colors.white),
              ),
            ),
          ),


          actions: [
     Container(
       margin: EdgeInsets.only(right: 50),
        height: 70,width: 70,
        decoration: BoxDecoration(
          image: DecorationImage(image: AssetImage("images/logo.png"))
        ),
      ),

         IconButton(onPressed: (){
           Get.to(
               fullscreenDialog: true,duration: Duration(milliseconds: 600),
               transition:Transition.fadeIn,
               MyWallet());
         }, icon: Icon(Icons.account_balance_wallet,color: Color(0xff259de0))),
          IconButton(onPressed: (){
            Get.to(
              fullscreenDialog: true,duration: Duration(milliseconds: 600),
              transition:Transition.fadeIn,
           Notifcate(),
                );
      }, icon: Icon(Icons.notifications_none,color: Color(0xff259de0))),

  ],        iconTheme: IconThemeData(color: Color(0xff259de0),size: 30,),

           bottom: TabBar(

      labelColor:Colors.blue ,
      indicatorSize: TabBarIndicatorSize.label,
      indicatorColor: Colors.grey,
      tabs: [
            Tab(
    child: Align(
      alignment: Alignment.center,
      child: Text("Fix Time", style: GoogleFonts.poppins(
          fontSize: 15,
          fontWeight: FontWeight.bold    ),),
    ),
  ),
            Tab(
    child: Text("Real Time", style: GoogleFonts.poppins(
      fontSize: 15,
fontWeight: FontWeight.bold    ),),
  ),


]),),
        drawer: Drawer(

        child: SingleChildScrollView(
          child: Column(children: [

            Container(
                height: 90,color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: [
                      Row(
                        children: [
                          InkWell(
                            onTap: _pickImage,
                            child:CircleAvatar(
                              radius: 25,
                              backgroundColor: Colors.grey,
                              backgroundImage: _selectedImage != null
                                  ? FileImage(_selectedImage!)
                                  : null,
                            ),
                          ),
                        Padding(
                          padding: const EdgeInsets.only(top: 20.0,left: 6),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("abc@gmail.com",style: TextStyle(color: Colors.grey,fontWeight: FontWeight.bold),),
                              Text("Your Name..",style: TextStyle(color: Colors.grey,fontWeight: FontWeight.bold),),
                              Text("Level 0",style: TextStyle(color: Colors.green,fontWeight: FontWeight.bold),)
                            ],
                          ),
                        ),
                      ],),
                      IconButton(onPressed: (){
                        Navigator.pop(context);
                      }, icon:Icon(Icons.arrow_right,size: 40,color: Colors.grey,))

                    ],
                  ),
                )),
            ListTile(
              leading: Icon(Icons.notifications),
              title: Text(
                'Notifications',

              ),
              trailing: Container(height: 30,width: 30,
               decoration: BoxDecoration(color: Colors.black,borderRadius: BorderRadius.circular(12)),
                child: Center(child: Text("0",style: TextStyle(color: Colors.white,fontSize: 14),)),)
            ),
            ListTile(
                leading: Icon(Icons.account_balance_wallet,color: Colors.black,),
                title: Text(
                  'Wallet',

                ),
                trailing: Text("₹677.00",style: TextStyle(color: Colors.black,fontSize: 14),)
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [ Container(height: 40,width:130,
              decoration: BoxDecoration(color: Colors.black,borderRadius: BorderRadius.circular(12)),
              child: Center(child: Text("Deposit",style: TextStyle(color: Colors.white,fontSize: 16,fontWeight: FontWeight.bold),)),),
              Container(height: 40,width:130,
                decoration: BoxDecoration(color: Color(0xff4cb050),borderRadius: BorderRadius.circular(12)),
                child: Center(child: Text("Withdraw",style: TextStyle(color: Colors.white,fontSize: 16,fontWeight: FontWeight.bold),)),)
            ],),
            Card(
              color: Color(0xfffefefe),
              child:  ListTile(
                leading: Icon(Icons.account_balance_wallet,color: Colors.grey,),
                title: Text(
                  'twiz15 Marking System',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold),

                ),
            ),),
            Card(
              color: Color(0xfffefefe),
              child:  ListTile(
                leading: Icon(Icons.question_mark_outlined,color: Colors.grey,),
                title: Text(
                  'How to Participate?',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold),

                ),
              ),),
            Card(
              color: Color(0xfffefefe),
              child:  ListTile(
                leading: Icon(Icons.mail,color: Colors.grey,),
                title: Text(
                  'Support & FAQs',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold),

                ),
              ),),
            Card(
              color: Color(0xfffefefe),
              child:  ListTile(
                leading: Icon(Icons.share,color: Colors.grey,),
                title: Text(
                  'Share App',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold),

                ),
              ),),
            Row(mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text("Legal",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.grey,fontSize: 16),),
                ),
              ],
            ),
            Card(
              color: Color(0xfffefefe),
              child:  ListTile(
                leading: Text(
                  'Privacy Policy',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                ),
              ),),
            Card(
              color: Color(0xfffefefe),
              child:  ListTile(
                leading: Text(
                  'Terms & Conditions',style: TextStyle(color:Colors.black,fontWeight: FontWeight.bold,fontSize: 14),
                ),
              ),),
            Padding(
              padding: const EdgeInsets.only(top: 2.0,left: 5,right: 5,bottom: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap:(){
                      clearSession();
                    },
                    child: Container(height: 40,width:130,
                      decoration: BoxDecoration(color: Color(0xff4cb050),borderRadius: BorderRadius.circular(12)),
                      child: Center(child: Text("LogOut",style: TextStyle(color: Colors.white,fontSize: 18,fontWeight: FontWeight.bold),)),),
                  ),
                  Text("v1.0.6")
                ],),
            ),
          ],),
        ),
      ),
         body: Container(

           height: MediaQuery.of(context).size.height*1,
           child: TabBarView(children: [
             FixTab(),
             RealTab(),


           ]),
         )
      ),
    );
  }
}
