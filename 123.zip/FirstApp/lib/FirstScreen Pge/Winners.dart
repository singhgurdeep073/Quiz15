import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_fonts/google_fonts.dart';

class Winners extends StatefulWidget {
  const Winners({super.key});

  @override
  State<Winners> createState() => _WinnersState();
}

class _WinnersState extends State<Winners> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.grey.shade100,
      body: LayoutBuilder(
        builder: (context, constraints) =>
            Column(
              children: [
                SizedBox(
                  height:710,
                  child: Stack(
                    children: [
                      Positioned(
                          top: 0,
                          bottom: 400,
                          left: 0,
                          right: 0,
                          child: Container(height: 360,
                            color: Colors.blueAccent,
                            child: Column(children: [
                              Padding(
                                padding: const EdgeInsets.only(top: 35.0,bottom: 30),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'QuizPe Coin',
                                      style: GoogleFonts.yaldevi(
                                        fontSize: 24,color: Colors.white,
                                        fontWeight: FontWeight.w700,
                                        fontStyle: FontStyle.normal,
                                      ),
                                    ),
                                    SizedBox(width: 7,),
                                    Icon(CupertinoIcons.info_circle_fill,color: Colors.white,)
                                  ],
                                ),
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'QuizPe Coin',
                                        style: GoogleFonts.poppins(
                                          fontSize: 15,
                                            color: Colors.white,
                                          fontWeight: FontWeight.w300,
                                          fontStyle: FontStyle.normal,
                                        ),
                                      ),
                                      Text(
                                        '28',
                                        style: GoogleFonts.poppins(
                                          fontSize: 14,color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontStyle: FontStyle.normal,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Ranking',
                                        style: GoogleFonts.poppins(
                                          fontSize: 15,
                                          color: Colors.white,
                                          fontWeight: FontWeight.w300,
                                          fontStyle: FontStyle.normal,
                                        ),
                                      ),
                                      Text(
                                        '1228',
                                        style: GoogleFonts.poppins(
                                          fontSize: 14,color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontStyle: FontStyle.normal,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Container(
                                    height: 40,
                                    width: 90,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(color: Colors.black),
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    child: Center(child: Text("View Ranking",style: TextStyle(fontSize: 13),),),
                                  )


                                ],
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 20),
                                height: 40,
                                width: 320,
                                decoration: BoxDecoration(
                                  color: Colors.black38,

                                  borderRadius: BorderRadius.circular(7),
                                ),
                                child: Center(child: Text("The more you ply,more QuizPe coin you will earn",style: TextStyle(fontSize: 13,color: Colors.white),),),
                              )


                            ],),)
                      ),
                      Positioned(
                        top:200,
                        left: 0,
                        right: 0,
                        child: Padding(
                          padding: const EdgeInsets.all( 13.0),
                          child: Container(
                            height: 370,
                            decoration: BoxDecoration(
                            color: Colors.white,
                              boxShadow: [BoxShadow(color: Colors.black87,blurRadius: 4,offset: Offset(3,2))],
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Column(
                              children: [

                                Padding(
                                  padding: const EdgeInsets.only(right: 120.0,top: 10),
                                  child: Text(
                                    'Earning details - Lifetime',
                                    style: GoogleFonts.yaldevi(
                                      fontSize: 17,color: Colors.black,
                                      fontWeight: FontWeight.w700,
                                      fontStyle: FontStyle.normal,
                                    ),
                                  ),
                                ),
                                Card(

                                  color:Colors.grey.shade100,
                                  child:  ListTile(
                                    title: Text(
                                      'Contest Played',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                                    ),
                                    trailing: Icon(CupertinoIcons.add_circled),
                                    leading:Icon(Icons.messenger)
                                  ),),
                                Card(

                                  color:Colors.grey.shade100,
                                  child:  ListTile(
                                      title: Text(
                                        'Referrals playing contest',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                                      ),
                                      trailing:Text("Invite",style: TextStyle(color:Colors.indigo,fontWeight: FontWeight.bold),),
                                      leading:Icon(Icons.person)
                                  ),),
                                Card(

                                  color:Colors.grey.shade100,
                                  child:  ListTile(
                                      title: Text(
                                        'App share & install',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                                      ),
                                      trailing:Text("Invite",style: TextStyle(color:Colors.indigo,fontWeight: FontWeight.bold),),
                                      leading:Icon(Icons.output_outlined)
                                  ),),
                                Card(

                                  color:Colors.grey.shade100,
                                  child:  ListTile(
                                      title: Text(
                                        'Wallet Money',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                                      ),
                                      trailing:Icon(CupertinoIcons.add_circled),
                                      leading:Icon(Icons.account_balance_wallet)
                                  ),),
                                Card(

                                  color:Colors.grey.shade100,
                                  child:  ListTile(
                                      title: Text(
                                        'Winnings',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                                      ),
                                      trailing:Icon(CupertinoIcons.add_circled),
                                      leading:Icon(Icons.badge_rounded)
                                  ),),
                              ],
                            ),

                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
      ),
    );
  }
}
