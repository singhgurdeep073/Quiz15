import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';

import '../Home/Notification.dart';
import 'Home.dart';

class Rewards extends StatefulWidget {
  const Rewards({super.key});

  @override
  State<Rewards> createState() => _RewardsState();
}

class _RewardsState extends State<Rewards> {
  List<Imageslider>img=[
    Imageslider(img: "images/S1.jpeg"),
    Imageslider(img: "images/S2.jpeg"),
    Imageslider(img: "images/S3.jpeg"),
  ];
  @override
  Widget build(BuildContext context) {
    return  DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            title:  Text('LeaderBoard',style: GoogleFonts.poppins(
              fontSize: 20,fontWeight: FontWeight.w500,color: Colors.white,
            ),),
            actions: [
               IconButton(onPressed: (){}, icon:Icon(Icons.share)),
               IconButton(onPressed: (){}, icon:Icon(Icons.info)),
               IconButton(onPressed: (){
                  Get.to(
                   fullscreenDialog: true,duration: Duration(milliseconds: 600),
                   transition:Transition.fadeIn,
                   Notifcate(),
                   );
               }, icon:Icon(Icons.notifications)),

                  ],
            backgroundColor: Colors.blueAccent,
            elevation: 0,
            bottom: TabBar(
                unselectedLabelColor: Colors.black,
                indicatorSize: TabBarIndicatorSize.tab,
                indicator: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                   gradient: LinearGradient(colors: [
                     Colors.grey,

                     Colors.grey,
                     Colors.white,
                   ])),
                tabs: [
                  Tab(
                    child: Align(
                      alignment: Alignment.center,
                      child: Text("Money Minters",style: TextStyle(fontSize: 13,fontWeight: FontWeight.bold),),
                    ),
                  ),
                  Tab(
                    child: Align(
                      alignment: Alignment.center,
                      child: Text("Premier Club",style: TextStyle(
                        fontWeight: FontWeight.bold
                      ),),
                    ),
                  ),
                  Tab(
                    child: Align(
                      alignment: Alignment.center,
                      child: Text("Contest league",style: TextStyle(fontSize: 13,fontWeight: FontWeight.bold),),
                    ),
                  ),
                ]),
          ),
          body:Column(children: [
            Container(
              height: 239,
              color: Colors.blueAccent,
              child: Column(children: [
                Container(
                  margin: EdgeInsets.all(4),
                  child:   CarouselSlider.builder(
                    itemCount: img.length,
                    itemBuilder: (BuildContext context, int index, int realIndex) {
                      return Padding(
                        padding: const EdgeInsets.only(left: 4.0,right: 4,top: 4),
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              image: DecorationImage(image: AssetImage(img[index].img),fit: BoxFit.cover)
                          ),
                        ),
                      );
                    },
                    options: CarouselOptions(
                      height: 90,
                      aspectRatio: 9 / 9,
                      viewportFraction: 1,
                      initialPage: 1,
                      enableInfiniteScroll: true,
                      autoPlay: true,
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20),
                  height: 120,
                  color: Colors.indigo,
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text('Rank',style: GoogleFonts.poppins(fontSize: 14,color: Colors.white),),
                          Text('Name',style: GoogleFonts.poppins(fontSize: 14,color: Colors.white),),
                          Text('Badge',style: GoogleFonts.poppins(fontSize: 14,color: Colors.white),),
                          Text('QuizPe Coins',style: GoogleFonts.poppins(fontSize: 14,color: Colors.white),),
                        ],
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 15),
                        height: 60,
                        width: 300,
                        decoration: BoxDecoration(
                          color: Colors.orange.shade100,
                          borderRadius: BorderRadius.circular(10)

                        ),
                        child: ListTile(
                            title: Row(
                              children: [
                                CircleAvatar(
                                  radius: 20,
                               backgroundImage: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGqbJbA69As8mUJ2xfuiO3KB7f9CTbq-85VWM5ZjdgbZDBu1Mdrg1xXJ94JMT9yfWxir0&usqp=CAU"),
                                ),
                                SizedBox(width: 5,),
                                Text(
                                  'Name..',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                                ),
                              ],
                            ),
                            trailing:Text("28.5",style: TextStyle(color:Colors.indigo,),),
                            leading:Text("85")
                        ),
                      )
                    ],
                  ),
                ),

              ],),
            ),
            Padding(
              padding:  EdgeInsets.only(right:MediaQuery.of(context).size.width*.65),
              child: Text('Current Month',style: GoogleFonts.poppins(fontSize: 18,color: Colors.black),),
            ),
            Container(
              height: 325,
              child:
              SingleChildScrollView(
                child:  Column(
                  children: [
                    Card(
                      color:Colors.grey.shade100,
                      child: ListTile(
                          title: Row(
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundImage: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGqbJbA69As8mUJ2xfuiO3KB7f9CTbq-85VWM5ZjdgbZDBu1Mdrg1xXJ94JMT9yfWxir0&usqp=CAU"),
                              ),
                              SizedBox(width: 5,),
                              Text(
                                'Name..',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                              ),
                            ],
                          ),
                          trailing:Text("3028.5",style: TextStyle(color:Colors.indigo,),),
                          leading:Text("1")
                      ),),
                    Card(

                      color:Colors.grey.shade100,
                      child: ListTile(
                          title: Row(
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundImage: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGqbJbA69As8mUJ2xfuiO3KB7f9CTbq-85VWM5ZjdgbZDBu1Mdrg1xXJ94JMT9yfWxir0&usqp=CAU"),
                              ),
                              SizedBox(width: 5,),
                              Text(
                                'Name..',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                              ),
                            ],
                          ),
                          trailing:Text("2528.5",style: TextStyle(color:Colors.indigo,),),
                          leading:Text("2")
                      ),),
                    Card(

                      color:Colors.grey.shade100,
                      child: ListTile(
                          title: Row(
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundImage: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGqbJbA69As8mUJ2xfuiO3KB7f9CTbq-85VWM5ZjdgbZDBu1Mdrg1xXJ94JMT9yfWxir0&usqp=CAU"),
                              ),
                              SizedBox(width: 5,),
                              Text(
                                'Name..',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                              ),
                            ],
                          ),
                          trailing:Text("2428.5",style: TextStyle(color:Colors.indigo,),),
                          leading:Text("3")
                      ),),
                    Card(

                      color:Colors.grey.shade100,
                      child: ListTile(
                          title: Row(
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundImage: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGqbJbA69As8mUJ2xfuiO3KB7f9CTbq-85VWM5ZjdgbZDBu1Mdrg1xXJ94JMT9yfWxir0&usqp=CAU"),
                              ),
                              SizedBox(width: 5,),
                              Text(
                                'Name..',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                              ),
                            ],
                          ),
                          trailing:Text("2228.5",style: TextStyle(color:Colors.indigo,),),
                          leading:Text("4")
                      ),),
                    Card(

                      color:Colors.grey.shade100,
                      child: ListTile(
                          title: Row(
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundImage: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGqbJbA69As8mUJ2xfuiO3KB7f9CTbq-85VWM5ZjdgbZDBu1Mdrg1xXJ94JMT9yfWxir0&usqp=CAU"),
                              ),
                              SizedBox(width: 5,),
                              Text(
                                'Name..',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                              ),
                            ],
                          ),
                          trailing:Text("2028.5",style: TextStyle(color:Colors.indigo,),),
                          leading:Text("5")
                      ),),
                    Card(

                      color:Colors.grey.shade100,
                      child: ListTile(
                          title: Row(
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundImage: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGqbJbA69As8mUJ2xfuiO3KB7f9CTbq-85VWM5ZjdgbZDBu1Mdrg1xXJ94JMT9yfWxir0&usqp=CAU"),
                              ),
                              SizedBox(width: 5,),
                              Text(
                                'Name..',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                              ),
                            ],
                          ),
                          trailing:Text("1828.5",style: TextStyle(color:Colors.indigo,),),
                          leading:Text("6")
                      ),),
                    Card(

                      color:Colors.grey.shade100,
                      child: ListTile(
                          title: Row(
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundImage: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGqbJbA69As8mUJ2xfuiO3KB7f9CTbq-85VWM5ZjdgbZDBu1Mdrg1xXJ94JMT9yfWxir0&usqp=CAU"),
                              ),
                              SizedBox(width: 5,),
                              Text(
                                'Name..',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                              ),
                            ],
                          ),
                          trailing:Text("1628.5",style: TextStyle(color:Colors.indigo,),),
                          leading:Text("7")
                      ),),
                    Card(

                      color:Colors.grey.shade100,
                      child: ListTile(
                          title: Row(
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundImage: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGqbJbA69As8mUJ2xfuiO3KB7f9CTbq-85VWM5ZjdgbZDBu1Mdrg1xXJ94JMT9yfWxir0&usqp=CAU"),
                              ),
                              SizedBox(width: 5,),
                              Text(
                                'Name..',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14),

                              ),
                            ],
                          ),
                          trailing:Text("1428.5",style: TextStyle(color:Colors.indigo,),),
                          leading:Text("8")
                      ),),

                  ],
                ),
              ),
            )


          ],)
        ));
  }}