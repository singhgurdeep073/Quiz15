import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../Home/JoinPage.dart';
void main(){
  runApp(Subject());
}
class Sub{

  final String subject;

  Sub({required this.subject,} );
  factory Sub.FromJson(Map<String,dynamic>json){
    return Sub(subject:json['subjec']);

  }
}

class Subject extends StatefulWidget {
  const Subject({super.key});

  @override
  State<Subject> createState() => _SubjectState();
}

class _SubjectState extends State<Subject> {
  Future<List<Sub>> fetchDataQuiz15() async{
    var url=Uri.parse("https://amazonboost.in/demo/twiz/subject");
    final responce=await http.get(url);
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => Sub.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: 122,
        child:  FutureBuilder<List<Sub>>(
            future: fetchDataQuiz15(),
            builder: (context,abc){
              if(abc.hasData){
                return  Container(
                  height: MediaQuery.of(context).size.height*1,
                  child: ListView.builder(
                      itemCount: abc.data!.length,

                      itemBuilder: (BuildContext context,int len){
                        return Column(
                          children: [
                          Text(abc.data![len].subject.toString())





                          ],
                        );

                      }),
                );
              }
              else if(abc.hasError){
                return Text(abc.error.toString());

              }
              return Center(child: SpinKitWaveSpinner(color: Colors.grey));
            }

        ), ),
      );
  }
}
