import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Quest{

  final String ques;
  final String opt1;
  final String opt2;
  final String opt3;
  final String opt4;

  Quest({required this.ques,required this.opt1,required this.opt2,required this.opt3,required this.opt4,} );
  factory Quest.FromJson(Map<String,dynamic>json){
    return Quest(opt1: json["option_one"],opt2: json['option_two'],opt3: json['option_three'],opt4: json['option_four'],ques: json['question']);

  }
}
class Question extends StatefulWidget {
  const Question({super.key});

  @override
  State<Question> createState() => _QuestionState();
}

class _QuestionState extends State<Question> {
  Future<List<Quest>> fetchDataQuiz() async{
    var url=Uri.parse("https://amazonboost.in/demo/twiz/question_view_question");
    final responce=await http.get(url);
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => Quest.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: 122,
        child:  FutureBuilder<List<Quest>>(
            future: fetchDataQuiz(),
            builder: (context,abc){
              if(abc.hasData){
                return  Container(
                  height: MediaQuery.of(context).size.height*1,
                  child: ListView.builder(
                      itemCount: abc.data!.length,

                      itemBuilder: (BuildContext context,int len){
                        return Column(
                          children: [
                            Text(abc.data![len].ques),
                            Text(abc.data![len].opt1),
                            Text(abc.data![len].opt2),
                            Text(abc.data![len].opt3),
                            Text(abc.data![len].opt4),
                          ],
                        );

                      }),
                );
              }
              else if(abc.hasError){
                return Text(abc.error.toString());

              }
              return Center(child: SpinKitWaveSpinner(color: Colors.grey));
            }

        ), ),
    );
  }
}
