import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:firstapp/QuizCategory/NavBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import '../BottomNavigation.dart';
import '../Home/RankPages/Catgorytab/Real.dart';
import '../clock.dart';

class FinishQuiz extends StatefulWidget {
  const FinishQuiz({super.key});

  @override
  State<FinishQuiz> createState() => _FinishQuizState();
}

class _FinishQuizState extends State<FinishQuiz> {
  final GlobalKey<FormState>_form= GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      body: Form(
        key: _form,
        child: LayoutBuilder(
          builder: (context, constraints) =>
              SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height:MediaQuery.of(context).size.height*1,
                      child: Stack(
                        children: [
                          Positioned(
                            top: 0,
                            bottom: 580,
                            left: 0,
                            right: 0,
                            child: Container(height: 360,
                              color: Colors.blueAccent,
                              child: Column(children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 18.0),
                                  child: Row(
                                    children: [
                                      IconButton(onPressed: (){
                                        Get.to(NavBar());
                                      }, icon:Icon(CupertinoIcons.left_chevron,color: Colors.white,)),
                                      Text(
                                        'Quiz Result',
                                        style: GoogleFonts.yaldevi(
                                          fontSize: 24,color: Colors.white,
                                          fontWeight: FontWeight.w700,
                                          fontStyle: FontStyle.normal,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(Icons.verified,color: Colors.green,size: 60,),
                                        Column(
                                          children: [
                                            Text("Amount Won",style: TextStyle(color: Colors.white,fontSize: 20),),

                            SizedBox(
                              width: 120.0,
                              child: DefaultTextStyle(
                                style: GoogleFonts.poppins(
                                  fontSize: 25,fontWeight: FontWeight.w500,color: Colors.amber
                              ),
                                child: AnimatedTextKit(
                                  repeatForever: false,

                                  animatedTexts: [

                                    TypewriterAnimatedText('₹10.00')
                                  ],

                                ),
                              ),
                            )
                                          ],
                                        )
                                      ],
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 68.0),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.end,
                                        children: [
                                          Text("Entry Fee",style: TextStyle(fontWeight: FontWeight.w600,color: Colors.white70),),
                                          Text("Rs.3",style: TextStyle(fontWeight: FontWeight.w600,color: Colors.white),)
                                        ],
                                      ),
                                    )
                                  ],
                                )
                              ],),)
                          ),
                          Positioned(
                            top:140,
                            left: 0,
                            right: 0,
                            child: Padding(
                              padding: const EdgeInsets.all( 13.0),
                              child: Container(
                                height: 600,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                 child: Column(
                                   children: [
                                   Container(height: 170,width: 300,
                                     decoration: BoxDecoration(
                                       color: Colors.white,
                                         boxShadow: [BoxShadow(
                                           color: Colors.grey,blurRadius: 12,offset: Offset(3,7)
                                         )],
                                         borderRadius: BorderRadius.circular(10)),
                                     child:Column(children: [
                                       Padding(
                                         padding: const EdgeInsets.all(8.0),
                                         child: Row(
                                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                           children: [
                                             Column(
                                               crossAxisAlignment: CrossAxisAlignment.start,
                                               children: [
                                                 Text("Modern History",style: TextStyle(color: Colors.black,fontSize: 18),),
                                                 Text("Language-"+"English",style: TextStyle(fontSize: 12,color: Colors.grey),)
                                               ],
                                             ),
                                             Icon(Icons.share,size: 30,)
                                           ],
                                         ),
                                       ),
                                       Padding(
                                         padding: const EdgeInsets.only(top: 38.0),
                                         child: SizedBox(
                                           width: 250,height: 50,
                                           child: ElevatedButton(
                                               style: ElevatedButton.styleFrom(
                                                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                                 primary: Colors.blue.shade200, // Background color
                                                 onPrimary: Colors.blue, // Text Color (Foreground color)
                                               ),
                                               onPressed: (){
                                                 Get.to(
                                                     fullscreenDialog: true,duration: Duration(milliseconds: 800),
                                                     transition:Transition.fadeIn,
                                                     RealTab());
},
                                               child: Text('Play more 1-on-1 Contest',
                                                 style: GoogleFonts.poppins(
                                                   fontSize: 15,fontWeight: FontWeight.w300,color: Colors.white
                                               ),)),
                                         ),
                                       ),

                                     ],)),
                                   Padding(
                                     padding: const EdgeInsets.only(top: 30.0),
                                     child: Container(height: 180,width: 300,
                                         decoration: BoxDecoration(
                                             color: Colors.white,
                                             boxShadow: [BoxShadow(
                                                 color: Colors.grey,blurRadius: 12,offset: Offset(3,7)
                                             )],
                                             borderRadius: BorderRadius.circular(10)
                                         ),
                                       child: Column(children: [
                                           SizedBox(height: 30,),
                                         Row(
                                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,

                                           children: [
                                             Container(
                                               margin: EdgeInsets.all(8),
                                               width: 110,
                                               decoration: BoxDecoration(
                                                   color: Colors.white,
                                                   boxShadow: [BoxShadow(
                                                       color: Colors.grey,blurRadius: 7,offset: Offset(4,6)
                                                   )],
                                                   borderRadius: BorderRadius.circular(10)
                                               ),
                                               height:MediaQuery.of(context).size.height*.15 ,
                                               child: Column(children: [
                                                  SizedBox(height: 7,),
                                                 Column(crossAxisAlignment: CrossAxisAlignment.center,
                                                 mainAxisAlignment: MainAxisAlignment.center,
                                                 children: [
                                                   Row(
                                                     children: [
                                                       Icon(Icons.check_circle_rounded,color: Colors.green,size: 20,),
                                                       Text('Correct Qs:',style: TextStyle(color: Colors.black,fontSize: 9),),
                                                       Padding(
                                                         padding: EdgeInsets.only(left: 22.0),
                                                         child: Text("0",style: TextStyle(color: Colors.black,fontSize: 9),),
                                                       )
                                                     ],
                                                   ),
                                                   SizedBox(height: 5,),
                                                   Row(
                                                     children: [
                                                       Icon(Icons.dangerous_rounded,color: Colors.red,size: 20,),
                                                       Text('Wrong Qs:',style: TextStyle(color: Colors.black,fontSize: 9),),
                                                       Padding(
                                                         padding: EdgeInsets.only(left: 25.0),
                                                         child: Text("0",style: TextStyle(color: Colors.black,fontSize: 9),),
                                                       )
                                                     ],
                                                   ),
                                                   SizedBox(height: 5,),

                                                   Row(
                                                     children: [
                                                       Icon(Icons.circle,color: Colors.grey,size: 20,),
                                                       Text('Unattempted:',style: TextStyle(color: Colors.black,fontSize: 9),),
                                                       Padding(
                                                         padding: EdgeInsets.only(left: 13.0),
                                                         child: Text("0",style: TextStyle(color: Colors.black,fontSize: 9),),
                                                       )
                                                     ],
                                                   ),
                                                   SizedBox(height: 6,),
                                                   SizedBox(
                                                     width: 100,height: 30,
                                                     child: ElevatedButton(
                                                         style: ElevatedButton.styleFrom(
                                                           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                                           primary: Colors.blue.shade200, // Background color
                                                           onPrimary: Colors.blue, // Text Color (Foreground color)
                                                         ),
                                                         onPressed: (){
/*
                                                   Navigator.push(context,MaterialPageRoute(builder: (context){
                                                     return RealTab();
                                                   }));
*/
                                                         },
                                                         child: Text('View Solution',style: GoogleFonts.poppins(
                                                             fontSize: 11,fontWeight: FontWeight.w300,color: Colors.black
                                                         ),)),
                                                   ),
                                                 ],),
                                               ],),
                                             ),
                                             Container(height: 130,width: 1,color: Colors.black,),
                                             Container(
                                               width: 110,
                                               decoration: BoxDecoration(
                                                   color: Colors.white,
                                                   boxShadow: [BoxShadow(
                                                       color: Colors.grey,blurRadius: 7,offset: Offset(4,6)
                                                   )],
                                                   borderRadius: BorderRadius.circular(10)
                                               ),
                                               height:MediaQuery.of(context).size.height*.15 ,
                                               child: Column(children: [
                                                 Padding(
                                                   padding: const EdgeInsets.only(left: 2,right: 1),
                                                   child: SizedBox(
                                                     height: 60,width: 300,
                                                     child: Center(
                                                       child: AutoSizeText(

                                                          "More upcoming contests are launched for you..",
                                                           style: TextStyle(fontSize: 2),
                                                           minFontSize: 13,
                                                           maxLines: 3,
                                                           overflow: TextOverflow.ellipsis

                                                       ),
                                                     ),
                                                   ),
                                                 ),


                                                 Padding(
                                                   padding: const EdgeInsets.only(top: 22.0),
                                                   child: SizedBox(
                                                     width: 100,height: 30,
                                                     child: ElevatedButton(
                                                         style: ElevatedButton.styleFrom(
                                                           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                                           primary: Colors.green, // Background color
                                                           onPrimary: Colors.white, // Text Color (Foreground color)
                                                         ),
                                                         onPressed: (){
                                                           Get.to(
                                                               fullscreenDialog: true,duration: Duration(milliseconds: 500),
                                                               transition:Transition.fadeIn,
                                                               QuizNav());                                                         },
                                                         child: Text('Join Now',style: GoogleFonts.poppins(
                                                             fontSize: 11,fontWeight: FontWeight.w300,color: Colors.white
                                                         ),)),
                                                   ),
                                                 ),

                                               ],),
                                             ),

                                           ],
                                         ),
                                       ],),
                                        ),
                                   ),
                                   SizedBox(height: 20,),
                                   Container(
                                     height: 90,width: 300,
                                     decoration: BoxDecoration(
                                      color: Colors.blue.shade200,
                                      boxShadow: [BoxShadow(
                                          color: Colors.grey,blurRadius: 7,offset: Offset(4,6)
                                      )],
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(top: 18.0),
                                        child: Column(
                                          children: [
                                            Text(
                                            'Rate This App To Improve the Experience',style: GoogleFonts.poppins(
                                            fontSize: 13,color: Colors.white,fontWeight: FontWeight.bold
                                          ),),
                                            Container(
                                              child: RatingBar.builder(
                                                initialRating: 1,
                                                minRating: 0,
                                                direction: Axis.horizontal,
                                                allowHalfRating: true,
                                                itemCount: 5,
                                                itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                                                itemBuilder: (context, _) => Icon(
                                                  Icons.star,
                                                  color: Colors.amber,
                                                ),
                                                onRatingUpdate: (rating) {
                                                  print(rating);                                  },
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      IconButton(onPressed: (){}, icon: Icon(Icons.arrow_right,size: 50,color: Colors.white,))

                                    ],
                                  ),
                                )],),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
        ),
      ),
    );
  }}