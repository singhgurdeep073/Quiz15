import 'dart:async';

import 'package:firstapp/Home/JoinPage.dart';
import 'package:firstapp/Quiz%20Page/Submit.dart';
import 'package:firstapp/QuizCategory/NavBar.dart';
import 'package:firstapp/clock.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:quiver/async.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:auto_size_text/auto_size_text.dart';

import '../api/question.dart';
import '../FirstScreen Pge/Home.dart';
import '../Home/Subcategory/SubCategory.dart';
class Quiz extends StatefulWidget {

  const Quiz({super.key,});

  @override
  State<Quiz> createState() => _QuizState();
}
class _QuizState extends State<Quiz> {
  late Timer _timer;
  int _secondsRemaining = 15 * 60;

  void startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_secondsRemaining > 0) {
        setState(() {
          _secondsRemaining--;
        });
      } else {
        _timer.cancel();
      }
    });
  }

  void pauseTimer() {
    if (_timer.isActive) {
      _timer.cancel();
    }
  }

  void resetTimer() {
    if (_timer.isActive) {
      _timer.cancel();
    }
    setState(() {
      _secondsRemaining = 15 * 60;
    });
  }

  void addTenSeconds() {
    if (_secondsRemaining < (15 * 60 - 10)) {
      setState(() {
        _secondsRemaining += 10;
      });
    }
  }

  void subtractTenSeconds() {
    if (_secondsRemaining >= 10) {
      setState(() {
        _secondsRemaining -= 10;
      });
    }
  }
   PageController _con = PageController();
  Future<List<Quest>> fetchDataQuiz() async{
    final responce=await http.get(Uri.parse("https://amazonboost.in/demo/twiz/question_view_question"));
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => Quest.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }
  }
  Future<bool> _pop() async {
    return (
        await showDialog(
          context: context,
          builder: (context) => AlertDialog(

            content:Text('Are You Sure to Quit Quiz',style: GoogleFonts.poppins(
              fontSize: 15,color: Colors.black,
            ),),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),

                child: Text('No',style: GoogleFonts.poppins(
                  fontSize: 15,color: Colors.black
                ),),
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    primary: Colors.red.shade300, // Background color
                    onPrimary: Colors.black, // Text Color (Foreground color)
                  ),
                  onPressed: () => Navigator.push(context,MaterialPageRoute(builder: (context)=>Pool())),child: Text('Yes',style: GoogleFonts.poppins(
                  fontSize: 18,fontWeight: FontWeight.w300,color: Colors.white
              ),)),
            ],
          ),
        )) ??
        false;
  }
  Future<bool> Submit() async {
    return (
        await showDialog(
          context: context,
          builder: (context) => AlertDialog(

            content:Container(
              height:MediaQuery.of(context).size.height*.30 ,
              child: Column(children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Quiz Summary',style: GoogleFonts.poppins(
                        fontSize: 23,fontWeight: FontWeight.w300,color: Colors.black
                    ),),
                  IconButton(onPressed: (){
                    Navigator.pop(context);
                  }, icon: Icon(Icons.dangerous_rounded,color: Colors.grey,size: 35,))
                ],),
                SizedBox(height: 20,),
                ListTile(
                    leading: Icon(Icons.check_circle_rounded,color: Colors.green,),
                    title: Text(
                      'Attempted:',

                    ),
                    trailing: Container(height: 30,width: 30,
                      decoration: BoxDecoration(color: Colors.green,borderRadius: BorderRadius.circular(12)),
                      child: Center(child: Text("0",style: TextStyle(color: Colors.white,fontSize: 14),)),)
                ),
                ListTile(
                    leading: Icon(Icons.dangerous,color: Colors.red,),
                    title: Text(
                      'Not Attempted:',

                    ),
                    trailing: Container(height: 30,width: 30,
                      decoration: BoxDecoration(color: Colors.red,borderRadius: BorderRadius.circular(12)),
                      child: Center(child: Text("0",style: TextStyle(color: Colors.white,fontSize: 14),)),)
                ),
                ListTile(
                    leading: Icon(Icons.circle,color: Colors.grey,),
                    title: Text(
                      'Not Seen:',

                    ),
                    trailing: Container(height: 30,width: 30,
                      decoration: BoxDecoration(color: Colors.grey,borderRadius: BorderRadius.circular(12)),
                      child: Center(child: Text("0",style: TextStyle(color: Colors.white,fontSize: 14),)),)
                ),
              ],),
            ),
            actions: <Widget>[

              ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    primary: Colors.grey, // Background color
                    onPrimary: Colors.black, // Text Color (Foreground color)
                  ),
                  onPressed: () => Navigator.of(context).pop(false),
                  child: Text('Continue',style: GoogleFonts.poppins(
                      fontSize: 15,fontWeight: FontWeight.w300,color: Colors.white
                  ),)),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    primary: Colors.amber, // Background color
                    onPrimary: Colors.black, // Text Color (Foreground color)
                  ),
                  onPressed: (){
                Get.to(
                    fullscreenDialog: true,duration: Duration(milliseconds: 800),
                    transition:Transition.fadeIn,
                    FinishQuiz());
                  },
                  child: Text('Quit',style: GoogleFonts.poppins(
                  fontSize: 15,fontWeight: FontWeight.w300,color: Colors.white
              ),)),
            ],
          ),
        )) ??
        false;
  }
  DateTime lastTimeBackbuttonWasClicked = DateTime.now();

  @override
  Widget build(BuildContext context) {
    int minutes = _secondsRemaining ~/ 60;
    int seconds = _secondsRemaining % 60;
    return Scaffold(
        appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.black, //change your color here
        ),
        backgroundColor: Colors.white,
        title:  Center(
        child: Container(
          margin: EdgeInsets.only(right: MediaQuery.of(context).size.width*.15),

          height: 70,width: 70,
          decoration: BoxDecoration(
              image: DecorationImage(image: AssetImage("images/logo.png"))
          ),
        ),
      ),),
      backgroundColor: Color(0xff259de0),
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height*.60,
    child:  FutureBuilder<List<Quest>>(
    future: fetchDataQuiz(),
    builder: (context,abc){
    if(abc.hasData){
    return  Container(

          height: MediaQuery.of(context).size.height*1,
    child:PageView.builder(
          physics: NeverScrollableScrollPhysics(),
          controller: _con,
          itemCount: abc.data!.length,
          itemBuilder: (context, len) {
            return Column(
                children: [
                  SizedBox(height: 20,),
                  Center(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            height: 400,width: 350,
                            child: Column(children: [
                              GestureDetector(
                                onTap:(){
                                  Get.to(QuizNav());
                                },
                                child: Container(height: 90,width: MediaQuery.of(context).size.width*1,
                                  decoration: BoxDecoration(
                                    color: Color(0xffd5d5d5),
                                    borderRadius: BorderRadius.only(topLeft: Radius.circular(12),topRight: Radius.circular(12)),
                                  ),child: Center(
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [

                                          SizedBox(
                                            height: 90,width: 300,
                                            child: Center(
                                              child: AutoSizeText(
                                                  abc.data![len].ques,
                                                  style: TextStyle(fontSize: 2),
                                                  minFontSize: 14,
                                                  maxLines: 4,
                                                  overflow: TextOverflow.ellipsis

                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Column(

                                children: [
                                  Text(
                                    '$minutes:${seconds < 10 ? '0':''}$seconds',
                                    style: TextStyle(fontSize: 18,color: Colors.redAccent),
                                  ),
                                  SizedBox(
                                    width: 300,
                                    child: ElevatedButton(

                                        style: ButtonStyle(

                                          overlayColor: MaterialStateProperty.resolveWith<Color?>(
                                                (Set<MaterialState> states) {
                                              if (states.contains(MaterialState.pressed))
                                                return Color(0xfffbbc72);
                                              return null;
                                            },),),

                                        onPressed: (){
                                          addTenSeconds();
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(
                                            SnackBar(
                                              margin: EdgeInsets.only(bottom: 50,left: 10,right: 10),
                                              dismissDirection: DismissDirection.endToStart,
                                              behavior: SnackBarBehavior.floating,
                                              duration: Duration(seconds: 2),
                                              backgroundColor: Colors.greenAccent,
                                              content: Text('Correct Answer...',style: GoogleFonts.poppins(
                                                fontSize: 15,color: Colors.black,
                                              ),),
                                            ),
                                          );
                                        }, child: Text(abc.data![len].opt1,style: GoogleFonts.poppins(
                                      fontSize: 15,
                                    ),)),
                                  ),
                                  SizedBox(
                                    width: 300,
                                    child: ElevatedButton(
                                        style: ButtonStyle(

                                          overlayColor: MaterialStateProperty.resolveWith<Color?>(
                                                (Set<MaterialState> states) {
                                              if (states.contains(MaterialState.pressed))
                                                return  Color(0xfffbbc72);
                                              return null;
                                            },),),
                                        onPressed: (){
                                          subtractTenSeconds();
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(
                                            SnackBar(
                                              margin: EdgeInsets.only(bottom: 50,left: 10,right: 10),
                                              dismissDirection: DismissDirection.endToStart,
                                              behavior: SnackBarBehavior.floating,
                                              duration: Duration(seconds: 2),
                                              backgroundColor: Colors.redAccent,
                                              content: Text(
                                                'Incorrect Correct Answer...',style: GoogleFonts.poppins(
                                                fontSize: 15,color: Colors.black,
                                              ),),
                                            ),
                                          );
                                        }, child: Text(abc.data![len].opt2,style: GoogleFonts.poppins(
                                      fontSize: 15,
                                    ),)),
                                  ),
                                  SizedBox(
                                    width: 300,
                                    child: ElevatedButton(
                                        style: ButtonStyle(

                                          overlayColor: MaterialStateProperty.resolveWith<Color?>(
                                                (Set<MaterialState> states) {
                                              if (states.contains(MaterialState.pressed))
                                                return  Color(0xfffbbc72);
                                              return null;
                                            },),),
                                        onPressed: (){
                                          addTenSeconds();
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(
                                            SnackBar(
                                              margin: EdgeInsets.only(bottom: 50,left: 10,right: 10),
                                              dismissDirection: DismissDirection.endToStart,
                                              behavior: SnackBarBehavior.floating,
                                              duration: Duration(seconds: 2),
                                              backgroundColor: Colors.greenAccent,
                                              content: Text(
                                                'Correct Answer...',style: GoogleFonts.poppins(
                                                fontSize: 15,color: Colors.black,
                                              ),),
                                            ),
                                          );
                                        }, child: Text(abc.data![len].opt3,style: GoogleFonts.poppins(
                                      fontSize: 15,
                                    ),)),
                                  ),
                                  SizedBox(
                                    width: 300,
                                    child: ElevatedButton(
                                        style: ButtonStyle(
                                          overlayColor: MaterialStateProperty.resolveWith<Color?>(
                                                (Set<MaterialState> states) {
                                              if (states.contains(MaterialState.pressed))
                                                return  Color(0xfffbbc72);
                                              return null;
                                            },),),
                                        onPressed: (){
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(
                                            SnackBar(
                                              margin: EdgeInsets.only(bottom: 50,left: 10,right: 10),
                                              dismissDirection: DismissDirection.endToStart,
                                              behavior: SnackBarBehavior.floating,
                                              duration: Duration(seconds: 2),
                                              backgroundColor: Colors.greenAccent,
                                              content: Text(
                                                'Correct Answer...',style: GoogleFonts.poppins(
                                                fontSize: 15,color: Colors.black,
                                              ),),
                                            ),
                                          );
                                        },child: Text(abc.data![len].opt4,style: GoogleFonts.poppins(
                                      fontSize: 15,
                                    ),)),
                                  ),

                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  SizedBox(
                                    width: 100,
                                    child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                          primary: Colors.amber, // Background color
                                          onPrimary: Colors.black, // Text Color (Foreground color)
                                        ),
                                        onPressed:(){
                                          Navigator.pop(context);
                                        }, child: Text('Back',style: GoogleFonts.poppins(
                                        fontSize: 15,fontWeight: FontWeight.w300
                                    ),)),
                                  ),
                                  SizedBox(
                                    width: 100,
                                    child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                          primary: Colors.amber, // Background color
                                          onPrimary: Colors.black, // Text Color (Foreground color)
                                        ),
                                        onLongPress:  startTimer,
                                        onPressed:(){
                                          _con.nextPage(duration: Duration(seconds: 1), curve: Curves.easeInOut);
                                        }, child: Text('Next',style: GoogleFonts.poppins(
                                      fontSize: 15,fontWeight: FontWeight.w300
                                    ),)),
                                  ),
                                ],
                              ),
                             ],)),
                      )),

                ]);
          },
    ),
    );
    }
    else if(abc.hasError){
    return Text(abc.error.toString());

    }
    return Center(child: SpinKitWaveSpinner(color: Colors.grey));
    }

    ), ),
          SizedBox(
            width: 150,
            child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  primary: Colors.white, // Background color
                  onPrimary: Colors.black, // Text Color (Foreground color)
                ),

                onPressed:Submit, child: Text('Submit',style: GoogleFonts.poppins(
                fontSize: 15,fontWeight: FontWeight.w400,letterSpacing:2
            ),)),
          ),
        ],
      )
    );




  }
}
