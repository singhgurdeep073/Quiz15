import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';

import '../BottomNavigation.dart';
import '../QuizCategory/NavBar.dart';
import '../Home/RankPages/Catgorytab/Real.dart';
import '../controller/wallet.dart';
import 'Pan&BankDetails.dart';

class MyWallet extends StatefulWidget {
  const MyWallet({super.key});

  @override
  State<MyWallet> createState() => _MyWalletState();
}

class _MyWalletState extends State<MyWallet> {
  var paymentController = Get.put(PaymentController());
  final rupees=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      body: LayoutBuilder(
        builder: (context, constraints) =>
            SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(
                    height:MediaQuery.of(context).size.height*1,
                    child: Stack(
                      children: [
                        Positioned(
                            top: 0,
                            bottom: 520,
                            left: 0,
                            right: 0,
                            child: Container(height: 360,
                              color: Colors.blueAccent,
                              child: Column(children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 18.0),
                                  child: Row(
                                    children: [
                                      IconButton(onPressed: (){
                                        Get.to(NavBar());
                                      }, icon:Icon(CupertinoIcons.arrow_left,color: Colors.white,)),
                                      Text(
                                        'My Wallet',
                                        style: GoogleFonts.yaldevi(
                                          fontSize: 24,color: Colors.white,
                                          fontWeight: FontWeight.w700,
                                          fontStyle: FontStyle.normal,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(4.0),
                                  child: Container(
                                    height: 100,
                                    decoration: BoxDecoration(
                                      color: Colors.black26,
                                       borderRadius: BorderRadius.circular(21)
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [

                                        Row(
                                          children: [
                                            Icon(Icons.account_balance_wallet_outlined,color: Colors.orange,size: 40,),


                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(height: 20,),
                                                Row(
                                                  children: [
                                                    Text("Current Balance",style: TextStyle(color: Colors.white,fontSize: 15),),
                                                Icon((CupertinoIcons.info),color: Colors.white,)
                                                  ],
                                                ),
                                                Text("₹100",style: TextStyle(color: Colors.white,fontSize: 18),)
                                              ],
                                            )
                                          ],
                                        ),
                                        ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),),
                                              primary: Colors.green.shade700, // Background color
                                              onPrimary: Colors.grey.shade200, // Text Color (Foreground color)
                                            ),
                                            onPressed: (){
                                              showBottomSheet(context: context,
                                                  shape:RoundedRectangleBorder( borderRadius: BorderRadius.only(topRight: Radius.circular(30),topLeft: Radius.circular(30))),
                                                  backgroundColor: Colors.grey.shade200,

                                                  builder: (context){

                                                return SizedBox(
                                                  height: 300,
                                                  child: Column(
                                                    children: [
                                                      Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                          children: [
                                                            Text("Add money",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 24),),
                                                        IconButton(onPressed: (){
                                                          Navigator.pop(context,false);
                                                        }, icon: Icon(Icons.close))
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        decoration: BoxDecoration(
                                                          gradient: LinearGradient(colors: [
                                                            Colors.blue.shade200,
                                                            Colors.grey.shade200,
                                                          ])
                                                        ),

                                                        height:50,
                                                        width:300,

                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                          children: [
                                                            Row(
                                                              children: [
                                                                Icon(Icons.account_balance_wallet,color: Colors.orange,size: 30,),

                                                               SizedBox(width: 12,),
                                                                Text("Current Balance",style: TextStyle(color: Colors.black,fontSize: 15),),
                                                                Icon((CupertinoIcons.info),color: Colors.black,)

                                                              ],
                                                            ),
                                                            Text("₹0",style: TextStyle(color: Colors.black,fontSize: 18),),

                                                          ],
                                                        ),
                                                      ),
                                                      SizedBox(height: 12,),
                                                      SizedBox(
                                                        width:300,
                                                        child: TextFormField(
                                                          controller: rupees,
                                                          keyboardType: TextInputType.phone,

                                                          decoration: InputDecoration(
                                                            contentPadding: EdgeInsets.only(left: 18),                                                            enabledBorder: OutlineInputBorder(
                                                              
                                                              borderSide: BorderSide(color:Colors.blue.shade400),
                                                              borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                                            ),
                                                            focusedBorder: OutlineInputBorder(
                                                              borderSide: BorderSide(color: Colors.grey),
                                                              borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                                            ),
                                                            hintText: '₹250',

                                                            hintStyle: TextStyle(
                                                              fontWeight: FontWeight.bold,
                                                                fontSize: 18.0, color: Colors.black
                                                            ),



                                                          ),
                                                        ),
                                                      ),
                                                      SizedBox(height: 30,),
                                                      SizedBox(height:60,width:250,
                                                        child: ElevatedButton(
                                                            style: ElevatedButton.styleFrom(
                                                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),),
                                                              primary: Colors.green.shade700, // Background color
                                                              onPrimary: Colors.grey.shade200, // Text Color (Foreground color)
                                                            ),
                                                            onPressed: (){ }, child: Text("Add ₹250")),
                                                      ),
                                                    ],
                                                  )
                                                );
                                              });
                                              }, child: Text("Add Money")),

                                      ],
                                    ),
                                  ),
                                )
                              ],),)
                        ),
                        Positioned(
                          top:170,
                          left: 0,
                          right: 0,
                          child: Padding(
                            padding: const EdgeInsets.all( 13.0),
                            child: Container(
                              height: 550,
                              decoration: BoxDecoration(
                              color: Colors.white,boxShadow: [BoxShadow(color: Colors.black,blurRadius: 4)],
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(children: [
                                  Row(
                                    children: [
                                      
                                      Icon(Icons.badge_rounded,color: Colors.orange,size: 30,),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [

                                          Row(
                                            children: [
                                              Text("Amount Unutilised",style: TextStyle(color: Colors.black,fontSize: 15),),
                                              Icon((CupertinoIcons.info),color: Colors.black,)
                                            ],
                                          ),
                                          Text("₹1",style: TextStyle(color: Colors.black,fontSize: 18),),

                                        ],
                                      )
                                    ],
                                  ),
                                  SizedBox(width: 300,
                                    child: Divider(
                                      thickness: 1,color: Colors.black,
                                    ),
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
  children: [
    Icon(Icons.blur_circular,color: Colors.orange,size: 30,),
    Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        Row(
          children: [
            Text("Winnings",style: TextStyle(color: Colors.black,fontSize: 15),),
            Icon((CupertinoIcons.info),color: Colors.black,)
          ],
        ),
        Text("₹0",style: TextStyle(color: Colors.black,fontSize: 18),),

      ],
    ),  ],
),
                                      ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                            primary: Colors.green.shade700, // Background color
                                            onPrimary: Colors.white, // Text Color (Foreground color)
                                          ),
                                          onPressed: (){
                                            Get.to(
                                                fullscreenDialog: true,duration: Duration(milliseconds: 600),
                                                transition:Transition.fadeIn,
                                                Pan());
                                          }, child: Text("Verify for Withdraw")),
                                    ],
                                  ),
                                  SizedBox(width: 300,
                                    child: Divider(
                                      thickness: 1,color: Colors.black,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Icon(Icons.attach_money_outlined,color: Colors.orange,size: 30,),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [

                                          Row(
                                            children: [
                                              Text("Bonus",style: TextStyle(color: Colors.black,fontSize: 15),),
                                              Icon((CupertinoIcons.info),color: Colors.black,)
                                            ],
                                          ),
                                          Text("₹1.96",style: TextStyle(color: Colors.black,fontSize: 18),),

                                        ],
                                      )
                                    ],
                                  ),
                                  SizedBox(width: 300,
                                    child: Divider(
                                      thickness: 1,color: Colors.black,
                                    ),
                                  ),
                                  SizedBox(height: 50,),
                                  Container(
                                    height: 150,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      boxShadow: [BoxShadow(color: Colors.black,blurRadius: 1)],
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    child: Column(
                                      children: [
                                        ListTile(
                                          leading: Icon(Icons.data_usage_sharp),
                                          title: Text("My Transactions"),
                                          trailing: Icon(Icons.arrow_right),
                                        ),
                                        SizedBox(width: 300,
                                          child: Divider(
                                            thickness: 1,color: Colors.black,
                                          ),
                                        ),
                                        ListTile(
                                          leading: Icon(Icons.refresh),
                                          title: Text("Refer & Earn"),
                                          subtitle: Text("Invite Friens To earn Rs. 99",style: TextStyle(fontSize: 13,color: Colors.grey),),
                                          trailing: Icon(Icons.arrow_right),
                                        ),

                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 50,),
                                  Container(
                                    height: 70,
                                    decoration: BoxDecoration(
                                      color: Colors.green.shade100,
                                      boxShadow: [BoxShadow(color: Colors.green,blurRadius: 1)],
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    child: Column(
                                      children: [
                                        ListTile(
                                          leading: Icon(Icons.messenger_sharp),
                                          title: Text("Do You have a Question about Balance..",style: TextStyle(fontSize: 14),),
                                          trailing:  ElevatedButton(
                                              style: ElevatedButton.styleFrom(
                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                                primary: Colors.green.shade700, // Background color
                                                onPrimary: Colors.white, // Text Color (Foreground color)
                                              ),
                                              onPressed: (){
                                              }, child: Text("Get Help")),
                                        ),


                                      ],
                                    ),
                                  ),
                                ],),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
      ),
    );
  }
}
