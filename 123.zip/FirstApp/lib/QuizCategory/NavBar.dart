import 'package:firstapp/QuizCategory/Complete.dart';
import 'package:firstapp/QuizCategory/Live.dart';
import 'package:firstapp/QuizCategory/upcoming.dart';
import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

class QuizNav extends StatefulWidget {
  const QuizNav({super.key});

  @override
  State<QuizNav> createState() => _QuizNavState();
}

class _QuizNavState extends State<QuizNav> {
  int currentPage = 0;
  List<Widget> pages =  [
    Live(),
    Upcoming(),
    Complete()
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(


      body: pages[currentPage],
      bottomNavigationBar: Padding(
        padding:  EdgeInsets.all(12),
        child: Container(
          height: 70,

          decoration: BoxDecoration(
              color: Colors.grey,
              borderRadius: BorderRadius.circular(13)),
          child: GNav(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            tabBorder: Border.all(color: Colors.white),
            activeColor: Colors.black,
            tabBackgroundColor: Colors.white,
            gap: 1,
            onTabChange: (index) => setState(() => currentPage = index),
            selectedIndex: currentPage,
            padding: const EdgeInsets.all(16),
            tabs: const [
              GButton(icon: Icons.home,textSize: 10,iconColor: Colors.white,iconSize: 15),
              GButton(icon: Icons.menu_book,textSize: 15,iconColor: Colors.white,iconSize: 15),
              GButton(icon: Icons.open_in_new,textSize: 15,iconColor: Colors.white,iconSize: 15),

            ],
          ),
        ),
      ),
    );
  }
}