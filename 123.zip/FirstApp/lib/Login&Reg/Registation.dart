import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../First Category.dart';
import 'Login&Reg.dart';

class Reg extends StatefulWidget {
  const Reg({super.key});

  @override
  State<Reg> createState() => _RegState();
}

class _RegState extends State<Reg> {
  final formGlobalKey = GlobalKey <FormState>();

  final name = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  final State = TextEditingController();
  final city = TextEditingController();
  final pincode = TextEditingController();
  bool isVerifying = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      resizeToAvoidBottomInset: false,
      body: Form(
      key:formGlobalKey,
      child: Column(
        children: [
          SizedBox(
            height: 700,
            child: Stack(
              children: [
                Positioned(
                  top: 0,
                  bottom: 300,
                  left: 0,
                  right: 0,
                  child: Column(
                    children: [
                      Center(
                        child: Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage("images/AppBar.jpeg"),
                              fit: BoxFit.cover,
                            ),
                          ),
                          margin: EdgeInsets.only(),
                          height: 200,
                          child: Row(
                            mainAxisAlignment:
                            MainAxisAlignment.center,
                            children: [

                              Column(
                                children: [
                                  SizedBox(height: 50,),
                                  Text(
                                    "Register Now",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25,
                                    ),
                                  ),
                                  Text(
                                    "Let's get you started",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),

                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top:130,
                  left: 5,
                  right: 5,
                  child: Container(
                    height:500,
                    decoration: BoxDecoration(
                       color:Colors.white,
                      boxShadow: [BoxShadow(
                        color: Colors.black,blurRadius: 3,
                      )],
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                            left: 14.0,
                            right: 14,
                            top: 14,
                          ),
                          child: Column(
                            children: [
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: name,


                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color:Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'Name',

                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue
                                  ),
                                  prefixIcon: Icon(
                                    Icons.account_circle,
                                    color: Colors.grey,
                                  ),


                                ),
                              ),
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: email,

                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color:Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'Email',

                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue
                                  ),
                                  prefixIcon: Icon(
                                    Icons.email,
                                    color: Colors.grey,
                                  ),


                                ),
                              ),
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: phone,
                                keyboardType: TextInputType.phone,
                                maxLength: 10,
                                decoration: InputDecoration(
                                  counterStyle: TextStyle(color: Colors.black,fontSize: 1),
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'Phone No.',
                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue,
                                  ),
                                  prefixIcon: Icon(
                                    Icons.call,
                                    color: Colors.grey,
                                  ),


                                ),
                              ),
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: State,

                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'State',

                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue,
                                  ),
                                  prefixIcon: Icon(
                                    Icons.flag,
                                    color: Colors.grey,
                                  ),


                                ),
                              ),
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: city,

                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'Your City',

                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue,
                                  ),
                                  prefixIcon: Icon(
                                    Icons.location_city_sharp,
                                    color: Colors.grey,
                                  ),


                                ),
                              ),
                              SizedBox(height: 10,),
                              TextFormField(
                                controller: pincode,
                                maxLength: 10,
                                keyboardType: TextInputType.phone,
                                decoration: InputDecoration(
                                  counterStyle: TextStyle(color: Colors.white,fontSize: 1),
                                  contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.blue.shade400),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                  labelText: 'Pin Code',

                                  labelStyle: TextStyle(
                                      fontSize: 13.0, color: Colors.blue
                                  ),
                                  prefixIcon: Icon(
                                    Icons.pin_drop,
                                    color: Colors.grey,
                                  ),


                                ),
                              ),
                              SizedBox(
                                width: 250,
                                child: ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                      primary: Colors.green.shade400, // Background color
                                      onPrimary: Colors.white, // Text Color (Foreground color)
                                    ),
                                    onPressed: (){
                                      print(name.toString());
                                      print(email.toString());
                                      print(phone.toString());
                                      print(State.toString());
                                      print(city.toString());
                                      print(pincode.toString());
                                      Get.to(
                                          fullscreenDialog: true,duration: Duration(milliseconds: 600),
                                          transition:Transition.fadeIn,
                                          Cat());

                                    }, child: Text("Register",)),
                              ),
                            ],
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
    );
  }




}