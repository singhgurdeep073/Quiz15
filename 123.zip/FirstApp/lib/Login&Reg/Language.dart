import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';

import '../BottomNavigation.dart';
import '../First Category.dart';
import '../FirstScreen Pge/Home.dart';
class Language{
  final String lang;
  Language({required this.lang});
}
class Lang extends StatefulWidget {
  const Lang({super.key});

  @override
  State<Lang> createState() => _LangState();
}

class _LangState extends State<Lang> {
  Set<Language> ll = {};
  List<Language>lan=[
    Language(lang: "Hindi"),
    Language(lang: "English"),
    Language(lang: "Marathi"),
    Language(lang: "Punjabi"),

  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      body: LayoutBuilder(
          builder: (context, constraints) =>
              SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height:MediaQuery.of(context).size.height*1,
                      child: Stack(
                        children: [
                          Positioned(
                              top: 0,
                              bottom:MediaQuery.of(context).size.height*.60,
                              left: 0,
                              right: 0,
                              child: Container(height: MediaQuery.of(context).size.height*.50,
                                color: Colors.blueAccent,
                                child: Column(children: [


                                  Padding(
                                    padding:  EdgeInsets.only(top:MediaQuery.of(context).size.height*.10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [

                                        Icon(Icons.search,color: Colors.orange.shade200,size: 40,),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              """Choose Language""",
                                              style: GoogleFonts.yaldevi(
                                                fontSize: 24,color: Colors.white,
                                                fontWeight: FontWeight.w700,
                                                fontStyle: FontStyle.normal,
                                              ),
                                            ),

                                          ],)
                                      ],),
                                  )
                                ],),)
                          ),
                          Positioned(
                            top:MediaQuery.of(context).size.height*.20,
                            left: 0,
                            right: 0,
                            child: Padding(
                              padding: const EdgeInsets.all( 13.0),
                              child: Column(
                                children: [
                                  Container(
                                    height: MediaQuery.of(context).size.height*.60,
                                    decoration: BoxDecoration(
                                      color: Colors.white,boxShadow: [BoxShadow(color: Colors.black,blurRadius: 1)],
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    child: GridView.builder(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
                                        itemCount: lan.length,

                                        itemBuilder: (context,index){
                                      bool isSelected =
                                      ll.contains(lan[index]);
                                          return GestureDetector(
                                            onTap: (){
                                              setState(() {
                                                if (isSelected) {
                                                  ll.remove(lan[index]);
                                                } else {
                                                  ll.add(lan[index]);
                                                }
                                              });

                                            },
                                            child: Card(
                                              color: isSelected
                                                  ? Colors.green.shade300
                                                  : Colors.blue.shade100,
                                              child: Center(child: Text(lan[index].lang,  style: GoogleFonts.yaldevi(
                                                fontSize: 24,color: Colors.black,
                                                fontWeight: FontWeight.w700,
                                                fontStyle: FontStyle.normal,
                                              ),)),
                                            ),
                                          );
                                        }),
                                  ),
                                  SizedBox(
                                    width: 150,
                                    child: ElevatedButton(
                                      onPressed: ll.length >= 1
                                          ? () {

                                        Get.off(
                                          fullscreenDialog: true,duration: Duration(milliseconds: 600),
                                          transition:Transition.fadeIn,
                                          NavBar(),
                                        );
                                      }
                                          : null,
                                      child: Text('Next',style: GoogleFonts.poppins(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold
                                      ),),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                  ],
                ),
              )
      ),
    );
  }
}
