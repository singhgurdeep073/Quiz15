import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../../FirstScreen Pge/Home.dart';
import '../../Subcategory/SubCategory.dart';

class FixTab extends StatefulWidget {
  const FixTab({super.key});

  @override
  State<FixTab> createState() => _RealTAbState();
}
class _RealTAbState extends State<FixTab> {
  List<Imageslider>img=[
    Imageslider(img: "images/S1.jpeg"),
    Imageslider(img: "images/S2.jpeg"),
    Imageslider(img: "images/S3.jpeg"),
  ];

  Future<List<Quiz15>> fetchDataQuiz15() async{
    final responce=await http.get(Uri.parse("https://amazonboost.in/demo/twiz/question_view_api"));
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => Quiz15.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:   Column(
        children: [
          Container(
            margin: EdgeInsets.all(4),
            child:   CarouselSlider.builder(
              itemCount: img.length,
              itemBuilder: (BuildContext context, int index, int realIndex) {
                return Padding(
                  padding: const EdgeInsets.only(left: 4.0,right: 4,top: 4),
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        image: DecorationImage(image: AssetImage(img[index].img),fit: BoxFit.cover)
                    ),
                  ),
                );
              },
              options: CarouselOptions(
                height: 90,
                aspectRatio: 9 / 9,
                viewportFraction: 1,
                initialPage: 1,
                enableInfiniteScroll: true,
                autoPlay: true,
              ),
            ),
          ),
          Row(mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Upcoming Quiz..',
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.normal,
                  ),
                ),
              ),
            ],
          ),
          Container(
            height: 450,
            child: FutureBuilder<List<Quiz15>>(
                future: fetchDataQuiz15(),
                builder: (context,abc){
                  if(abc.hasData){
                    return  ListView.builder(
                        itemCount: abc.data!.length,
                          scrollDirection: Axis.vertical,
                        itemBuilder: (BuildContext context,int len){
                          return Column(
                            children: [

                              GestureDetector(
                                onTap: (){
                                  Get.to(
                                      fullscreenDialog: true,duration: Duration(milliseconds: 600),
                                      transition:Transition.fadeIn,
                                      Pool());
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    height: 133,width: 350,
                                    decoration: BoxDecoration(
                                        border: Border.all(color: Color(0xffe5e5e5),width: 1.50 ),
                                        borderRadius: BorderRadius.circular(10)
                                    ),
                                    child: Column(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(right: 8.0),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(height: 36,
                                                width: 110,
                                                decoration: BoxDecoration(
                                                    color: Color(0xffe3e7ed),
                                                    borderRadius: BorderRadius.only(bottomRight: Radius.circular(45),topLeft: Radius.circular(12))
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    abc.data![len].categ,
                                                    style: GoogleFonts.poppins(
                                                      textStyle: Theme.of(context).textTheme.displayLarge,
                                                      fontSize: 16,
                                                      fontWeight: FontWeight.w500,
                                                    ),
                                                  ),
                                                ),
                                              ), Container(
                                                height:25,width: 120,
                                                decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(5),
                                                    color: Color(0xff07a76b),
                                                    border: Border.all(color:Color(0xff07a76b), )
                                                ),
                                                child:   Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [
                                                    Text(
                                                      'Competitions',
                                                      style: GoogleFonts.poppins(
                                                        fontSize: 12,
                                                        fontWeight: FontWeight.w400,
                                                        fontStyle: FontStyle.normal,
                                                      ),
                                                    ),
                                                    SizedBox(width: 10,),
                                                    Container(color: Colors.white,height: 25,width: 25,
                                                      child: Center(
                                                        child: Text(
                                                          '4',
                                                          style: GoogleFonts.poppins(
                                                            fontSize: 18,
                                                            color: Colors.blue,
                                                            fontWeight: FontWeight.w700,
                                                            fontStyle: FontStyle.normal,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),),
                                            ],),
                                        ),
                                        SizedBox(
                                          height: 3,
                                        ),
                                        Divider(thickness: 0.50,),
                                        Padding(
                                          padding: const EdgeInsets.only(left: 8.0,right: 8),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [Column(crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text("Win Cash",style: TextStyle(fontSize: 16,color: Colors.green,fontWeight: FontWeight.bold),),
                                                Text("Prize Pool ",style: TextStyle(fontSize: 12,color: Colors.black,fontWeight: FontWeight.bold),),
                                              ],
                                            ),
                                              Icon(CupertinoIcons.right_chevron)
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(top: 4),
                                          height: 35,width: MediaQuery.of(context).size.width*1,
                                          decoration: BoxDecoration(
                                              color: Color(0xffd4d4d4),
                                              borderRadius: BorderRadius.only(bottomLeft: Radius.circular(8),bottomRight: Radius.circular(8))),
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Row(children: [
                                                  Icon(Icons.sign_language_sharp,color: Colors.blue,size: 17,),
                                                  Text("English",style: TextStyle(fontSize: 12,color: Colors.black,fontWeight: FontWeight.bold),),


                                                ],),
                                                Row(children: [
                                                  Icon(Icons.alarm_on,color: Colors.blue,size: 17,),
                                                  Text("1 H 0 M",style: TextStyle(fontSize: 12,color: Colors.black,fontWeight: FontWeight.bold),),


                                                ],),
                                              ],),
                                          ), )

                                      ],),),
                                ),
                              ),
                            ],);

                        });
                  }
                  else if(abc.hasError){
                    return Text(abc.error.toString());

                  }
                  return Center(child: SpinKitWaveSpinner(color: Colors.grey));
                }

            ),
          ),
        ],
      ),

    );
  }
}

class Quiz15 {
  final int id;
  final String created_at;
  final String categ;
  Quiz15({required this.id,required this.created_at,required this.categ, });
  factory Quiz15.FromJson(Map<String,dynamic>json){
    return Quiz15(id: json['id'],created_at: json['created_at'],categ:json['categ']);

  }
}
