import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:scroll_loop_auto_scroll/scroll_loop_auto_scroll.dart';
class RealTab extends StatefulWidget {
  const RealTab({Key? key}) : super(key: key);

  @override
  State<RealTab> createState() => _RealTabState();
}

class _RealTabState extends State<RealTab> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children:[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    CircleAvatar(
                      radius: 40,
                      backgroundImage: NetworkImage("https://cdn-icons-png.flaticon.com/512/3177/3177440.png"),),
                    SpinKitThreeBounce(
                     size: 20,
                     color: Colors.grey),
                    SizedBox(
                      height: 150,
                      child: ScrollLoopAutoScroll(
                        duration: Duration(seconds: 8),
                        scrollDirection: Axis.vertical,
                        child: Column(
                          children: [
                            CircleAvatar(
                              radius: 40,
                              backgroundImage: NetworkImage("https://wac-cdn.atlassian.com/dam/jcr:ba03a215-2f45-40f5-8540-b2015223c918/Max-R_Headshot%20(1).jpg?cdnVersion=1283"),
                            ),
                            CircleAvatar(
                              radius: 40,
                              backgroundImage: NetworkImage("https://clipart-library.com/images/kTKo7BB8c.png"),
                            ),
                            CircleAvatar(
                              radius: 40,
                              backgroundImage: NetworkImage("https://icons-for-free.com/iconfiles/png/512/business+costume+male+man+office+user+icon-1320196264882354682.png"),
                            ),
                            CircleAvatar(
                              radius: 40,
                              backgroundImage: NetworkImage("https://preview.keenthemes.com/metronic-v4/theme/assets/pages/media/profile/profile_user.jpg"),
                            ),
                          ],
                        ),
                      ),
                    ),],
                ),



            ],
          ),
        ),
      ),
    );
  }
}