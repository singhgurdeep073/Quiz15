import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../Payment/Payment.dart';
import '../RankPages/Leaderboard.dart';
import '../RankPages/Winnings.dart';
class AlredyJoin extends StatefulWidget {
  const AlredyJoin({super.key});
  @override
  State<AlredyJoin> createState() => _AlredyJoinState();
}
class _AlredyJoinState extends State<AlredyJoin> {
  @override
  Widget build(BuildContext context) {
    return  DefaultTabController(
      length: 2,
      child: Scaffold(
          resizeToAvoidBottomInset: false,
          appBar: AppBar(
            iconTheme: IconThemeData(
              color: Colors.black,
            ),
            backgroundColor: Colors.white,
            actions: [
              Container(
                margin: EdgeInsets.only(right: 100),
                height: 70,width: 70,
                decoration: BoxDecoration(
                    image: DecorationImage(image: AssetImage("images/logo.png"))
                ),
              ),
              IconButton(onPressed: (){}, icon:Icon( Icons.account_balance_wallet,color: Color(0xff259de0),),),
            ],
          ),
          body: Column(children: [
            Container(
              height: 225,
              width: MediaQuery.of(context).size.width*1,
              decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.black,blurRadius: 6)]),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(right: 250.0,top: 15),
                    child: Column(

                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Prize Pool',style: GoogleFonts.poppins(
                          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black,

                        ),)

                      ],),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 10),
                    height: 4,width: 300,
                    decoration: BoxDecoration( color: Colors.blue,
                        borderRadius: BorderRadius.circular(12)
                    ),
                    child: Row(
                      children: [
                        Container(
                          height: 4,width: 250,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                                Colors.grey.shade200,

                                Colors.red,])
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0,right: 8,top: 7),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '4 Spot left',
                          style: GoogleFonts.yaldevi(
                            fontSize: 13,color: Colors.red,
                            fontWeight: FontWeight.bold,
                            fontStyle: FontStyle.normal,
                          ),
                        ),
                        Text(
                          '10 Spots',
                          style: GoogleFonts.yaldevi(
                            fontSize: 13,color: Colors.grey,
                            fontWeight: FontWeight.w400,
                            fontStyle: FontStyle.normal,
                          ),
                        ),
                      ],),
                  ),
                  GestureDetector(
                    onTap: (){
                      Get.snackbar("You Already Join","Wait For Quiz Time",
                      colorText: Colors.white,
                        backgroundColor: Colors.green.shade800
                      );
                    },
                    child: Container(
                      margin: EdgeInsets.only(top: 12),
                      height: 40,width: 300,
                      decoration: BoxDecoration(
                        color: Colors.blue.shade200,
                        border: Border.all(color: Colors.blue),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child:
                      Center(child:  Text('Join',style: GoogleFonts.poppins(
                          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,

                      ),)),

                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 15),
                    height: 40,width: 360,
                    decoration: BoxDecoration(
                      color: Color(0xfff5f5f5),

                    ),child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(children: [
                        Icon( Icons.monetization_on, size: 15,),
                        SizedBox(width: 6,),
                        Text(
                          '₹60,000',
                          style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                        ),
                        SizedBox(width: 6,),
                        Icon( Icons.local_bar_outlined, size: 15,),
                        SizedBox(width: 6,),
                        Text(
                          '57%',
                          style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                        ),
                        SizedBox(width: 6,),
                        Icon( Icons.maps_ugc_sharp, size: 15,),
                        SizedBox(width: 6,),
                        Text(
                          'Upto 20',
                          style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                        ),
                      ],),
                      Row(
                        children: [
                          Icon( Icons.check_circle_outline, ),
                          SizedBox(width: 6,),
                          Text(
                            'Guaranteed',
                            style: TextStyle(fontWeight: FontWeight.w200,fontSize: 12),
                          ),
                        ],
                      ),



                    ],
                  ),),
                  Container(
                      height: 40,width: 360,
                      decoration: BoxDecoration(
                        color: Color(0xfffdebeb),

                      ),
                      child: Row(
                        children: [
                          Text(" Earn 1 for every ₹60 spent on contest entry"),
                        ],
                      )),

                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),),
                  child: TabBar(
                    labelColor:Color(0xff259de0),
                    indicatorSize: TabBarIndicatorSize.label,
                    indicatorColor: Colors.grey,
                    tabs: [
                      Tab(
                        text: "Winnings",
                      ),
                      Tab(
                        text: "Leaderboard",
                      ),
                    ],
                  ),
                ),
                Container(height: 350,
                  child: TabBarView(children: [
                    Winnings(),
                    Leaderboard(),
                  ]),)
              ],),
          ])),
    );
  }
}
