import 'dart:async';

import 'package:firstapp/Payment/MyWallet.dart';
import 'package:firstapp/Quiz%20Page/Quiz%20Page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../api/Sub.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../../clock.dart';
import '../../controller/wallet.dart';
import '../RankPages/RankPage.dart';
class Entry extends StatefulWidget {
  const Entry({super.key});

  @override
  State<Entry> createState() => _EntryState();
}

class _EntryState extends State<Entry> {
  var paymentController = Get.put(PaymentController());
  int price = 100;
  late Timer _timer;
  int _secondsRemaining = 15 * 60;
  bool checkBox1=false;
  bool checkBox2=false;
  bool checkBox3=false;
  Future<List<Sub>> fetchDataQuiz() async{
    final responce=await http.get(Uri.parse("https://amazonboost.in/demo/twiz/subject"));
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => Sub.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }
  }
  void startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_secondsRemaining > 0) {
        setState(() {
          _secondsRemaining--;
        });
      } else {
        _timer.cancel();
      }
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:   Column(
        children: [
          Container(height: 70,
            width: MediaQuery.of(context).size.width*1,
            color:Color(0xff259de0),
            child: Column(children: [
              Padding(
                padding: const EdgeInsets.only(left: 8.0,right: 8,),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Select Content", style: GoogleFonts.poppins(
                      fontSize: 15,
                      color: Colors.white,
                    ),),
                    Text("Join", style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 15,
                    ),),
                    Text("Create Team", style: GoogleFonts.poppins(
                      fontSize: 15, color: Colors.white,
                    ),),
                  ],
                ),
              ),
              Row(
                  children: <Widget>[
                    Checkbox(
                      activeColor: Colors.white,
                      checkColor: Colors.black,
                      shape: const CircleBorder(),
                      value: checkBox1,
                      onChanged: (bool? newValue) {
                        setState(() {
                          checkBox1 = newValue!;
                        });
                      },
                    ),
                    Expanded(
                        child: Divider(
                          thickness: 1,
                        )
                    ),
                    Checkbox(
                      activeColor: Colors.white,
                      checkColor: Colors.black,
                      shape: const CircleBorder(
                      ),
                      value: checkBox2,
                      onChanged: (bool? newValue) {
                        setState(() {
                          checkBox2 = newValue!;
                        });
                      },
                    ),
                    Expanded(
                        child: Divider(
                          thickness: 1,)
                    ),
                    Checkbox(
                      activeColor: Colors.white,
                      checkColor: Colors.black,
                      shape: const CircleBorder(),
                      value: checkBox3,
                      onChanged: (bool? newValue) {
                        setState(() {
                          checkBox3 = newValue!;
                        });
                      },
                    ),
                  ]
              ),
            ],),
          ),
          FutureBuilder<List<Sub>>(
              future: fetchDataQuiz(),
              builder: (context,abc){
                if(abc.hasData){
                  return  Container(
                    height:MediaQuery.of(context).size.height*.73,
                    child: ListView.builder(
                        itemCount: abc.data!.length,
                        scrollDirection: Axis.vertical,
                        itemBuilder: (BuildContext context,int len){
                          return Column(
                            children: [
                              SizedBox(
                                height: 6,
                              ),
                              GestureDetector(
                                  onTap: (){
                                    Get.to(
                                        fullscreenDialog: true,duration: Duration(milliseconds: 600),
                                        transition:Transition.fadeIn,
                                        Rank());                                    },
                                  child: Container(height: 170,width: 350,
                                    decoration: BoxDecoration(
                                        border: Border.all(color: Color(0xffe5e5e5),width: 1.50 ),
                                        borderRadius: BorderRadius.circular(10)
                                    ),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(left: 8.0,right: 8),
                                              child: Container(height: 36,
                                                width: 210,
                                                decoration: BoxDecoration(
                                                    color: Color(0xffe3e7ed),
                                                    borderRadius: BorderRadius.only(bottomRight: Radius.circular(45),topLeft: Radius.circular(12))
                                                ),
                                                child: Padding(
                                                  padding: const EdgeInsets.only(left: 7.0,right: 1,top: 12),
                                                  child: Text(
                                                    abc.data![len].subject,
                                                    style: GoogleFonts.poppins(
                                                      textStyle: Theme.of(context).textTheme.displayLarge,
                                                      fontSize: 14,
                                                      fontWeight: FontWeight.w500,
                                                      fontStyle: FontStyle.italic,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child: Column(
                                                children: [
                                                  Text("2 Days",style: TextStyle(fontWeight: FontWeight.bold,color: Color(0xffb63131),fontSize: 13),),
                                                  Text("01:30PM",style: TextStyle(fontSize: 13),),
                                                ],
                                              ),
                                            ),
                                          ],),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(left: 8.0,right: 8),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,

                                            children: [
                                              Container(
                                                  height: 35,width: 60,
                                                  decoration: BoxDecoration(

                                                      borderRadius: BorderRadius.circular(12)
                                                  ),
                                                  child:Clock()
                                              ),

                                              Row(
                                                children: [
                                                  Padding(
                                                    padding: const EdgeInsets.only(left: 4.0,right: 4),
                                                    child: Center(
                                                      child: Obx(() {
                                                        if (paymentController.paymentPrice > 30) {
                                                          return SizedBox(
                                                            width: 150,
                                                            child: ElevatedButton(
                                                              style: ElevatedButton.styleFrom(
                                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),),
                                                                primary: Colors.green.shade700, // Background color
                                                                onPrimary: Colors.grey.shade200, // Text Color (Foreground color)
                                                              ),
                                                              onPressed: (){
                                                                Get.to(() => Quiz());
                                                              },
                                                              child: Text('Join Now'),
                                                            ),
                                                          );
                                                        } else {
                                                          return ElevatedButton(
                                                            style: ElevatedButton.styleFrom(
                                                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),),
                                                              primary: Colors.red.shade700, // Background color
                                                              onPrimary: Colors.grey.shade200, // Text Color (Foreground color)
                                                            ),
                                                            onPressed: () {
                                                              Get.to(() => MyWallet());
                                                            },
                                                            child: Text('Need to Pay'),
                                                          );
                                                        }
                                                      }),
                                                    ),
                                                  ),
                                                ],
                                              ),

                                            ],
                                          ),


                                        ),

                                        Padding(
                                          padding: const EdgeInsets.only(left: 8.0,right: 8),
                                          child: Divider(
                                            thickness: .30,
                                            color: Color(0xff878787),
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(right: 230.0),
                                          child: Center(
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  'Prize Pool',
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 15,
                                                    fontWeight: FontWeight.w300,


                                                  ),
                                                ),
                                                Text(
                                                  'Rs.1',
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 18,
                                                    fontWeight: FontWeight.bold,


                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        )
                                      ],),)
                              )],
                          );

                        }),
                  );
                }
                else if(abc.hasError){
                  return Text(abc.error.toString());

                }
                return Padding(
                  padding:  EdgeInsets.only(top:MediaQuery.of(context).size.height*.35),
                  child: SpinKitWaveSpinner(color: Colors.grey),
                );
              }

          ),
        ],
      ),
    );
  }
}
